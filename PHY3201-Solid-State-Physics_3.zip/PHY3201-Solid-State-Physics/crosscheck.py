# -*- coding: utf-8 -*-
"""Cross-check: every number asserted in the 18 new questions must appear in the
   independently computed set from verify_calc.py."""
import json, re, io, sys
p='/home/claude/PHY3201-Solid-State-Physics/assets/js/content/practice.js'
s=io.open(p,encoding='utf-8').read()
arr=json.loads(re.search(r'practiceBank = (\[.*?\n\];)',s,re.S).group(1)[:-1])
new={q['id']:q for q in arr if q['id'].split('-')[1] in ('C3','M3')}
assert len(new)==18, len(new)

# (id, list of strings that MUST be present somewhere in equation+solution)
MUST = {
 'T1-C3': ['0.16795','0.5236','2.639','3.790'],
 'T1-M3': ['0.939','0.564','0.4053','0.5660','0.702','1.4 %','0.35 %'],
 'T2-C3': ['0.2027','0.1433','0.1170','0.4964','4.03'],
 'T2-M3': ['0.08214','12.17','17.22','1.414','1.217','1.722','0.2027','0.1433'],
 'T3-C3': ['0.10854','0.14473','0.28948','1.333','2.667','0.23380','0.4049','19.24','22.36','32.55'],
 'T3-M3': ['0.01501','0.9442','9.8','0.13865'],
 'T4-C3': ['71','37','3.68','5041','1369'],
 'T4-M3': ['26.9','81.6','5.257','27.6','27'],
 'T5-C3': ['8.924','7.932','3.966','7.808','8.031','11.1','2.8 %'],
 'T5-M3': ['3.816','0.0104','57.15','0.05141','0.824','3.52','26.9','3.46','93'],
 'T6-C3': ['1.192','2.384','3.80','3050','2160','0.7071'],
 'T6-M3': ['2.316','3.599','5.73','3.59','4.46','0.87','1.242'],
 'T7-C3': ['233.78','1943.8','4.817','0.0482','0.19','0.00695','14.43','3.8'],
 'T7-M3': ['36.7','12.9','45.9','2.8','1.062'],
 'T8-C3': ['2.174','25','43.9','39.2','153','5.429'],
 'T8-M3': ['436','401','8.8','1.788'],
 'T9-C3': ['21.663','3.906','1.706','6.67','8 ×'],
 'T9-M3': ['2.275','2.780','6.11','0.067','3.9','6.1'],
}
bad=[]
for qid, toks in MUST.items():
    blob = new[qid]['equation'] + '\n' + new[qid]['solution'] + '\n' + new[qid]['meaning'] + '\n' + new[qid]['prompt'] + '\n' + new[qid]['hint1'] + '\n' + new[qid]['hint2'] + '\n' + new[qid]['workspace']
    for t in toks:
        if t not in blob: bad.append((qid,t))
print('missing asserted values:', len(bad))
for x in bad: print('  ', x)

# every new question must show an '=' chain in its equation field and be multi-line
for qid,q in sorted(new.items()):
    lines=[l for l in q['equation'].split('\n') if l.strip()]
    assert len(lines)>=3, (qid,'equation too short',len(lines))
    assert '=' in q['equation'], qid
    assert q['type']=='Calculation', qid
print('all 18 have a multi-line equation → substitution → result block')
sys.exit(1 if bad else 0)
