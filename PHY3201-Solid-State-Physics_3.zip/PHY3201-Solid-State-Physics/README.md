# PHY3201 · Solid State Physics — Course Studio

Interactive course studio for **PHY3201 Solid State Physics**, Universiti Putra Malaysia.
3 credits · 14 teaching weeks · 42 lecture contact hours · 9 topics · 120 h student learning time.

Built 1 September 2026. Rebuilt from the ChatGPT studio (`PHY3201_Studio_MASTER`) onto the
architecture used for the PHY4230 studio, restructured to the **official 9-topic Rangka Kursus**,
and rewritten with Kittel-anchored derivations and checked numbers.

---

## 1 · Running it

**As a folder / GitHub Pages site**

Open `index.html`, or push the folder to a repository and enable GitHub Pages on the root.
No build step, no dependencies, no network requests.

**As a single file**

```
python3 build-single-file.py      →  PHY3201-offline.html
```

One self-contained HTML file, ~490 KB, with every stylesheet, script and diagram inlined.
It makes **no network requests at all** — usable offline, on a projector, or emailed to a student.

---

## 2 · Structure

```
index.html                    page shell, script load order (order matters)
build-single-file.py          offline bundler — see §6 before adding a script
assets/
  css/styles.css              design system, print stylesheet, responsive rules
  img/                        drop upm-logo.png here (see §7)
  js/
    glossary.js               60 terms, auto-linked site-wide
    diagrams.js               41 hand-authored SVG mechanism diagrams
    content/
      home.js                 course home
      map.js                  14-week teaching map
      assessment.js           assessment hub + CAP/COPO mapping
      topic01.js … topic09.js the nine topics
      practice.js             63-question bank + the Practice Hub page
      p4ph.js                 Physics for Planetary Health project brief
      references.js           reference list, reading map, glossary table
    widgets.js                12 interactive explorers
    app.js                    router, block renderer, navigation, progress
```

**Routes (15):** `home` · `map` · `assessment` · `p4ph` · `topic01`–`topic09` · `practice` · `references`

---

## 3 · What changed from the ChatGPT studio

| | Old studio | This one |
|---|---|---|
| Topics | 8 (Wave Diffraction merged with Amplitude Wave Scattering) | **9, matching the official RK** and the week-by-week table |
| Assessment | Continuous 10 / Test 15 / Test 15 / P4PH 20 / Final 40 | Same weights, remapped to the **Sem 1 2026/2027 CAP-COPO**: PO1 60, PO3 20, PO7 20 |
| Figures | AI-generated raster images, flagged unvalidated in the old manifest | **41 hand-authored SVG diagrams**, drawn from the equations |
| Practice bank | 27 questions | **63 questions**, 7 per topic, balanced across level and type |
| Derivations | Stated | Derived, with **Calculation Corners** whose numbers were computed and checked against published values |
| References | Listed | Mapped **per topic to chapter and section**, with three citation errors corrected and coverage gaps named |

**The AI-generated images from the old studio were deliberately not carried over.** The old
`IMAGE_ASSET_MANIFEST.txt` flagged them as unvalidated drafts, and one was already known to be
wrong (a "7 crystal systems" heading over a figure showing four). Every figure here is drawn
from the physics instead.

### The 9-topic structure

| # | Topic | Hours | Weeks |
|---|---|---|---|
| 1 | Crystal Structure | 3 | 1 |
| 2 | Crystal Analysis | 6 | 2–3 |
| 3 | Wave Diffraction | 3 | 4 |
| 4 | Amplitude Wave Scattering | 3 | 5 |
| 5 | Crystal Bonding | 6 | 6–7 |
| 6 | Phonons I | 6 | 8–9 |
| 7 | Phonons II | 6 | 10–11 |
| 8 | Free Electrons and Fermi Gas | 6 | 12–13 |
| 9 | Band Theory | 3 | 14 |
| | **Total** | **42** | **14** |

This split is confirmed by the RK weekly table, which allocates exactly these hours.

### Corrections applied after an independent physics review

An adversarial review pass recomputed every numerical claim and checked the physics. Eight definite
errors were found and fixed; seven further statements were sharpened. Recorded here because several
are the kind of thing that quietly propagates into a lecture:

1. **Topic 4 said (200) is absent in silicon "by mixed parity".** It is not — (200) is all-even and
   the FCC rule *allows* it. Both (200) and (222) are extinguished by the diamond **basis**
   (h+k+l ≡ 2 mod 4), which is precisely the point that paragraph was making. Fixed there and in
   practice question T4-M2.
2. **A practice answer claimed the first-two-peak ratio distinguishes SC, BCC and FCC.** It gives
   BCC and SC the same 1:2 ratio. They first diverge at the seventh line: BCC has it (from (321)),
   SC cannot, since 7 is not a sum of three squares. Fixed.
3. **Topic 5 claimed lead has "covalent-scale bonds in some directions".** It does not — lead is FCC
   with non-directional metallic bonding, 2.03 eV/atom. Replaced with the MgO/NaCl comparison.
4. **The bonding table gave ionic cohesive energy as 5–10 eV/atom.** That is the per-*ion-pair*
   figure; per atom NaCl is about 4.0 eV, which is comparable to silicon, not larger. The row now
   states both conventions.
5. **Topic 8 said the drift velocity is "about 2 × 10⁻¹¹ of v_F"** — it is 4.7 × 10⁻¹¹ — and called
   the gap "eleven orders of magnitude" where it is ten. Both fixed.
6. **Topic 9 called 220 lm/W a laboratory LED record.** It is a *commercial package* figure (Cree,
   31 March 2026) — and the P4PH page's own "do not claim" list rejects the unverified lab record.
   The sentence now draws the package-versus-installed contrast it was actually making.
7. **"Aluminium has a positive Hall coefficient"** is true only in the high-field limit; at low field
   it is about −3.4 × 10⁻¹¹ m³/C, which the free-electron model with three electrons per atom
   predicts almost exactly. Beryllium, zinc and cadmium are the unqualified examples, and are now
   what the text uses.
8. **"Every LED is built from a direct-gap material."** GaP:N and SiC indirect-gap emitters were once
   commercial. Now "every modern high-brightness LED", with the exception noted.
9. Topic 6 called silicon "monatomic" two paragraphs after using that word to mean one atom per
   primitive cell. Silicon has two. Now "non-polar elemental".
10. The Topic 1 summary table listed HCP as "2 points per cell" — those are atoms; HCP is one lattice
    point with a two-atom basis, which is the distinction the error box on the same page enforces.
11. Small slips: sin 21.66° is 0.36910 not 0.36917; 12π⁴/5 is 233.78, so "234 Nk_B" and "1944
    J/mol/K" were not consistent with each other.

**Every Calculation Corner number was then recomputed** — 71 values across the studio and the
question bank — and all agree with the text to within rounding.

---

## 4 · Editing content

Content is data, not markup. Each page is an object in `assets/js/content/`:

```js
window.PHY3201.pages.topic03 = {
  title: 'Wave Diffraction',
  navShort: 'Wave Diffraction',      // sidebar / stepper label
  accent: 'diffraction',             // structure | diffraction | bonding | phonon | electron
  hours: '3 lecture hours',
  weeks: 'Week 4',
  question: '…',                     // shown on the topic index cards
  eyebrow: ['Topic 03', '3 lecture hours', 'CLO1 · C4'],
  lede: '…',
  blocks: [ … ]
};
```

### Block types

Seventeen types. `person` was added for the developer credit.


| Type | Fields | Renders as |
|---|---|---|
| `h2` `h3` | `x` | heading (h2 gets an anchor id) |
| `p` | `x` | paragraph |
| `eq` | `x`, `note`, `tight` | monospace display equation with a note |
| `ul` `ol` | `items[]` | list |
| `callout` | `kind` (`key`\|`note`\|`warn`\|`stop`\|`ok`), `title`, `x` | coloured box |
| `error` | `claim`, `why` | the ✕ common-error block |
| `calc` | `title`, `known`, `find`, `equation`, `substitution`, `answer`, `meaning` | Calculation Corner |
| `table` | `head[]`, `rows[][]`, `caption` | table (prefix a heading with `~` for a right-aligned numeric column) |
| `diagram` | `id`, `label`, `caption` | an SVG from `diagrams.js` |
| `image` | `src`, `alt`, `label`, `caption` | a raster figure |
| `person` | `kicker`, `name`, `role`, `affil`, `src`, `alt`, `x` | a credit card: portrait beside name and affiliation |
| `check` | `q`, `options[]`, `answer`, `why` | inline self-check |
| `read` | `items[{book, where}]` | the "Where to read more" panel |
| `widget` | `id`, `title` | mounts an explorer from `widgets.js` |
| `grid` | `cols` (2\|3\|4\|5), `cards[{k,big,h,x,href}]` | card grid |
| `topicgrid` | — | the nine topic cards |
| `hr` | — | rule |
| `html` | `x` | raw HTML (no `<script>` — it will not execute) |

Inline markup inside any string: `**bold**`, `*italic*`, `` `code` ``, `[text](#route)`.
Everything is escaped first, so content cannot inject markup by accident.

### Adding a practice question

Append to `window.PHY3201.practiceBank` in `assets/js/content/practice.js`:

```js
{ id:'T5-F4', topic:5, topicName:'Crystal Bonding', level:'Foundation',
  type:'Calculation', clo:'CLO1', prompt:'…',
  workspace:'…', hint1:'…', hint2:'…',
  solution:'…', equation:'…', meaning:'…' }
```
Add `options:[…]` and `answerIndex:n` for a multiple-choice question. It appears in the hub
automatically and the filters pick it up.

### Adding a glossary term

Add a key to `window.PHY3201.glossary` in `glossary.js`. It is auto-linked on its **first**
occurrence in each page. Auto-linking deliberately skips headings, links, code, equation bodies,
anything inside an `<svg>`, practice-question cards, and any element with class `noglos`.

### Adding a diagram

Add `D['my-id'] = function () { … return svg(500, height, body); }` in `diagrams.js`, then place
`{ t:'diagram', id:'my-id', label:'Figure 6.6', caption:'…' }` in a content file.

Helpers: `tx()` single label · `txw(x,y,s,charsPerLine,o)` wrapped label ·
**`txfit(x,y,s,{w:availablePixels,…})`** wrap to a pixel width — use this for anything long ·
`bx()` rounded box that wraps its own text and grows to fit · `arr()` labelled arrow ·
`ln()` `dot()` `ring()` `path()` `rect()` `ax()` axes · `fn()` sample a function to a polyline.

`bx()` and `txfit()` wrap using a character-width estimate that is deliberately conservative, so
the diagrams still hold if Inter fails to load and a wider fallback font is substituted.
**Preserve that if you edit the file.** After adding or editing a diagram, re-check that no label
escapes its viewBox — see §5.

---

## 5 · Verification

Everything below was checked before release and is worth re-running after edits.

- **All 15 routes render** with no console errors and no unresolved block or widget types.
- **All 41 diagrams** produce valid SVG with no `NaN` / `undefined` in the output.
- **No SVG label overflows its viewBox**, horizontally or vertically (43 overflows were found and
  fixed during the build; the auto-fit pass in the height values reflects that).
- **Every widget control was exercised** — sliders driven to both ends and the midpoint, every
  segmented button clicked, every numeric input given 0/1/3/−2/4 — with no NaN in any readout.
- **No horizontal page scroll** at 1280 px or at 390 px.
- **Every number in a Calculation Corner was computed** in Python and compared with a published
  value; where the model is a few percent off, the discrepancy is stated and explained rather than
  hidden.
- **The offline build makes zero network requests.**

Two bugs the browser tests caught and that are worth knowing about if you edit `app.js`:

1. The glossary auto-linker was injecting HTML `<span>` elements inside `<svg>` elements, which
   silently swallowed diagram labels. `nodeName` is lower-case for SVG elements, so the skip list
   must be compared case-insensitively — and the linker now rejects anything in the SVG namespace
   outright.
2. The linker's DOM surgery used `parent.insertBefore(span, parent.lastChild)`, which misplaces the
   term whenever the paragraph has more than one child node. It now rebuilds the text node with a
   document fragment.

---

## 6 · Gotchas

- **Script order in `index.html` is fixed:** `glossary.js` → `diagrams.js` → content → `widgets.js`
  → `app.js`. `glossary.js` also creates `window.PHY3201.pages`, which every content file writes
  into, so it must load first.
- **`build-single-file.py` has its own `JS_FILES` list.** Any new script added to `index.html`
  must be added there too, or it will be missing from the offline build.
- **Light-only by design.** These pages are projected and printed; `color-scheme: light` is set
  explicitly. There is no dark theme.
- **`localStorage`** holds topic-visited progress and the P4PH planner draft. Both are wrapped in
  `try/catch` and degrade silently in private-browsing mode.

---

## 7 · The UPM logo

**Installed.** The official mark ships in three forms:

| File | Size | Used for |
|---|---|---|
| `assets/img/upm-shield.png` | 98 × 108 | **The brand bar** — the shield at 38px, with the university name beside it in type |
| `assets/img/upm-logo.png` | 288 × 132 | The full horizontal lockup, trimmed to content. Not used by default — see below |
| `assets/img/upm-logo-original.png` | 3543 × 2126 | The untouched original as supplied, kept as the master |

### Why the brand bar uses the shield rather than the full lockup

The full horizontal lockup is a letterhead asset. Measured against the supplied file, the two
lower lines occupy 6.2 % and 9.0 % of the lockup's height — so at a 44px header they render at
**2.7px and 3.9px**, which is mud, not type. Enlarging the bar does not rescue it: even at 54px the
"UNIVERSITI PUTRA MALAYSIA" line is 3.3px.

The brand bar therefore uses the standard small-size configuration: **the official shield,
unmodified, at 38px, with the university name set in the page's own type beside it.** Nothing is
redrawn or approximated — it is the same official artwork, cropped at the gutter the lockup itself
provides between symbol and wordmark.

**To use the full lockup anyway**, in `index.html`: point `src` at `assets/img/upm-logo.png`, set
`width="288" height="132"`, and delete the `brandbar__univ` span from inside the link. Then re-run
both build scripts.

### After changing anything in `assets/img/`

Re-run **both** `python3 build-single-file.py` and `python3 build-artifact.py`. Each inlines every
local image as a base64 data URI.

> **This matters more than it sounds.** An artifact is served from its own origin with no
> accompanying asset folder, so a relative `src` silently 404s. That is exactly why the published
> **PHY4230** studio showed a broken image where its logo should have been: the file was referenced
> as `assets/img/upm-logo.png` and never inlined, with no `onerror` fallback. `build-artifact.py`
> now inlines images *and* aborts the build if any `assets/…` reference survives, so the same
> mistake cannot be made here twice.

The `<img>` also carries an `onerror` that removes it and unhides `#brandMark` — a lattice glyph
plus the university name in type. That fallback is deliberately **not** an invented crest, and it
should not be replaced with one; a look-alike of a real university's mark is worse than no mark.

## 8 · Course data — do not alter without checking the source documents

**CLOs and programme mapping** (Assessment Plan and CAP/COPO, Semester 1 2026/2027):

- **CLO1** Describe material properties from atomic arrangement and crystal bonding · C4 · **PO1** · 60 %
- **CLO2** Relate crystal structure to material properties · CTPS · **PO3** · 20 %
- **CLO3** Explain fundamental concepts and technologies based on solid state physics · A3 / LL · **PO7** · 20 %

**Assessment:** Test 1 15 % (Week 6) · Test 2 15 % (Week 10) · Continuous assessment 10 % (Weeks 2–13)
· PBL 20 % (Weeks 2–14) · Final assessment 40 %. Coursework 60 % + final 40 %.

**PBL internal split:** physics accuracy 5 · planetary-health analysis 4 · communication 3 ·
evidence 2 · engagement 1 · individual micro-viva 3 · individual reflection 2 = 20 %.

---

## 9 · Reference-list corrections

Three of the five prescribed references do not match a book that exists as cited. Details and
sources are on the **References** page of the studio and in the project note
`claude/PHY3201-reference-and-fact-check-notes.md`. In brief:

1. **Kittel** — the Global Edition is the **8th-edition text**, ISBN 978-1-119-45416-8. Do not
   print "9th ed.". Kittel has **no numbered sections**; cite the chapter and the subheading name.
2. **Ashcroft & Mermin** — there is no "2nd ed. (2019)". The Cengage Asia book is
   **Ashcroft, Mermin & Wei (2016), Revised ed., ISBN 978-981-4369-89-3**, 35 chapters, renumbered.
3. **Lawrence (2019)** — editor rather than author; no discoverable table of contents; zero holdings
   in the K10plus union catalogue; publisher domain does not resolve. **Recommend removing it.**

Also add **Callister & Rethwisch, *Materials Science and Engineering*, Ch. 3** as a supplementary
text: atomic packing fraction, planar density and volume density — the second half of the
six-hour Topic 2 — have no named coverage in any of the four verifiable prescribed books.

## 10 · Claims deliberately avoided

The References page carries a "do not claim" list of figures that circulate widely and could not be
verified, or that are commonly misquoted (the 104 K diamond conductivity value presented as room
temperature, the AM1.5G Shockley–Queisser number presented as the 1961 result, the Malaysian
semiconductor market share, and others). **Please preserve that list when editing.** Re-check the
technology figures each semester; the physics does not age, but the records do.

---

## 11 · The colour system

The palette is sampled from the official UPM artwork, which contains exactly three colours:
crimson **#C8244B** (55 % of non-white pixels), warm grey **#939090** (36 %) and the wordmark
black **#35363A** (3 %). **There is no navy in the UPM logo.** The navy this studio used in its
first build came from the PHY4230 figure set, not from the university identity; it has been
replaced. The tokens and their measured contrast ratios on white are documented at the top of
`assets/css/styles.css` — do not edit a colour there without re-running the contrast check, which
requires 4.5:1 for body text and 3:1 for large text (WCAG AA).

Five colours are reserved for the **topic strands** and mean nothing else:

| strand | token | pages |
|---|---|---|
| structure | `--structure` #1B5AAE | Topics 1–2 |
| diffraction | `--diffraction` #6B3FA0 | Topics 3–4 |
| bonding | `--bonding` #147A5E | Topic 5 |
| phonon | `--phonon` #A85F12 | Topics 6–7 |
| electron | `--electron` #0B6C86 | Topics 8–9 |

Every page that is **not** a topic — course home, the 14-week map, the assessment hub, the P4PH
brief, the Practice Hub and References — carries `accent: 'brand'`, which paints the rule in UPM
crimson. That is what keeps the five strand colours legible as a code rather than decoration. A
new non-topic page should use `'brand'`, not a borrowed strand colour.

The question bank (`qbank/make_html.py`) carries the same tokens so the two deliverables match.

## 12 · Diagram layout — the wrapping trap

`assets/js/diagrams.js` hand-writes SVG with absolute coordinates, and `txfit(x, y, s, {w})`
wraps a label to a pixel width. **Changing a label's text or size can change its line count, and
every coordinate below it is hard-coded** — that is how a one-line title silently becomes two
lines and lands on the artwork. After any edit to that file, run all three checks:

```bash
node svgv.mjs      # no text outside any viewBox
node measure.mjs   # every svg() height still matches its content
node sheet.mjs     # re-render all 41 diagrams to shots/dg/ and LOOK at them
```

The first two are necessary and not sufficient: a label can sit fully inside the viewBox and
still be printed across a curve. The contact sheet is the check that catches that, and it has to
be read by eye.

---

## 13 · Images referenced from content blocks

`index.html` carries the only `<img>` tag written by hand (the UPM shield). Every other image
enters through a **content block** — the `person` and `image` types — where the `src` is a plain
`assets/img/...` path held inside a JavaScript string.

Both bundlers therefore run **two** image passes: one over `<img src="…">` tags, and one over any
bare `assets/img/<file>.<ext>` string anywhere in the output, including inside the concatenated JS.
Without the second pass the portrait would 404 in the offline file and in the artifact — an artifact
is served from its own origin with no asset folder beside it. Both builds then hard-fail if any
`src=`/`href=` attribute or bare `assets/img/…` path survives, so this cannot regress silently.

To add another photo: drop the file in `assets/img/`, reference it by that path from a block, and
re-run `build-single-file.py`. Nothing else needs changing. Keep the file small — it is base64-encoded
into every build, which inflates it by about a third; the 360 × 360 portrait costs 15 KB.
