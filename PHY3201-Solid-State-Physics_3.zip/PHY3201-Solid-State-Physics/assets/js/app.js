/* PHY3201 Course Studio — router, block renderer, navigation, progress.
   Content lives in assets/js/content/*.js as arrays of block objects.
   To change the sidebar grouping, edit NAV below.
   To change the order of the Week-1 introduction, edit INTRO below. */
(function () {
  'use strict';
  var S = window.PHY3201 = window.PHY3201 || {};
  S.pages = S.pages || {};

  /* ── navigation model ─────────────────────────────────────── */
  var INTRO = ['home', 'map', 'assessment', 'p4ph'];

  var NAV = [
    { label: 'Week 1 · Course introduction', items: [
      { id: 'home',       t: 'Course home' },
      { id: 'map',        t: '14-week teaching map' },
      { id: 'assessment', t: 'Assessment hub' },
      { id: 'p4ph',       t: 'Physics for Planetary Health' }
    ]},
    { label: 'Structure · Weeks 1–3', items: [
      { id: 'topic01', t: 'Crystal Structure', n: '3 h' },
      { id: 'topic02', t: 'Crystal Analysis', n: '6 h' }
    ]},
    { label: 'Diffraction · Weeks 4–5', items: [
      { id: 'topic03', t: 'Wave Diffraction', n: '3 h' },
      { id: 'topic04', t: 'Amplitude Wave Scattering', n: '3 h' }
    ]},
    { label: 'Binding · Weeks 6–7', items: [
      { id: 'topic05', t: 'Crystal Bonding', n: '6 h' }
    ]},
    { label: 'Lattice dynamics · Weeks 8–11', items: [
      { id: 'topic06', t: 'Phonons I', n: '6 h' },
      { id: 'topic07', t: 'Phonons II', n: '6 h' }
    ]},
    { label: 'Electrons · Weeks 12–14', items: [
      { id: 'topic08', t: 'Free Electrons and Fermi Gas', n: '6 h' },
      { id: 'topic09', t: 'Band Theory', n: '3 h' }
    ]},
    { label: 'Practice and reference', items: [
      { id: 'practice',   t: 'Practice hub' },
      { id: 'references', t: 'References and glossary' }
    ]}
  ];

  var TOPIC_IDS = ['topic01','topic02','topic03','topic04','topic05','topic06','topic07','topic08','topic09'];

  /* linear reading order: introduction, then the nine topics, then practice */
  var ORDER = INTRO.concat(TOPIC_IDS, ['practice', 'references']);

  /* ── progress (localStorage, best-effort) ─────────────────── */
  var KEY = 'phy3201.visited.v1';
  function readVisited() {
    try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; }
  }
  function writeVisited(v) {
    try { localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { /* private mode */ }
  }
  var visited = readVisited();

  function updateProgress() {
    var done = TOPIC_IDS.filter(function (id) { return visited[id]; }).length;
    var el = document.getElementById('progCount');
    var bar = document.getElementById('progBar');
    if (el) el.textContent = done + ' / ' + TOPIC_IDS.length;
    if (bar) bar.style.width = (done / TOPIC_IDS.length * 100).toFixed(1) + '%';
    Array.prototype.forEach.call(document.querySelectorAll('.nav a'), function (a) {
      a.classList.toggle('done', !!visited[a.dataset.id]);
    });
  }

  /* ── small helpers ────────────────────────────────────────── */
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  /* Inline markup permitted inside content strings: **bold**, *italic*, `code`,
     [text](#route) and the raw entities the physics needs. Escaped first, so
     content authors cannot inject markup by accident. */
  function md(s) {
    return esc(s)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>')
      .replace(/\[([^\]]+)\]\((#[^)]+)\)/g, '<a href="$2">$1</a>');
  }
  S.md = md; S.esc = esc;

  function slug(s) {
    return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  /* ── block renderer ───────────────────────────────────────── */
  var R = {};

  R.h2 = function (b) { return '<h2 id="' + slug(b.x) + '">' + md(b.x) + '</h2>'; };
  R.h3 = function (b) { return '<h3>' + md(b.x) + '</h3>'; };
  R.p  = function (b) { return '<p>' + md(b.x) + '</p>'; };
  R.hr = function () { return '<hr class="rule">'; };

  R.eq = function (b) {
    return '<div class="eq' + (b.tight ? ' eq--tight' : '') + '">' +
      '<div class="eq__body">' + esc(b.x) + '</div>' +
      (b.note ? '<div class="eq__note">' + md(b.note) + '</div>' : '') + '</div>';
  };

  R.ul = function (b) {
    return '<ul>' + b.items.map(function (i) { return '<li>' + md(i) + '</li>'; }).join('') + '</ul>';
  };
  R.ol = function (b) {
    return '<ol>' + b.items.map(function (i) { return '<li>' + md(i) + '</li>'; }).join('') + '</ol>';
  };

  R.callout = function (b) {
    var icon = { key: '◆', note: '·', warn: '!', stop: '✕', ok: '✓' }[b.kind || 'note'];
    return '<div class="callout callout--' + (b.kind || 'note') + '">' +
      (b.title ? '<div class="callout__title"><span aria-hidden="true">' + icon + '</span>' + md(b.title) + '</div>' : '') +
      '<p>' + md(b.x) + '</p></div>';
  };

  R.error = function (b) {
    return '<div class="errbox"><div class="errbox__claim">' + md(b.claim) + '</div>' +
      '<div class="errbox__why">' + md(b.why) + '</div></div>';
  };

  R.calc = function (b) {
    function row(k, v, cls) {
      if (!v) return '';
      return '<div class="calc__row' + (cls || '') + '"><div class="calc__k">' + k + '</div>' +
        '<div class="calc__v">' + (/\n|=/.test(v) && k !== 'Meaning' ? '<span class="m">' + esc(v) + '</span>' : md(v)) + '</div></div>';
    }
    return '<div class="calc"><div class="calc__head"><span class="tag">Calculation corner</span>' + md(b.title) + '</div>' +
      row('Known', b.known) + row('Find', b.find) + row('Equation', b.equation) +
      row('Substitution', b.substitution) + row('Answer', b.answer, ' calc__row--answer') +
      row('Meaning', b.meaning) + '</div>';
  };

  R.table = function (b) {
    var h = '<thead><tr>' + b.head.map(function (c) {
      return '<th' + (/^~/.test(c) ? ' class="num"' : '') + '>' + md(String(c).replace(/^~/, '')) + '</th>';
    }).join('') + '</tr></thead>';
    var body = '<tbody>' + b.rows.map(function (r) {
      return '<tr>' + r.map(function (c, i) {
        return '<td' + (/^~/.test(b.head[i]) ? ' class="num"' : '') + '>' + md(c) + '</td>';
      }).join('') + '</tr>';
    }).join('') + '</tbody>';
    return '<div class="tablewrap"><table>' + h + body + '</table></div>' +
      (b.caption ? '<div class="figure__cap">' + md(b.caption) + '</div>' : '');
  };

  R.diagram = function (b) {
    var svg = (S.diagrams && S.diagrams[b.id]) ? S.diagrams[b.id]() : '';
    if (!svg) svg = '<div class="empty">Diagram <code>' + esc(b.id) + '</code> is not defined.</div>';
    return '<figure class="figure"><div class="figure__frame">' + svg + '</div>' +
      (b.caption ? '<figcaption class="figure__cap"><b>' + md(b.label || 'Figure') + '.</b> ' + md(b.caption) + '</figcaption>' : '') +
      '</figure>';
  };

  R.image = function (b) {
    return '<figure class="figure"><div class="figure__frame">' +
      '<img src="' + esc(b.src) + '" alt="' + esc(b.alt || '') + '"></div>' +
      (b.caption ? '<figcaption class="figure__cap"><b>' + md(b.label || 'Figure') + '.</b> ' + md(b.caption) + '</figcaption>' : '') +
      '</figure>';
  };

  /* person — a credit card: portrait beside name, role and affiliation.
     `src` is a plain assets/img path; both bundlers rewrite it to a data URI, because an
     artifact is served from its own origin and a relative path would 404 there. */
  R.person = function (b) {
    return '<div class="person">' +
      (b.src ? '<img class="person__photo" src="' + esc(b.src) + '" alt="' + esc(b.alt || b.name || '') + '" width="132" height="132" decoding="async">' : '') +
      '<div class="person__body">' +
      (b.kicker ? '<span class="person__kicker">' + md(b.kicker) + '</span>' : '') +
      '<span class="person__name">' + md(b.name || '') + '</span>' +
      (b.role ? '<span class="person__role">' + md(b.role) + '</span>' : '') +
      (b.affil ? '<span class="person__affil">' + md(b.affil) + '</span>' : '') +
      (b.x ? '<p class="person__note">' + md(b.x) + '</p>' : '') +
      '</div></div>';
  };

  R.check = function (b, i) {
    var opts = b.options.map(function (o, k) {
      return '<button class="opt" data-k="' + k + '"><span class="k">' + 'ABCD'[k] + '</span><span>' + md(o) + '</span></button>';
    }).join('');
    return '<div class="check" data-check="' + i + '" data-answer="' + b.answer + '">' +
      '<div class="check__q">' + md(b.q) + '</div>' +
      '<div class="check__opts">' + opts + '</div>' +
      '<div class="check__why hidden">' + md(b.why) + '</div></div>';
  };

  R.read = function (b) {
    return '<div class="read"><div class="read__t">Where to read more</div><ul>' +
      b.items.map(function (i) { return '<li><b>' + md(i.book) + '</b><span>' + md(i.where) + '</span></li>'; }).join('') +
      '</ul></div>';
  };

  R.widget = function (b) {
    return '<div class="widget" data-widget="' + esc(b.id) + '">' +
      '<div class="widget__head"><span class="widget__tag">Explore</span>' +
      '<span class="widget__title">' + md(b.title || b.id) + '</span></div>' +
      '<div class="widget__body" data-widget-body="' + esc(b.id) + '"></div></div>';
  };

  R.grid = function (b) {
    return '<div class="grid grid--' + (b.cols || 2) + '">' + b.cards.map(function (c) {
      var inner = (c.k ? '<div class="card__k">' + md(c.k) + '</div>' : '') +
        (c.big ? '<div class="card__big">' + md(c.big) + '</div>' : '') +
        (c.h ? '<h3>' + md(c.h) + '</h3>' : '') +
        (c.x ? '<p>' + md(c.x) + '</p>' : '');
      return c.href ? '<a class="card card--link" href="' + esc(c.href) + '">' + inner + '</a>'
                    : '<div class="card">' + inner + '</div>';
    }).join('') + '</div>';
  };

  R.topicgrid = function (b) {
    var accents = { structure: 'var(--structure)', diffraction: 'var(--diffraction)',
                    bonding: 'var(--bonding)', phonon: 'var(--phonon)', electron: 'var(--electron)' };
    return '<div class="grid grid--2">' + TOPIC_IDS.map(function (id, i) {
      var p = S.pages[id]; if (!p) return '';
      return '<a class="tcard" href="#' + id + '">' +
        '<span class="tcard__n" style="background:' + (accents[p.accent] || 'var(--navy-500)') + '">' + (i + 1) + '</span>' +
        '<span><span class="tcard__t">' + md(p.title) + '</span>' +
        '<span class="tcard__m">' + md(p.hours || '') + (p.weeks ? ' · ' + md(p.weeks) : '') + '</span>' +
        '<span class="tcard__d">' + md(p.question || '') + '</span></span></a>';
    }).join('') + '</div>';
  };

  R.html = function (b) { return b.x; };

  function renderBlocks(blocks) {
    var checkIdx = 0;
    return blocks.map(function (b) {
      var fn = R[b.t];
      if (!fn) return '<div class="empty">Unknown block type <code>' + esc(b.t) + '</code></div>';
      return fn(b, b.t === 'check' ? checkIdx++ : 0);
    }).join('');
  }
  S.renderBlocks = renderBlocks;

  /* ── glossary auto-linking ────────────────────────────────── */
  function linkGlossary(root) {
    var G = S.glossary; if (!G) return;
    var terms = Object.keys(G).sort(function (a, b) { return b.length - a.length; });
    if (!terms.length) return;
    var rx = new RegExp('\\b(' + terms.map(function (t) {
      return t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }).join('|') + ')\\b', 'i');

    /* nodeName is lower-case for SVG elements, so compare case-insensitively —
       linking inside an <svg> injects an HTML <span> that silently eats the label. */
    var skip = { A: 1, CODE: 1, SCRIPT: 1, STYLE: 1, H1: 1, H2: 1, H3: 1, BUTTON: 1 };
    var SVGNS = 'http://www.w3.org/2000/svg';
    var seen = {};
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        var p = n.parentNode;
        while (p && p !== root) {
          if (p.namespaceURI === SVGNS) return NodeFilter.FILTER_REJECT;
          if (skip[String(p.nodeName).toUpperCase()]) return NodeFilter.FILTER_REJECT;
          if (p.classList && (p.classList.contains('eq__body') ||
                              p.classList.contains('q') ||        /* practice questions */
                              p.classList.contains('noglos'))) return NodeFilter.FILTER_REJECT;
          p = p.parentNode;
        }
        return rx.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);

    nodes.forEach(function (node) {
      var m = rx.exec(node.nodeValue);
      if (!m) return;
      var key = terms.find(function (t) { return t.toLowerCase() === m[1].toLowerCase(); });
      if (!key || seen[key.toLowerCase()]) return;   /* first occurrence only */
      seen[key.toLowerCase()] = 1;
      var span = document.createElement('span');
      span.className = 'gterm'; span.textContent = m[1];
      span.setAttribute('tabindex', '0');
      span.dataset.term = key;
      span.setAttribute('aria-label', key + ': ' + G[key]);
      /* rebuild the text node as before + <span> + after, in place */
      var frag = document.createDocumentFragment();
      frag.appendChild(document.createTextNode(node.nodeValue.slice(0, m.index)));
      frag.appendChild(span);
      frag.appendChild(document.createTextNode(node.nodeValue.slice(m.index + m[1].length)));
      node.parentNode.replaceChild(frag, node);
    });
  }

  var pop, popTerm;
  function placePop(el) {
    if (!pop) return;
    var r = el.getBoundingClientRect();
    var top = r.bottom + window.scrollY + 7;
    var left = Math.min(r.left + window.scrollX, window.innerWidth - pop.offsetWidth - 14);
    pop.style.top = top + 'px'; pop.style.left = Math.max(8, left) + 'px';
  }
  function showPop(el) {
    hidePop();
    var G = S.glossary, key = el.dataset.term;
    if (!G || !G[key]) return;
    pop = document.createElement('div');
    pop.className = 'gpop';
    pop.innerHTML = '<b>' + esc(key) + '</b>' + esc(G[key]);
    document.body.appendChild(pop);
    popTerm = el;
    placePop(el);
  }
  function hidePop() { if (pop) { pop.remove(); pop = null; } popTerm = null; }

  document.addEventListener('mouseover', function (e) {
    var t = e.target.closest && e.target.closest('.gterm'); if (t) showPop(t);
  });
  document.addEventListener('mouseout', function (e) {
    if (e.target.closest && e.target.closest('.gterm')) hidePop();
  });
  document.addEventListener('focusin', function (e) {
    var t = e.target.closest && e.target.closest('.gterm'); if (t) showPop(t);
  });
  document.addEventListener('focusout', hidePop);
  window.addEventListener('scroll', function () {
    if (popTerm && document.contains(popTerm)) placePop(popTerm); else hidePop();
  }, { passive: true });

  /* ── inline checks ────────────────────────────────────────── */
  document.addEventListener('click', function (e) {
    var opt = e.target.closest && e.target.closest('.check .opt');
    if (!opt) return;
    var box = opt.closest('.check');
    var ans = Number(box.dataset.answer);
    Array.prototype.forEach.call(box.querySelectorAll('.opt'), function (o, i) {
      o.disabled = true;
      if (i === ans) o.classList.add('is-right');
      else if (o === opt) o.classList.add('is-wrong');
    });
    box.querySelector('.check__why').classList.remove('hidden');
  });

  /* ── navigation build ─────────────────────────────────────── */
  function buildNav() {
    var root = document.getElementById('navRoot');
    root.innerHTML = NAV.map(function (g) {
      return '<div class="navgroup"><div class="navgroup__label">' + esc(g.label) + '</div></div>' +
        g.items.map(function (it) {
          return '<a href="#' + it.id + '" data-id="' + it.id + '">' +
            '<span class="dot"></span><span style="flex:1">' + esc(it.t) + '</span>' +
            (it.n ? '<span class="num">' + esc(it.n) + '</span>' : '') + '</a>';
        }).join('');
    }).join('');
  }

  /* ── page render ──────────────────────────────────────────── */
  function pagerFor(id) {
    var i = ORDER.indexOf(id);
    if (i < 0) return '';
    var prev = ORDER[i - 1], next = ORDER[i + 1];
    var out = '<div class="pager">';
    if (prev && S.pages[prev]) out += '<a href="#' + prev + '"><span class="pager__k">Previous</span>' +
      '<span class="pager__t">' + esc(S.pages[prev].title) + '</span></a>';
    if (next && S.pages[next]) out += '<a class="next" href="#' + next + '"><span class="pager__k">Next</span>' +
      '<span class="pager__t">' + esc(S.pages[next].title) + '</span></a>';
    return out + '</div>';
  }

  function introStepper(id) {
    var i = INTRO.indexOf(id);
    if (i < 0) return '';
    return '<div class="grid grid--4" style="margin:0 0 20px">' + INTRO.map(function (pid, k) {
      var p = S.pages[pid]; if (!p) return '';
      var on = pid === id;
      return '<a class="card card--link" href="#' + pid + '" style="' +
        (on ? 'border-color:var(--navy);background:#F3F6FC' : '') + '">' +
        '<div class="card__k">Step ' + (k + 1) + '</div>' +
        '<div style="font-weight:700;color:var(--navy);font-size:14.5px;line-height:1.3;margin-top:2px">' +
        esc(p.navShort || p.title) + '</div></a>';
    }).join('') + '</div>';
  }

  function render(id) {
    var p = S.pages[id];
    var view = document.getElementById('view');
    if (!p) {
      view.innerHTML = '<h1>Page not found</h1><p>No page is registered for <code>' + esc(id) +
        '</code>. <a href="#home">Return to the course home</a>.</p>';
      return;
    }
    var head = '<div class="accentbar"></div>' +
      (p.eyebrow ? '<div class="eyebrow">' + p.eyebrow.map(function (c, i) {
        return i === 0 ? '<span class="chip">' + esc(c) + '</span>' : '<span>' + esc(c) + '</span>';
      }).join('') + '</div>' : '') +
      '<h1>' + md(p.title) + '</h1>' +
      (p.lede ? '<p class="lede">' + md(p.lede) + '</p>' : '');

    view.setAttribute('data-accent', p.accent || '');
    view.innerHTML = head + introStepper(id) + renderBlocks(p.blocks || []) + pagerFor(id);

    /* mount widgets */
    Array.prototype.forEach.call(view.querySelectorAll('[data-widget-body]'), function (el) {
      var name = el.getAttribute('data-widget-body');
      var w = S.widgets && S.widgets[name];
      if (w) { try { w(el); } catch (err) { el.innerHTML = '<div class="empty">Widget error: ' + esc(err.message) + '</div>'; } }
      else el.innerHTML = '<div class="empty">Widget <code>' + esc(name) + '</code> is not defined.</div>';
    });

    linkGlossary(view);

    /* nav state */
    Array.prototype.forEach.call(document.querySelectorAll('.nav a'), function (a) {
      a.classList.toggle('is-active', a.dataset.id === id);
    });

    if (TOPIC_IDS.indexOf(id) >= 0 && !visited[id]) { visited[id] = 1; writeVisited(visited); }
    updateProgress();

    document.body.classList.remove('nav-open');
    var sc = document.querySelector('.scrim'); if (sc) sc.remove();
    window.scrollTo(0, 0);
    view.focus({ preventScroll: true });
    document.title = p.title + ' · PHY3201 Solid State Physics';
  }

  function route() {
    var id = (location.hash || '#home').slice(1).split('?')[0];
    render(S.pages[id] ? id : 'home');
  }

  /* ── mobile nav ───────────────────────────────────────────── */
  document.getElementById('menuBtn').addEventListener('click', function () {
    var open = document.body.classList.toggle('nav-open');
    this.setAttribute('aria-expanded', String(open));
    if (open) {
      var s = document.createElement('div'); s.className = 'scrim';
      s.addEventListener('click', function () { document.body.classList.remove('nav-open'); s.remove(); });
      document.body.appendChild(s);
    } else { var sc = document.querySelector('.scrim'); if (sc) sc.remove(); }
  });

  /* ── boot ─────────────────────────────────────────────────── */
  buildNav();
  updateProgress();
  window.addEventListener('hashchange', route);
  route();

  S.render = render; S.ORDER = ORDER; S.TOPIC_IDS = TOPIC_IDS; S.NAV = NAV; S.INTRO = INTRO;
})();
