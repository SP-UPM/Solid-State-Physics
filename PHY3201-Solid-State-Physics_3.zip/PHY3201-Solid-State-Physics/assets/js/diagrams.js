/* PHY3201 — hand-authored SVG mechanism diagrams.
   Every diagram is drawn to show a MECHANISM, not to name parts.
   Colours use CSS custom properties so the diagrams stay in step with the palette.

   Helpers
     svg(w,h,body)      viewBox-scaled responsive frame
     tx(x,y,s,o)        single-line label            o: {size,fill,anchor,weight,style}
     txw(x,y,s,w,o)     wrapped label, w = chars per line
     bx(x,y,w,h,s,o)    rounded box whose text wraps and which grows to fit
     arr(x1,y1,x2,y2,o) arrow, optionally labelled   o: {label,dash,color,curve}
     ax(...)            a labelled pair of axes
   bx() wraps its own text so the diagrams still hold if Inter fails to load and a
   wider fallback font is substituted. Preserve that if you edit this file. */
(function () {
  'use strict';
  var D = {};
  var C = {
    ink: 'var(--ink)', ink2: 'var(--ink-2)', ink3: 'var(--ink-3)',
    navy: 'var(--navy)', blue: 'var(--structure)', purple: 'var(--diffraction)',
    green: 'var(--bonding)', amber: 'var(--phonon)', cyan: 'var(--electron)',
    crimson: 'var(--crimson)', rule: 'var(--rule)', paper: 'var(--paper)', paper2: 'var(--paper-2)'
  };
  D.C = C;

  function svg(w, h, body) {
    return '<svg viewBox="0 0 ' + w + ' ' + h + '" width="' + w + '" height="' + h +
      '" role="img" style="max-width:100%;height:auto;font-family:var(--sans)" ' +
      'xmlns="http://www.w3.org/2000/svg">' +
      '<defs>' +
        '<marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">' +
          '<path d="M0,0 L10,5 L0,10 z" fill="context-stroke"/></marker>' +
      '</defs>' + body + '</svg>';
  }

  function tx(x, y, s, o) {
    o = o || {};
    return '<text x="' + x + '" y="' + y + '" font-size="' + (o.size || 12) + '" fill="' + (o.fill || C.ink2) +
      '" text-anchor="' + (o.anchor || 'start') + '" font-weight="' + (o.weight || 500) + '"' +
      (o.style ? ' font-style="' + o.style + '"' : '') +
      (o.mono ? ' font-family="var(--mono)"' : '') + '>' + s + '</text>';
  }

  function wrap(s, n) {
    var words = String(s).split(/\s+/), lines = [], cur = '';
    words.forEach(function (w) {
      if (!cur) { cur = w; }
      else if ((cur + ' ' + w).length <= n) { cur += ' ' + w; }
      else { lines.push(cur); cur = w; }
    });
    if (cur) lines.push(cur);
    return lines;
  }

  function txw(x, y, s, n, o) {
    o = o || {};
    var size = o.size || 12, lh = o.lh || size * 1.28;
    return wrap(s, n).map(function (l, i) {
      return tx(x, y + i * lh, l, o);
    }).join('');
  }

  /* wrap to fit an available PIXEL width, honouring text-anchor.
     Use this for any label long enough to risk running past the viewBox. */
  function txfit(x, y, s, o) {
    o = o || {};
    var size = o.size || 12, avail = o.w || 200;
    /* bold faces are wider per character than regular ones */
    var per = (o.weight && o.weight >= 700) ? 0.585 : 0.548;
    var cpl = Math.max(8, Math.floor(avail / (size * per)));
    return txw(x, y, s, cpl, o);
  }

  function bx(x, y, w, s, o) {
    o = o || {};
    var size = o.size || 11.5, pad = o.pad || 8, cpl = Math.max(6, Math.floor((w - 2 * pad) / (size * 0.60)));
    var lines = wrap(s, cpl), lh = size * 1.3;
    var h = o.h || Math.max(o.minh || 26, lines.length * lh + 2 * pad - 4);
    var body = '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (o.rx || 7) +
      '" fill="' + (o.fill || C.paper) + '" stroke="' + (o.stroke || C.rule) + '" stroke-width="' + (o.sw || 1.2) + '"/>';
    var ty = y + h / 2 - (lines.length - 1) * lh / 2 + size * 0.35;
    body += lines.map(function (l, i) {
      return tx(x + w / 2, ty + i * lh, l, { size: size, fill: o.color || C.ink2, anchor: 'middle', weight: o.weight || 600 });
    }).join('');
    return body;
  }

  function arr(x1, y1, x2, y2, o) {
    o = o || {};
    var col = o.color || C.ink3, out = '';
    if (o.curve) {
      var mx = (x1 + x2) / 2 + (o.curve || 0), my = (y1 + y2) / 2 - Math.abs(o.curve || 0) * 0.6;
      out += '<path d="M' + x1 + ',' + y1 + ' Q' + mx + ',' + my + ' ' + x2 + ',' + y2 + '" fill="none" stroke="' + col +
        '" stroke-width="' + (o.w || 1.6) + '"' + (o.dash ? ' stroke-dasharray="' + o.dash + '"' : '') +
        (o.noHead ? '' : ' marker-end="url(#ah)"') + '/>';
    } else {
      out += '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" stroke="' + col +
        '" stroke-width="' + (o.w || 1.6) + '"' + (o.dash ? ' stroke-dasharray="' + o.dash + '"' : '') +
        (o.noHead ? '' : ' marker-end="url(#ah)"') + (o.both ? ' marker-start="url(#ah)"' : '') + '/>';
    }
    if (o.label) {
      var lx = (x1 + x2) / 2 + (o.lx || 0), ly = (y1 + y2) / 2 + (o.ly || -6);
      out += tx(lx, ly, o.label, { size: o.lsize || 11, fill: o.lcolor || col, anchor: 'middle', weight: 700 });
    }
    return out;
  }

  function ln(x1, y1, x2, y2, o) { o = o || {}; return arr(x1, y1, x2, y2, Object.assign({ noHead: true }, o)); }

  function dot(x, y, r, f) { return '<circle cx="' + x + '" cy="' + y + '" r="' + (r || 4) + '" fill="' + (f || C.navy) + '"/>'; }
  function ring(x, y, r, s, w) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="none" stroke="' + (s || C.ink3) + '" stroke-width="' + (w || 1.4) + '"/>'; }
  function path(d, o) {
    o = o || {};
    return '<path d="' + d + '" fill="' + (o.fill || 'none') + '" stroke="' + (o.stroke || C.navy) +
      '" stroke-width="' + (o.w || 2) + '"' + (o.dash ? ' stroke-dasharray="' + o.dash + '"' : '') +
      (o.cap ? ' stroke-linecap="' + o.cap + '"' : '') + (o.op ? ' opacity="' + o.op + '"' : '') + '/>';
  }
  function rect(x, y, w, h, o) {
    o = o || {};
    return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (o.rx || 0) +
      '" fill="' + (o.fill || 'none') + '" stroke="' + (o.stroke || 'none') + '" stroke-width="' + (o.w || 1) +
      '"' + (o.dash ? ' stroke-dasharray="' + o.dash + '"' : '') + (o.op ? ' opacity="' + o.op + '"' : '') + '/>';
  }
  /* axes with labels: origin at (ox,oy), width w to the right, height h upward */
  function ax(ox, oy, w, h, xl, yl, o) {
    o = o || {};
    return ln(ox, oy, ox + w, oy, { color: C.ink3, w: 1.4 }) +
      arr(ox + w - 1, oy, ox + w + 8, oy, { color: C.ink3, w: 1.4 }) +
      ln(ox, oy, ox, oy - h, { color: C.ink3, w: 1.4 }) +
      arr(ox, oy - h + 1, ox, oy - h - 8, { color: C.ink3, w: 1.4 }) +
      tx(ox + w + 12, oy + 4, xl, { size: 11.5, fill: C.ink3, weight: 700 }) +
      tx(ox - 6, oy - h - 12, yl, { size: 11.5, fill: C.ink3, anchor: (o.ya || 'start'), weight: 700 });
  }
  /* sample a function to a polyline path */
  function fn(f, x0, x1, n, sx, sy) {
    var d = '', i, t, x, y;
    for (i = 0; i <= n; i++) {
      t = x0 + (x1 - x0) * i / n; x = sx(t); y = sy(f(t));
      d += (i ? ' L' : 'M') + x.toFixed(2) + ',' + y.toFixed(2);
    }
    return d;
  }

  var H = { svg: svg, tx: tx, txw: txw, txfit: txfit, bx: bx, arr: arr, ln: ln, dot: dot, ring: ring, path: path, rect: rect, ax: ax, fn: fn, wrap: wrap };
  D.H = H;
  window.PHY3201 = window.PHY3201 || {};
  window.PHY3201.diagramHelpers = H;
  window.PHY3201.diagrams = D.list = {};
})();

/* ── Topics 1–2 · crystal geometry ─────────────────────────── */
(function () {
  'use strict';
  var P = window.PHY3201, H = P.diagramHelpers, D = P.diagrams;
  var svg = H.svg, tx = H.tx, txw = H.txw, txfit = H.txfit, bx = H.bx, arr = H.arr, ln = H.ln,
      dot = H.dot, ring = H.ring, path = H.path, rect = H.rect;
  var C = { ink: 'var(--ink)', ink2: 'var(--ink-2)', ink3: 'var(--ink-3)', navy: 'var(--navy)',
            blue: 'var(--structure)', purple: 'var(--diffraction)', green: 'var(--bonding)',
            amber: 'var(--phonon)', cyan: 'var(--electron)', crimson: 'var(--crimson)',
            rule: 'var(--rule)', paper: 'var(--paper)', paper2: 'var(--paper-2)' };

  /* oblique projection of a unit cube: returns {p(x,y,z), edges} */
  function cube(ox, oy, s, o) {
    o = o || {};
    var dx = (o.dx == null ? 0.44 : o.dx) * s, dy = (o.dy == null ? 0.30 : o.dy) * s;
    function p(x, y, z) { return [ox + x * s + z * dx, oy - y * s - z * dy]; }
    var E = [[0,0,0,1,0,0],[1,0,0,1,1,0],[1,1,0,0,1,0],[0,1,0,0,0,0],
             [0,0,1,1,0,1],[1,0,1,1,1,1],[1,1,1,0,1,1],[0,1,1,0,0,1],
             [0,0,0,0,0,1],[1,0,0,1,0,1],[1,1,0,1,1,1],[0,1,0,0,1,1]];
    var back = [4,5,6,7,8,11].reduce(function (a) { return a; }, 0);
    var edges = E.map(function (e, i) {
      var a = p(e[0], e[1], e[2]), b = p(e[3], e[4], e[5]);
      var isBack = (i === 4 || i === 7 || i === 8 || i === 11);
      return ln(a[0], a[1], b[0], b[1], { color: isBack ? C.rule : (o.edge || C.ink3), w: isBack ? 1 : 1.4, dash: isBack ? '3 3' : '' });
    }).join('');
    return { p: p, edges: edges };
  }

  /* 1 · lattice + basis = crystal structure */
  D['lattice-basis'] = function () {
    var b = '', i, j, x, y;
    function grid(ox, oy, f) {
      var o = '';
      for (i = 0; i < 4; i++) for (j = 0; j < 3; j++) { x = ox + i * 38; y = oy + j * 38; o += f(x, y, i, j); }
      return o;
    }
    b += tx(10, 18, 'Lattice', { size: 12.5, fill: C.ink3, weight: 800 });
    b += tx(10, 33, 'periodic set of identical points', { size: 10.5, fill: C.ink3 });
    b += grid(24, 56, function (x, y) { return dot(x, y, 3.4, C.ink3); });
    b += ln(24, 56, 138, 56, { color: C.rule, w: 1, dash: '2 3' }) + ln(24, 56, 24, 132, { color: C.rule, w: 1, dash: '2 3' });
    b += tx(81, 154, 'points, not atoms', { size: 10, fill: C.ink3, anchor: 'middle', style: 'italic' });

    b += tx(178, 96, '+', { size: 24, fill: C.ink3, anchor: 'middle', weight: 700 });

    b += tx(206, 18, 'Basis', { size: 12.5, fill: C.ink3, weight: 800 });
    b += tx(206, 33, 'what sits at every point', { size: 10.5, fill: C.ink3 });
    b += dot(226, 88, 8.5, C.blue) + dot(250, 100, 6, C.amber);
    b += ln(226, 88, 250, 100, { color: C.ink3, w: 1.6 });
    b += tx(226, 74, 'A', { size: 10.5, fill: C.blue, anchor: 'middle', weight: 800 });
    b += tx(258, 118, 'B', { size: 10.5, fill: C.amber, anchor: 'middle', weight: 800 });
    b += tx(240, 154, 'one motif', { size: 10, fill: C.ink3, anchor: 'middle', style: 'italic' });

    b += tx(300, 96, '=', { size: 24, fill: C.ink3, anchor: 'middle', weight: 700 });

    b += tx(326, 18, 'Crystal structure', { size: 12.5, fill: C.navy, weight: 800 });
    b += tx(326, 33, 'the real material', { size: 10.5, fill: C.ink3 });
    b += grid(342, 56, function (x, y) {
      return ln(x, y, x + 12, y + 6, { color: C.ink3, w: 1.2 }) + dot(x, y, 5.5, C.blue) + dot(x + 12, y + 6, 3.8, C.amber);
    });
    b += tx(404, 154, 'the motif repeats at every point', { size: 10, fill: C.ink3, anchor: 'middle', style: 'italic' });
    return svg(500, 164, b);
  };

  /* 2 · primitive vs conventional cell (2-D centred rectangular) */
  D['primitive-vs-conventional'] = function () {
    var b = '', i, j;
    function pts(ox) {
      var o = '';
      for (i = 0; i <= 3; i++) for (j = 0; j <= 2; j++) {
        o += dot(ox + i * 56, 156 - j * 46, 4, C.ink3);
        if (i < 3 && j < 2) o += dot(ox + i * 56 + 28, 156 - j * 46 - 23, 4, C.ink3);
      }
      return o;
    }
    b += tx(14, 20, 'Conventional cell', { size: 12.5, fill: C.navy, weight: 800 });
    b += txw(14, 36, 'Chosen to display the full symmetry. Contains 2 lattice points.', 40, { size: 10.5, fill: C.ink3 });
    b += pts(30);
    b += rect(30, 110, 56, 46, { stroke: C.blue, w: 2.2, fill: 'rgba(27,90,174,.09)' });
    b += tx(30, 184, '4 × ¼ corner + 1 centre = 2', { size: 9.6, fill: C.blue, anchor: 'start', weight: 700 });
    b += arr(30, 156, 86, 156, { color: C.blue, label: 'a', ly: 13, lsize: 11.5 });
    b += arr(30, 156, 30, 110, { color: C.blue, label: 'b', lx: -11, ly: 4, lsize: 11.5 });

    b += ln(255, 14, 255, 182, { color: C.rule, w: 1 });

    b += tx(278, 20, 'Primitive cell', { size: 12.5, fill: C.navy, weight: 800 });
    b += txw(278, 36, 'Smallest cell that tiles the lattice. Contains exactly 1 lattice point.', 40, { size: 10.5, fill: C.ink3 });
    b += pts(294);
    b += path('M294,156 L322,133 L378,133 L350,156 Z', { fill: 'rgba(158,27,50,.10)', stroke: C.crimson, w: 2.2 });
    b += tx(294, 184, '4 × ¼ corner = 1', { size: 9.6, fill: C.crimson, anchor: 'start', weight: 700 });
    b += arr(294, 156, 350, 156, { color: C.crimson, label: 'a₁', ly: 13, lsize: 11.5 });
    b += arr(294, 156, 322, 133, { color: C.crimson, label: 'a₂', lx: -12, ly: -2, lsize: 11.5 });
    return svg(500, 200, b);
  };

  /* 3 · the four symmetry operations acting on an asymmetric motif */
  D['symmetry-ops'] = function () {
    var b = '';
    function motif(x, y, sx, sy, col) {
      sx = sx || 1; sy = sy || 1;
      return '<path transform="translate(' + x + ',' + y + ') scale(' + sx + ',' + sy + ')" d="M0,0 L18,0 L18,5 L6,5 L6,16 L0,16 Z" fill="' + (col || C.blue) + '" opacity=".85"/>';
    }
    var titles = ['Translation', 'Rotation (4-fold)', 'Reflection', 'Inversion'];
    var subs = ['move by a lattice vector', 'turn by 90° about an axis', 'flip across a mirror plane', 'send r to −r through a centre'];
    [0, 1, 2, 3].forEach(function (k) {
      var ox = 12 + k * 122;
      b += tx(ox, 16, titles[k], { size: 11.5, fill: C.navy, weight: 800 });
      b += txw(ox, 30, subs[k], 24, { size: 9.8, fill: C.ink3 });
      b += rect(ox, 44, 108, 92, { rx: 7, fill: C.paper2, stroke: C.rule });
      var cx = ox + 54, cy = 90;
      if (k === 0) {
        b += motif(ox + 12, 76) + motif(ox + 60, 76, 1, 1, C.amber);
        b += arr(ox + 34, 68, ox + 58, 68, { color: C.ink3, label: 'T', ly: -5 });
      } else if (k === 1) {
        b += motif(cx + 4, cy - 22) + motif(cx + 22, cy + 4, 1, 1, C.amber);
        b += ring(cx, cy, 3, C.crimson, 2) + dot(cx, cy, 1.6, C.crimson);
        b += arr(cx + 26, cy - 20, cx + 34, cy + 2, { color: C.crimson, curve: 12 });
      } else if (k === 2) {
        b += ln(cx, 52, cx, 130, { color: C.crimson, w: 2, dash: '5 3' });
        b += motif(cx - 30, 78) + motif(cx + 30, 78, -1, 1, C.amber);
        b += tx(cx, 142, 'mirror', { size: 9.5, fill: C.crimson, anchor: 'middle', weight: 700 });
      } else {
        b += motif(cx - 30, 66) + motif(cx + 30, 106, -1, -1, C.amber);
        b += dot(cx, 90, 3, C.crimson);
        b += ln(cx - 22, 74, cx + 22, 106, { color: C.crimson, w: 1, dash: '3 3' });
      }
    });
    return svg(500, 152, b);
  };

  /* 4 · SC, BCC, FCC lattice points */
  D['cubic-three'] = function () {
    var b = '', names = ['Simple cubic (SC)', 'Body-centred cubic (BCC)', 'Face-centred cubic (FCC)'];
    var info = ['1 point per cell · CN 6 · a = 2R', '2 points per cell · CN 8 · √3a = 4R', '4 points per cell · CN 12 · √2a = 4R'];
    var cols = [C.blue, C.green, C.crimson];
    [0, 1, 2].forEach(function (k) {
      var ox = 26 + k * 162, oy = 176, s = 78;
      var c = cube(ox, oy, s);
      b += txw(ox - 22, 20, names[k], 22, { size: 11.2, fill: C.navy, weight: 800 });
      b += txw(ox - 22, 48, info[k], 24, { size: 9.8, fill: C.ink3 });
      b += c.edges;
      /* corners */
      [[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]].forEach(function (v) {
        var q = c.p(v[0], v[1], v[2]); b += dot(q[0], q[1], 5, cols[k]);
      });
      if (k === 1) { var m = c.p(0.5, 0.5, 0.5); b += dot(m[0], m[1], 6.5, C.amber) + ring(m[0], m[1], 9.5, C.amber, 1.2); }
      if (k === 2) {
        [[0.5,0.5,0],[0.5,0.5,1],[0.5,0,0.5],[0.5,1,0.5],[0,0.5,0.5],[1,0.5,0.5]].forEach(function (v) {
          var q = c.p(v[0], v[1], v[2]); b += dot(q[0], q[1], 5.5, C.amber);
        });
      }
    });
    b += txfit(250, 240, 'Corner points are shared between 8 cells, face points between 2, the body point belongs to one cell alone.', { w: 476, size: 10.2, fill: C.ink3, anchor: 'middle', style: 'italic' });
    return svg(500, 264, b);
  };

  /* 5 · the general (triclinic) cell that defines the seven systems */
  D['cell-parameters'] = function () {
    var b = '', ox = 130, oy = 172, s = 96;
    function p(x, y, z) { return [ox + x * s + z * 0.5 * s, oy - y * s * 0.86 - z * 0.34 * s]; }
    var E = [[0,0,0,1,0,0],[1,0,0,1,1,0],[1,1,0,0,1,0],[0,1,0,0,0,0],
             [0,0,1,1,0,1],[1,0,1,1,1,1],[1,1,1,0,1,1],[0,1,1,0,0,1],
             [0,0,0,0,0,1],[1,0,0,1,0,1],[1,1,0,1,1,1],[0,1,0,0,1,1]];
    E.forEach(function (e, i) {
      var a = p(e[0], e[1], e[2]), q = p(e[3], e[4], e[5]);
      var back = (i === 4 || i === 7 || i === 8 || i === 11);
      b += ln(a[0], a[1], q[0], q[1], { color: back ? C.rule : C.ink3, w: back ? 1 : 1.5, dash: back ? '3 3' : '' });
    });
    var O = p(0,0,0), A = p(1,0,0), B = p(0,1,0), Cc = p(0,0,1);
    b += arr(O[0], O[1], A[0] + 14, A[1], { color: C.blue, w: 2 });
    b += arr(O[0], O[1], B[0], B[1] - 14, { color: C.green, w: 2 });
    b += arr(O[0], O[1], Cc[0] + 8, Cc[1] - 6, { color: C.amber, w: 2 });
    b += tx(A[0] + 20, A[1] + 5, 'a', { size: 13, fill: C.blue, weight: 800, style: 'italic' });
    b += tx(B[0] - 6, B[1] - 20, 'b', { size: 13, fill: C.green, weight: 800, style: 'italic', anchor: 'middle' });
    b += tx(Cc[0] + 14, Cc[1] - 8, 'c', { size: 13, fill: C.amber, weight: 800, style: 'italic' });
    b += tx(O[0] - 12, O[1] + 6, 'O', { size: 11, fill: C.ink3, weight: 700 });
    /* angle arcs at the origin */
    b += path('M' + (O[0]+30) + ',' + O[1] + ' A30,30 0 0 0 ' + (O[0]+16) + ',' + (O[1]-25), { stroke: C.crimson, w: 1.4 });
    b += tx(O[0] + 34, O[1] - 16, 'γ', { size: 12, fill: C.crimson, weight: 800 });
    b += path('M' + (O[0]+22) + ',' + (O[1]-8) + ' A24,24 0 0 0 ' + (O[0]+13) + ',' + (O[1]-19), { stroke: C.crimson, w: 1.4, dash: '2 2' });
    b += bx(300, 40, 186, 'Seven crystal systems = seven allowed combinations of the relations between a, b, c and α, β, γ.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += tx(300, 134, 'γ = angle between a and b', { size: 10.5, fill: C.ink3 });
    b += tx(300, 150, 'β = angle between a and c', { size: 10.5, fill: C.ink3 });
    b += tx(300, 166, 'α = angle between b and c', { size: 10.5, fill: C.ink3 });
    b += tx(300, 190, 'Cubic is the most constrained:', { size: 10.5, fill: C.ink2, weight: 700 });
    b += tx(300, 205, 'a = b = c, α = β = γ = 90°', { size: 11, fill: C.navy, mono: true, weight: 700 });
    return svg(500, 218, b);
  };

  /* 6 · how Miller indices are constructed */
  D['miller-steps'] = function () {
    var b = '', ox = 26, oy = 166, s = 96;
    function p(x, y, z) { return [ox + x * s + z * 0.46 * s, oy - y * s - z * 0.32 * s]; }
    var E = [[0,0,0,1,0,0],[1,0,0,1,1,0],[1,1,0,0,1,0],[0,1,0,0,0,0],
             [0,0,1,1,0,1],[1,0,1,1,1,1],[1,1,1,0,1,1],[0,1,1,0,0,1],
             [0,0,0,0,0,1],[1,0,0,1,0,1],[1,1,0,1,1,1],[0,1,0,0,1,1]];
    E.forEach(function (e, i) {
      var a = p(e[0], e[1], e[2]), q = p(e[3], e[4], e[5]);
      var back = (i === 4 || i === 7 || i === 8 || i === 11);
      b += ln(a[0], a[1], q[0], q[1], { color: back ? C.rule : C.ink3, w: back ? 1 : 1.3, dash: back ? '3 3' : '' });
    });
    /* plane with intercepts 1, 1/2, ∞  →  (120) */
    var i1 = p(1, 0, 0), i2 = p(0, 0.5, 0), i3a = p(1, 0, 1), i3b = p(0, 0.5, 1);
    b += path('M' + i1[0] + ',' + i1[1] + ' L' + i2[0] + ',' + i2[1] + ' L' + i3b[0] + ',' + i3b[1] + ' L' + i3a[0] + ',' + i3a[1] + ' Z',
      { fill: 'rgba(107,63,160,.18)', stroke: C.purple, w: 2 });
    b += dot(i1[0], i1[1], 4.5, C.purple) + dot(i2[0], i2[1], 4.5, C.purple);
    b += tx(i1[0] + 6, i1[1] + 15, 'x = 1', { size: 10.5, fill: C.purple, weight: 700 });
    b += tx(i2[0] + 8, i2[1] - 8, 'y = ½', { size: 10.5, fill: C.purple, weight: 700, anchor: 'start' });
    b += tx(p(0.5,0,1)[0] + 10, p(0.5,0,1)[1] - 30, 'z = ∞', { size: 10.5, fill: C.purple, weight: 700 });
    b += txfit(ox - 10, 194, 'The plane is parallel to z, so it never cuts that axis.', { w: 214, size: 9.8, fill: C.ink3, style: 'italic' });

    var sx = 236;
    b += bx(sx, 14, 246, 'Step 1 · Read the intercepts in lattice units', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += tx(sx + 123, 70, '(1,  ½,  ∞)', { size: 14, fill: C.ink, anchor: 'middle', mono: true, weight: 700 });
    b += arr(sx + 123, 76, sx + 123, 88, { color: C.ink3, w: 1.4 });
    b += bx(sx, 92, 246, 'Step 2 · Take the reciprocal of each', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += tx(sx + 123, 148, '(1,  2,  0)', { size: 14, fill: C.ink, anchor: 'middle', mono: true, weight: 700 });
    b += arr(sx + 123, 154, sx + 123, 166, { color: C.ink3, w: 1.4 });
    b += bx(sx, 170, 246, 'Step 3 · Clear fractions to the smallest integers, in round brackets', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += tx(sx + 123, 242, '(1 2 0)', { size: 18, fill: C.purple, anchor: 'middle', mono: true, weight: 800 });
    return svg(500, 254, b);
  };

  /* 7 · [hkl] direction vs (hkl) plane */
  D['direction-vs-plane'] = function () {
    var b = '', ox = 34, oy = 158, s = 96;
    function p(x, y, z) { return [ox + x * s + z * 0.46 * s, oy - y * s - z * 0.32 * s]; }
    function frame(shift) {
      var o = '';
      var E = [[0,0,0,1,0,0],[1,0,0,1,1,0],[1,1,0,0,1,0],[0,1,0,0,0,0],
               [0,0,1,1,0,1],[1,0,1,1,1,1],[1,1,1,0,1,1],[0,1,1,0,0,1],
               [0,0,0,0,0,1],[1,0,0,1,0,1],[1,1,0,1,1,1],[0,1,0,0,1,1]];
      E.forEach(function (e, i) {
        var a = p(e[0], e[1], e[2]), q = p(e[3], e[4], e[5]);
        var back = (i === 4 || i === 7 || i === 8 || i === 11);
        o += ln(a[0] + shift, a[1], q[0] + shift, q[1], { color: back ? C.rule : C.ink3, w: back ? 1 : 1.3, dash: back ? '3 3' : '' });
      });
      return o;
    }
    b += tx(30, 20, '[111]  —  a direction', { size: 12.5, fill: C.blue, weight: 800 });
    b += frame(0);
    var o0 = p(0,0,0), t1 = p(1,1,1);
    b += arr(o0[0], o0[1], t1[0], t1[1], { color: C.blue, w: 2.6 });
    b += dot(o0[0], o0[1], 4, C.blue);
    b += txw(20, 194, 'Square brackets. A vector from the origin: one step along a, one along b, one along c.', 44, { size: 10.3, fill: C.ink3 });

    b += ln(268, 12, 268, 214, { color: C.rule, w: 1 });

    var sh = 268;
    b += tx(sh + 26, 20, '(111)  —  a plane', { size: 12.5, fill: C.purple, weight: 800 });
    b += frame(sh);
    var a1 = p(1,0,0), a2 = p(0,1,0), a3 = p(0,0,1);
    b += path('M' + (a1[0]+sh) + ',' + a1[1] + ' L' + (a2[0]+sh) + ',' + a2[1] + ' L' + (a3[0]+sh) + ',' + a3[1] + ' Z',
      { fill: 'rgba(107,63,160,.20)', stroke: C.purple, w: 2 });
    /* the normal, drawn from the plane centroid */
    var cxp = (a1[0] + a2[0] + a3[0]) / 3 + sh, cyp = (a1[1] + a2[1] + a3[1]) / 3;
    var n1 = p(1,1,1);
    b += arr(cxp, cyp, cxp + (n1[0] - p(0,0,0)[0]) * 0.42, cyp + (n1[1] - p(0,0,0)[1]) * 0.42, { color: C.blue, w: 2.2, dash: '4 3' });
    b += tx(cxp + 40, cyp - 26, 'normal', { size: 10, fill: C.blue, weight: 700 });
    b += txw(sh + 16, 194, 'Round brackets. In a CUBIC crystal only, [hkl] is normal to (hkl) — the shortcut fails in other systems.', 44, { size: 10.3, fill: C.ink3 });
    return svg(500, 231, b);
  };

  /* 8 · where atoms touch, per structure */
  D['apf-contact'] = function () {
    var b = '';
    var titles = ['SC · atoms touch along the cube EDGE', 'BCC · atoms touch along the BODY DIAGONAL', 'FCC · atoms touch along the FACE DIAGONAL'];
    var rels = ['a = 2R', '√3 a = 4R', '√2 a = 4R'];
    var apfs = ['APF = π/6 ≈ 0.52', 'APF = √3π/8 ≈ 0.68', 'APF = π/(3√2) ≈ 0.74'];
    var cols = [C.blue, C.green, C.crimson];
    [0, 1, 2].forEach(function (k) {
      var ox = 30 + k * 162, oy = 104, w = 100;   /* SC circles reach R=w/2 beyond the square */
      b += txw(ox, 16, titles[k], 24, { size: 10.6, fill: C.navy, weight: 800 });
      b += rect(ox, oy, w, w, { stroke: C.ink3, w: 1.6, fill: C.paper2 });
      var R;
      if (k === 0) { R = w / 2; b += ring(ox, oy, R, cols[k], 1.6) + ring(ox + w, oy, R, cols[k], 1.6) + ring(ox, oy + w, R, cols[k], 1.6) + ring(ox + w, oy + w, R, cols[k], 1.6);
        b += ln(ox, oy + w, ox + w, oy + w, { color: C.crimson, w: 3 });
      } else if (k === 1) {
        /* (110) section through BCC: rectangle a × √2 a is hard at this size; show the cube face + body atom in projection */
        R = w * Math.sqrt(3) / 8;
        b += ring(ox, oy, R, cols[k], 1.6) + ring(ox + w, oy, R, cols[k], 1.6) + ring(ox, oy + w, R, cols[k], 1.6) + ring(ox + w, oy + w, R, cols[k], 1.6);
        b += ring(ox + w / 2, oy + w / 2, R, C.amber, 1.8);
        b += ln(ox, oy, ox + w, oy + w, { color: C.crimson, w: 3, dash: '' });
        b += tx(ox + w / 2 + R + 6, oy + w / 2 + 3.5, 'body atom', { size: 9.5, fill: C.amber, weight: 700 });
      } else {
        R = w * Math.SQRT2 / 8;
        b += ring(ox, oy, R, cols[k], 1.6) + ring(ox + w, oy, R, cols[k], 1.6) + ring(ox, oy + w, R, cols[k], 1.6) + ring(ox + w, oy + w, R, cols[k], 1.6);
        b += ring(ox + w / 2, oy + w / 2, R, C.amber, 1.8);
        b += ln(ox, oy + w, ox + w, oy, { color: C.crimson, w: 3 });
        b += tx(ox + w / 2 + R + 6, oy + w / 2 + 3.5, 'face atom', { size: 9.5, fill: C.amber, weight: 700 });
      }
      b += tx(ox + w / 2, oy + w + 66, rels[k], { size: 12.5, fill: C.crimson, anchor: 'middle', mono: true, weight: 800 });
      b += tx(ox + w / 2, oy + w + 83, apfs[k], { size: 11, fill: C.ink2, anchor: 'middle', weight: 700 });
    });
    b += txfit(250, 322, 'The contact direction is the whole trick: it is what converts a hard-sphere radius R into the lattice parameter a.', { w: 476, size: 10.3, fill: C.ink3, anchor: 'middle', style: 'italic' });
    return svg(500, 346, b);
  };

  /* 9 · planar density depends on which plane you cut */
  D['planar-density'] = function () {
    var b = '';
    var labels = ['FCC (100)', 'FCC (110)', 'FCC (111)'];
    var notes = ['2 atoms per a²', '2 atoms per √2 a²', '4 atoms per √3 a² — the densest'];
    [0, 1, 2].forEach(function (k) {
      var ox = 22 + k * 162, oy = 78, w = 126, h = 126;   /* clears the 2-line note above */
      b += tx(ox, 20, labels[k], { size: 12, fill: C.navy, weight: 800 });
      b += txw(ox, 34, notes[k], 22, { size: 9.6, fill: C.ink3 });
      var col = k === 2 ? C.crimson : C.blue;
      if (k === 0) {
        b += rect(ox, oy, w, h, { stroke: C.ink3, w: 1.5, fill: C.paper2 });
        var R = w * Math.SQRT2 / 8;
        [[0,0],[1,0],[0,1],[1,1]].forEach(function (v) { b += ring(ox + v[0]*w, oy + v[1]*h, R, col, 1.7); });
        b += ring(ox + w/2, oy + h/2, R, col, 1.7);
      } else if (k === 1) {
        b += rect(ox, oy + 18, w, h - 36, { stroke: C.ink3, w: 1.5, fill: C.paper2 });
        var R1 = (h - 36) / 2 * 0.72;
        [[0,0],[1,0],[0,1],[1,1]].forEach(function (v) { b += ring(ox + v[0]*w, oy + 18 + v[1]*(h-36), R1, col, 1.7); });
        b += ring(ox + w/2, oy + 18 + (h-36)/2, R1, col, 1.7);
        b += tx(ox + w/2, oy + h + 28, 'rectangular, less dense', { size: 9.5, fill: C.ink3, anchor: 'middle', style: 'italic' });
      } else {
        /* close-packed triangular net */
        var R2 = 18, dxr = 2 * R2, dyr = R2 * 1.732;
        b += path('M' + (ox+8) + ',' + (oy+h-6) + ' L' + (ox+8+3*dxr) + ',' + (oy+h-6) + ' L' + (ox+8+1.5*dxr) + ',' + (oy+h-6-1.5*dyr) + ' Z',
          { fill: 'rgba(158,27,50,.07)', stroke: C.rule, w: 1 });
        for (var r = 0; r < 3; r++) for (var q = 0; q <= 2 - r; q++) {
          b += ring(ox + 8 + q * dxr + r * R2, oy + h - 6 - r * dyr, R2, col, 1.7);
        }
      }
    });
    b += txfit(250, 250, 'Same crystal, different cut, different atoms per unit area — which is why surface chemistry, growth and etching are plane-dependent.', { w: 476, size: 10.3, fill: C.ink3, anchor: 'middle', style: 'italic' });
    return svg(500, 274, b);
  };

  /* 10 · real crystals are not perfect */
  D['real-defects'] = function () {
    var b = '', i, j, ox = 24, oy = 60, sp = 26;
    function lat(x0, cols, rows, skip, extra) {
      var o = '';
      for (i = 0; i < cols; i++) for (j = 0; j < rows; j++) {
        if (skip && skip(i, j)) continue;
        o += ring(x0 + i * sp, oy + j * sp, 8.5, C.ink3, 1.3);
      }
      return o + (extra || '');
    }
    b += tx(ox, 22, 'Vacancy', { size: 11.5, fill: C.navy, weight: 800 });
    b += tx(ox, 36, 'a missing atom', { size: 9.8, fill: C.ink3 });
    b += lat(ox + 10, 4, 4, function (i, j) { return i === 1 && j === 1; });
    b += '<circle cx="' + (ox + 36) + '" cy="' + (oy + sp) + '" r="8.5" fill="none" stroke="' + C.crimson + '" stroke-width="1.6" stroke-dasharray="3 3"/>';

    var o2 = 148;
    b += tx(o2, 22, 'Impurities', { size: 11.5, fill: C.navy, weight: 800 });
    b += tx(o2, 36, 'interstitial and substitutional', { size: 9.8, fill: C.ink3 });
    b += lat(o2 + 10, 4, 4, function (i, j) { return i === 2 && j === 2; });
    b += '<circle cx="' + (o2 + 10 + 2 * sp) + '" cy="' + (oy + 2 * sp) + '" r="8.5" fill="' + C.amber + '" opacity=".8"/>';
    b += dot(o2 + 10 + 0.5 * sp, oy + 0.5 * sp, 4.5, C.green);
    /* labelled as a key below the lattice: in-place labels sat on top of the rings. */
    b += dot(o2 + 6, 149, 4.5, C.green);
    b += tx(o2 + 16, 152, 'interstitial · squeezes between sites', { size: 9, fill: C.green, weight: 700 });
    b += '<circle cx="' + (o2 + 6) + '" cy="163" r="6" fill="' + C.amber + '" opacity=".8"/>';
    b += tx(o2 + 16, 166, 'substitutional · replaces a host atom', { size: 9, fill: C.amber, weight: 700 });

    var o3 = 300;
    b += tx(o3, 22, 'Edge dislocation', { size: 11.5, fill: C.navy, weight: 800 });
    b += tx(o3, 36, 'an extra half-plane', { size: 9.8, fill: C.ink3 });
    for (i = 0; i < 5; i++) for (j = 0; j < 4; j++) {
      if (j < 2 && i === 2) continue;
      var xx = o3 + 8 + i * 22 + (j < 2 && i > 2 ? -6 : 0) + (j < 2 && i < 2 ? 4 : 0);
      b += ring(xx, oy + j * 24, 6.5, C.ink3, 1.2);
    }
    for (j = 0; j < 2; j++) b += ring(o3 + 8 + 2 * 22, oy + j * 24, 6.5, C.crimson, 1.8);
    b += ln(o3 + 8 + 2 * 22, oy - 8, o3 + 8 + 2 * 22, oy + 30, { color: C.crimson, w: 2 });
    b += tx(o3 + 8 + 2 * 22 + 10, oy + 46, '⊥', { size: 15, fill: C.crimson, weight: 800 });

    var o4 = 24;
    b += tx(o4, 178, 'Grain boundary', { size: 11.5, fill: C.navy, weight: 800 });
    b += tx(o4, 192, 'two orientations meeting — the defect that separates a single crystal from a polycrystal', { size: 9.8, fill: C.ink3 });
    b += rect(o4, 202, 452, 74, { rx: 6, fill: C.paper2, stroke: C.rule });
    for (i = 0; i < 9; i++) for (j = 0; j < 3; j++) b += ring(o4 + 18 + i * 22, 216 + j * 22, 6, C.blue, 1.2);
    b += ln(o4 + 218, 202, o4 + 236, 276, { color: C.crimson, w: 2.4 });
    for (i = 0; i < 9; i++) for (j = 0; j < 3; j++) {
      var a = 0.32, px = o4 + 258 + i * 20, py = 214 + j * 22;
      var rx = o4 + 258 + Math.cos(a) * (px - o4 - 258) - Math.sin(a) * (py - 240);
      var ry = 240 + Math.sin(a) * (px - o4 - 258) + Math.cos(a) * (py - 240);
      if (rx < o4 + 240 || rx > o4 + 446) continue;
      b += ring(rx, ry, 6, C.green, 1.2);
    }
    b += tx(o4 + 236, 292, 'grain boundary', { size: 10, fill: C.crimson, anchor: 'middle', weight: 700 });
    return svg(500, 322, b);
  };
})();

/* ── Topics 3–4 · diffraction and reciprocal space ─────────── */
(function () {
  'use strict';
  var P = window.PHY3201, H = P.diagramHelpers, D = P.diagrams;
  var svg = H.svg, tx = H.tx, txw = H.txw, txfit = H.txfit, bx = H.bx, arr = H.arr, ln = H.ln,
      dot = H.dot, ring = H.ring, path = H.path, rect = H.rect, ax = H.ax, fn = H.fn;
  var C = { ink: 'var(--ink)', ink2: 'var(--ink-2)', ink3: 'var(--ink-3)', navy: 'var(--navy)',
            blue: 'var(--structure)', purple: 'var(--diffraction)', green: 'var(--bonding)',
            amber: 'var(--phonon)', cyan: 'var(--electron)', crimson: 'var(--crimson)',
            rule: 'var(--rule)', paper: 'var(--paper)', paper2: 'var(--paper-2)' };

  /* 11 · why an atom scatters: electron cloud, and why the form factor falls off */
  D['atomic-scattering'] = function () {
    var b = '', cx = 108, cy = 108;
    b += tx(20, 20, 'An atom scatters X-rays because its ELECTRONS oscillate', { size: 11.8, fill: C.navy, weight: 800 });
    /* incident wave */
    var i;
    for (i = 0; i < 3; i++) b += path('M20,' + (72 + i * 24) + ' q10,-8 20,0 t20,0 t20,0', { stroke: C.purple, w: 1.6, op: .8 });
    b += arr(80, 108, 96, 108, { color: C.purple, w: 1.8 });
    b += tx(20, 60, 'incident X-ray', { size: 10, fill: C.purple, weight: 700 });
    /* atom */
    b += '<circle cx="' + cx + '" cy="' + cy + '" r="30" fill="url(#eg)" opacity=".9"/>';
    b += '<defs><radialGradient id="eg"><stop offset="0%" stop-color="' + C.cyan + '" stop-opacity=".55"/><stop offset="100%" stop-color="' + C.cyan + '" stop-opacity=".05"/></radialGradient></defs>';
    b += dot(cx, cy, 5, C.crimson);
    b += tx(cx, cy + 48, 'nucleus + electron cloud', { size: 9.8, fill: C.ink3, anchor: 'middle' });
    b += tx(cx + 34, cy - 26, 'radius ~ 0.1 nm', { size: 9.5, fill: C.cyan, weight: 700 });
    /* scattered spherical waves */
    [40, 52, 64].forEach(function (r) {
      b += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="' + C.purple + '" stroke-width="1" opacity=".45" stroke-dasharray="4 4"/>';
    });
    b += arr(cx + 26, cy - 22, cx + 62, cy - 52, { color: C.purple, w: 1.6 });
    b += arr(cx + 34, cy, cx + 74, cy, { color: C.purple, w: 1.6 });
    b += arr(cx + 26, cy + 22, cx + 62, cy + 52, { color: C.purple, w: 1.6 });

    /* form factor plot */
    var ox = 300, oy = 176, w = 148, h = 108;
    b += ax(ox, oy, w, h, 'sinθ/λ', 'f');
    b += path(fn(function (t) { return Math.exp(-2.6 * t * t); }, 0, 1, 60,
      function (t) { return ox + t * w; }, function (v) { return oy - v * h; }), { stroke: C.purple, w: 2.4 });
    b += tx(ox + 4, oy - h - 4, 'f → Z as θ → 0', { size: 10, fill: C.purple, weight: 700 });
    b += txw(ox, oy + 22, 'The cloud is comparable in size to λ, so waves from different parts of the same atom fall out of step as the angle grows. That falling envelope is the atomic form factor f — it is why every powder pattern fades at high 2θ.', 38, { size: 10, fill: C.ink3 });
    b += tx(ox - 6, 48, 'Atomic form factor', { size: 11.8, fill: C.navy, weight: 800 });
    return svg(500, 272, b);
  };

  /* 12 · the Bragg path-difference argument, drawn to scale */
  D['bragg-mechanism'] = function () {
    var b = '', th = 32 * Math.PI / 180;
    var y1 = 132, y2 = 186, d = y2 - y1;
    var cxs = [70, 140, 210, 280, 350, 420];
    b += tx(20, 20, 'Bragg’s law is a PATH-DIFFERENCE argument between two planes', { size: 11.8, fill: C.navy, weight: 800 });
    /* planes */
    [y1, y2, y2 + d].forEach(function (y, k) {
      b += ln(34, y, 450, y, { color: C.rule, w: 1.3 });
      cxs.forEach(function (x) { b += dot(x, y, 6, k === 2 ? C.rule : C.blue); });
    });
    b += tx(454, y1 + 4, 'plane 1', { size: 9.6, fill: C.ink3 });
    b += tx(454, y2 + 4, 'plane 2', { size: 9.6, fill: C.ink3 });
    b += arr(30, y1, 30, y2, { color: C.ink3, both: true, w: 1.3 });
    b += tx(18, (y1 + y2) / 2 + 4, 'd', { size: 13, fill: C.ink3, weight: 800, style: 'italic', anchor: 'end' });

    /* ray on plane 1 */
    var A = [210, y1], L = 130;
    var inA = [A[0] - L * Math.cos(th), A[1] - L * Math.sin(th)];
    var outA = [A[0] + L * Math.cos(th), A[1] - L * Math.sin(th)];
    b += arr(inA[0], inA[1], A[0], A[1], { color: C.purple, w: 2 });
    b += arr(A[0], A[1], outA[0], outA[1], { color: C.purple, w: 2 });
    /* ray on plane 2 */
    var B = [280, y2];
    var inB = [B[0] - L * Math.cos(th), B[1] - L * Math.sin(th)];
    var outB = [B[0] + L * Math.cos(th), B[1] - L * Math.sin(th)];
    b += arr(inB[0], inB[1], B[0], B[1], { color: C.amber, w: 2 });
    b += arr(B[0], B[1], outB[0], outB[1], { color: C.amber, w: 2 });
    /* the two perpendiculars marking the extra path */
    var F1 = [B[0] - d * Math.sin(th) * Math.cos(th) - 0, 0];
    /* foot of perpendicular from A onto the lower incident ray */
    function foot(px, py, ax0, ay0, bx0, by0) {
      var vx = bx0 - ax0, vy = by0 - ay0, t = ((px - ax0) * vx + (py - ay0) * vy) / (vx * vx + vy * vy);
      return [ax0 + t * vx, ay0 + t * vy];
    }
    var f1 = foot(A[0], A[1], inB[0], inB[1], B[0], B[1]);
    var f2 = foot(A[0], A[1], B[0], B[1], outB[0], outB[1]);
    b += ln(A[0], A[1], f1[0], f1[1], { color: C.crimson, w: 1.8, dash: '4 3' });
    b += ln(A[0], A[1], f2[0], f2[1], { color: C.crimson, w: 1.8, dash: '4 3' });
    b += ln(f1[0], f1[1], B[0], B[1], { color: C.crimson, w: 3.4 });
    b += ln(B[0], B[1], f2[0], f2[1], { color: C.crimson, w: 3.4 });
    b += tx(f1[0] - 6, f1[1] + 18, 'd sin θ', { size: 11, fill: C.crimson, weight: 800, anchor: 'end' });
    b += tx(f2[0] + 8, f2[1] + 18, 'd sin θ', { size: 11, fill: C.crimson, weight: 800 });
    /* angle marks */
    b += path('M' + (A[0] - 46) + ',' + A[1] + ' A46,46 0 0 0 ' + (A[0] - 46 * Math.cos(th)) + ',' + (A[1] - 46 * Math.sin(th)), { stroke: C.ink3, w: 1.3 });
    b += tx(A[0] - 60, A[1] - 12, 'θ', { size: 13, fill: C.ink2, weight: 800 });
    b += tx(A[0] + 52, A[1] - 12, 'θ', { size: 13, fill: C.ink2, weight: 800 });
    b += dot(A[0], A[1], 6, C.purple) + dot(B[0], B[1], 6, C.amber);

    b += bx(24, 234, 452, 'Extra path travelled by the lower ray = 2d sin θ. Constructive interference needs that to equal a whole number of wavelengths:  nλ = 2d sin θ', { size: 12, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += txfit(24, 308, 'θ is measured from the PLANE, not from the plane normal. The detector sits at 2θ.', { w: 464, size: 10.4, fill: C.crimson, weight: 700 });
    return svg(500, 332, b);
  };

  /* 13 · the 2θ mistake */
  D['theta-vs-2theta'] = function () {
    var b = '', cx = 250, cy = 168, R = 120, th = 26 * Math.PI / 180;
    b += tx(20, 20, 'θ, 2θ and the angle your diffractometer reports', { size: 11.8, fill: C.navy, weight: 800 });
    b += ln(cx - 150, cy, cx + 150, cy, { color: C.rule, w: 1.3, dash: '5 4' });
    b += rect(cx - 54, cy, 108, 12, { fill: C.paper2, stroke: C.ink3, w: 1.3 });
    b += tx(cx, cy + 26, 'sample surface (the planes)', { size: 9.8, fill: C.ink3, anchor: 'middle' });
    var inc = [cx - R * Math.cos(th), cy - R * Math.sin(th)];
    var out = [cx + R * Math.cos(th), cy - R * Math.sin(th)];
    var str = [cx + R, cy];
    b += arr(inc[0], inc[1], cx, cy, { color: C.purple, w: 2.4 });
    b += arr(cx, cy, out[0], out[1], { color: C.amber, w: 2.4 });
    b += ln(cx, cy, str[0], str[1], { color: C.rule, w: 1.4, dash: '4 4' });
    b += tx(inc[0] - 6, inc[1] - 8, 'incident beam', { size: 10, fill: C.purple, weight: 700, anchor: 'middle' });
    b += tx(out[0] + 6, out[1] - 8, 'diffracted beam', { size: 10, fill: C.amber, weight: 700, anchor: 'middle' });
    b += path('M' + (cx - 62) + ',' + cy + ' A62,62 0 0 0 ' + (cx - 62 * Math.cos(th)) + ',' + (cy - 62 * Math.sin(th)), { stroke: C.ink2, w: 1.5 });
    b += tx(cx - 76, cy - 14, 'θ', { size: 14, fill: C.ink, weight: 800 });
    b += path('M' + (cx + 92) + ',' + cy + ' A92,92 0 0 0 ' + (cx + 92 * Math.cos(th)) + ',' + (cy - 92 * Math.sin(th)), { stroke: C.crimson, w: 2 });
    b += tx(cx + 104, cy - 22, '2θ', { size: 14, fill: C.crimson, weight: 800 });
    b += bx(24, 214, 452, 'A peak listed at 2θ = 44.7° corresponds to θ = 22.35°. Put 22.35° into Bragg’s law, never 44.7°. This single slip is the most common numerical error in the whole course.', { size: 11.4, color: 'var(--stop)', fill: 'var(--stop-bg)', stroke: '#EECAD1' });
    return svg(500, 279, b);
  };

  /* 14 · real space → reciprocal space */
  D['reciprocal-bridge'] = function () {
    var b = '', i;
    b += txfit(20, 20, 'Real space and reciprocal space are inverse pictures of the same crystal', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    /* real space: planes with spacing d */
    b += tx(30, 46, 'REAL SPACE', { size: 10.5, fill: C.blue, weight: 800 });
    for (i = 0; i < 5; i++) {
      b += ln(30, 62 + i * 24, 186, 62 + i * 24, { color: C.blue, w: 1.6 });
    }
    b += arr(198, 62, 198, 86, { color: C.crimson, both: true, w: 1.4 });
    b += tx(206, 78, 'd', { size: 13, fill: C.crimson, weight: 800, style: 'italic' });
    b += tx(30, 178, 'Widely spaced planes → small d', { size: 9.8, fill: C.ink3 });

    b += arr(224, 118, 274, 118, { color: C.ink3, w: 2 });
    b += tx(249, 108, 'G = 2π/d', { size: 11, fill: C.ink2, anchor: 'middle', weight: 800, mono: true });
    b += tx(249, 138, 'invert', { size: 9.8, fill: C.ink3, anchor: 'middle', style: 'italic' });

    b += tx(300, 46, 'RECIPROCAL SPACE', { size: 10.5, fill: C.purple, weight: 800 });
    b += ln(300, 130, 470, 130, { color: C.rule, w: 1.2 });
    b += dot(310, 130, 5, C.ink3);
    b += tx(310, 148, '0', { size: 10, fill: C.ink3, anchor: 'middle' });
    for (i = 1; i <= 4; i++) { b += dot(310 + i * 34, 130, 5, C.purple); b += tx(310 + i * 34, 148, i + 'G', { size: 9.5, fill: C.purple, anchor: 'middle', weight: 700 }); }
    b += arr(310, 112, 344, 112, { color: C.crimson, both: true, w: 1.4 });
    b += tx(327, 104, 'G', { size: 12, fill: C.crimson, weight: 800, anchor: 'middle' });
    b += tx(300, 178, 'becomes a short reciprocal vector', { size: 9.8, fill: C.ink3 });

    b += bx(24, 196, 452, 'A large real-space spacing is a short reciprocal vector, and a short spacing is a long one. That inversion is why closely spaced planes diffract at high angle: a big G needs a big scattering vector to match it.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 274, b);
  };

  /* 15 · the Ewald construction: the diffraction condition, geometrically */
  D['ewald'] = function () {
    var b = '', cx = 190, cy = 158, R = 96;
    b += txfit(20, 20, 'The Ewald construction: a peak needs a G-point on the sphere', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    /* reciprocal lattice */
    var i, j;
    for (i = -3; i <= 5; i++) for (j = -2; j <= 2; j++) {
      var px = cx + R + i * 44, py = cy + j * 44;
      if (px < 24 || px > 476 || py < 46 || py > 250) continue;
      b += dot(px, py, 3.4, C.rule);
    }
    b += '<circle cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill="none" stroke="' + C.purple + '" stroke-width="2"/>';
    b += dot(cx, cy, 4, C.ink3);
    b += tx(cx, cy + 18, 'centre', { size: 9.2, fill: C.ink3, anchor: 'middle' });
    /* incident k */
    b += arr(cx, cy, cx + R, cy, { color: C.purple, w: 2.2 });
    b += tx(cx + R / 2, cy - 8, 'k', { size: 13, fill: C.purple, anchor: 'middle', weight: 800, style: 'italic' });
    b += dot(cx + R, cy, 5.5, C.ink2);
    b += tx(cx + R + 8, cy + 38, 'origin of the', { size: 9.2, fill: C.ink3 });
    b += tx(cx + R + 8, cy + 49, 'reciprocal lattice', { size: 9.2, fill: C.ink3 });
    /* a point ON the sphere */
    var a2 = -0.86;
    var Px = cx + R * Math.cos(a2), Py = cy + R * Math.sin(a2);
    b += arr(cx, cy, Px, Py, { color: C.amber, w: 2.2 });
    b += tx(cx + 40, cy - 62, "k'", { size: 13, fill: C.amber, weight: 800, style: 'italic' });
    b += arr(cx + R, cy, Px, Py, { color: C.crimson, w: 2.4 });
    b += tx(cx + R + 16, cy - 42, 'G', { size: 13, fill: C.crimson, weight: 800, style: 'italic' });
    b += dot(Px, Py, 6, C.crimson);
    b += tx(Px - 8, Py - 10, 'on the sphere → a peak', { size: 9.6, fill: C.crimson, weight: 700, anchor: 'end' });
    /* a point off the sphere */
    b += dot(cx + R + 44, cy + 64, 5, C.ink3);
    b += tx(cx + R + 52, cy + 68, 'off the sphere → nothing', { size: 9.6, fill: C.ink3 });

    b += bx(330, 60, 150, 'Elastic scattering keeps |k′| = |k|, so the tip must stay on the sphere. The condition k′ − k = G is Bragg’s law written as a vector equation.', { size: 10.4, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += txfit(24, 268, 'Rotating the crystal rotates the reciprocal lattice through the sphere — which is exactly what a powder sample does statistically, all at once.', { w: 464, size: 10.2, fill: C.ink3, style: 'italic' });
    return svg(500, 292, b);
  };

  /* 16 · electron density as a Fourier sum */
  D['fourier-density'] = function () {
    var b = '', ox = 34, oy = 120, w = 200, h = 66;
    b += txfit(20, 20, 'A periodic electron density IS a Fourier series', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    b += ax(ox, oy, w, h, 'x', 'n(x)');
    var terms = [
      { n: 1, col: C.blue }, { n: 2, col: C.green }, { n: 3, col: C.amber }
    ];
    terms.forEach(function (t, k) {
      b += path(fn(function (x) { return 0.5 + 0.32 * Math.cos(2 * Math.PI * t.n * x); }, 0, 2, 120,
        function (x) { return ox + x / 2 * w; }, function (v) { return oy - v * h; }), { stroke: t.col, w: 1.5, op: .75 });
    });
    b += tx(ox, oy + 22, 'three Fourier components, each with its own G = 2πn/a', { size: 9.8, fill: C.ink3 });

    b += arr(258, 90, 296, 90, { color: C.ink3, w: 2, label: 'sum', ly: -7 });

    var o2 = 312, w2 = 158;
    b += ax(o2, oy, w2, h, 'x', 'n(x)');
    b += path(fn(function (x) {
      return 0.30 + 0.24 * Math.cos(2 * Math.PI * x) + 0.20 * Math.cos(4 * Math.PI * x) + 0.14 * Math.cos(6 * Math.PI * x);
    }, 0, 2, 160, function (x) { return o2 + x / 2 * w2; }, function (v) { return oy - v * h; }), { stroke: C.crimson, w: 2.4 });
    b += tx(o2, oy + 22, 'sharper peaks at the atom sites', { size: 9.8, fill: C.ink3 });

    b += bx(24, 162, 452, 'n(r) = Σ_G  n_G · exp(iG·r).  The crystal only admits wavevectors G that belong to the reciprocal lattice — every other frequency averages to zero over the periodic structure. This is the reason diffraction gives discrete spots rather than a continuous blur.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += txfit(24, 246, 'Adding more Fourier components sharpens the peaks — which is the same statement as: measuring more reflections resolves finer structural detail.', { w: 464, size: 10.2, fill: C.ink3, style: 'italic' });
    return svg(500, 272, b);
  };

  /* 17 · constructing the first Brillouin zone */
  D['brillouin-construction'] = function () {
    var b = '', cx0 = 108, cy = 140, sp = 52, i, j;
    var stages = ['1 · The reciprocal lattice', '2 · Draw G to the neighbours', '3 · Bisect each G perpendicularly'];
    [0, 1, 2].forEach(function (k) {
      var cx = cx0 + k * 154;
      b += txw(cx - 62, 22, stages[k], 24, { size: 10.8, fill: C.navy, weight: 800 });
      for (i = -2; i <= 2; i++) for (j = -2; j <= 2; j++) {
        var px = cx + i * sp, py = cy + j * sp;
        if (px < cx - 66 || px > cx + 66 || py < cy - 66 || py > cy + 66) continue;
        b += dot(px, py, 3.4, (i === 0 && j === 0) ? C.crimson : C.ink3);
      }
      if (k >= 1) {
        [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]].forEach(function (v) {
          b += arr(cx, cy, cx + v[0] * sp, cy + v[1] * sp, { color: C.purple, w: 1.2 });
        });
      }
      if (k === 2) {
        [[1,0],[-1,0],[0,1],[0,-1]].forEach(function (v) {
          var mx = cx + v[0] * sp / 2, my = cy + v[1] * sp / 2;
          b += ln(mx - v[1] * 40, my - v[0] * 40, mx + v[1] * 40, my + v[0] * 40, { color: C.crimson, w: 1.5, dash: '4 3' });
        });
        b += rect(cx - sp / 2, cy - sp / 2, sp, sp, { fill: 'rgba(158,27,50,.16)', stroke: C.crimson, w: 2.2 });
        b += tx(cx, cy + 4, 'BZ', { size: 11, fill: C.crimson, anchor: 'middle', weight: 800 });
      }
    });
    b += bx(24, 218, 452, 'The first Brillouin zone is the set of points closer to one reciprocal-lattice point than to any other — a Wigner–Seitz cell built in reciprocal space. Its boundary is exactly where the Bragg condition is satisfied, which is why every gap in this course opens there.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 310, b);
  };

  /* 18 · why the BCC (100) reflection cancels */
  D['structure-factor-cancel'] = function () {
    var b = '';
    b += tx(20, 20, 'A systematic absence is a phase cancellation inside the unit cell', { size: 11.8, fill: C.navy, weight: 800 });
    /* left: real space with (100) planes and the intervening body-centre plane */
    var ox = 34, oy = 56, s = 132;
    b += rect(ox, oy, s, s, { stroke: C.ink3, w: 1.4, fill: C.paper2 });
    [[0,0],[1,0],[0,1],[1,1]].forEach(function (v) { b += dot(ox + v[0]*s, oy + v[1]*s, 7, C.blue); });
    b += dot(ox + s/2, oy + s/2, 7, C.amber);
    b += ln(ox, oy - 12, ox, oy + s + 12, { color: C.crimson, w: 2 });
    b += ln(ox + s, oy - 12, ox + s, oy + s + 12, { color: C.crimson, w: 2 });
    b += ln(ox + s/2, oy - 12, ox + s/2, oy + s + 12, { color: C.amber, w: 2, dash: '5 4' });
    b += tx(ox, oy + s + 28, '(100) planes', { size: 10, fill: C.crimson, weight: 700 });
    b += txfit(ox, oy + s + 44, 'the body-centre plane sits exactly halfway', { w: 190, size: 10, fill: C.amber, weight: 700 });

    /* right: the two waves */
    var o2 = 236, base = 96;
    b += tx(o2, 46, 'Wave from the corner atoms', { size: 10.4, fill: C.blue, weight: 700 });
    b += path(fn(function (x) { return Math.sin(x * 2 * Math.PI); }, 0, 2, 100,
      function (x) { return o2 + x / 2 * 230; }, function (v) { return base + v * 18; }), { stroke: C.blue, w: 2 });
    b += tx(o2, 150, 'Wave from the body-centre atoms', { size: 10.4, fill: C.amber, weight: 700 });
    b += path(fn(function (x) { return Math.sin(x * 2 * Math.PI + Math.PI); }, 0, 2, 100,
      function (x) { return o2 + x / 2 * 230; }, function (v) { return base + 104 + v * 18; }), { stroke: C.amber, w: 2 });
    b += tx(o2, 232, 'Sum', { size: 10.4, fill: C.crimson, weight: 700 });
    b += ln(o2, 252, o2 + 230, 252, { color: C.crimson, w: 2.4 });
    b += tx(o2 + 236, 256, '0', { size: 12, fill: C.crimson, weight: 800 });

    b += bx(24, 268, 452, 'For (100) in BCC the extra half-spacing puts the body-centre wave exactly π out of phase. F₁₀₀ = f(1 + e^{iπ}) = 0. The plane family exists and Bragg’s law is satisfied — but no intensity arrives. Hence the BCC rule: h + k + l must be even.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 346, b);
  };

  /* 19 · selection rules side by side */
  D['selection-rules'] = function () {
    var b = '';
    b += tx(20, 20, 'The same planes, three different lattices, three different patterns', { size: 11.8, fill: C.navy, weight: 800 });
    var refl = ['100', '110', '111', '200', '210', '211', '220', '221', '300', '310', '311', '222'];
    var sums = refl.map(function (r) { return r.split('').map(Number); });
    var rows = [
      { name: 'SC', col: C.blue, ok: function () { return true; } },
      { name: 'BCC', col: C.green, ok: function (v) { return (v[0] + v[1] + v[2]) % 2 === 0; } },
      { name: 'FCC', col: C.crimson, ok: function (v) { var e = v.filter(function (x) { return x % 2 === 0; }).length; return e === 3 || e === 0; } }
    ];
    var x0 = 74, cw = 34;
    refl.forEach(function (r, i) {
      b += tx(x0 + i * cw + cw / 2, 54, r, { size: 10.4, fill: C.ink3, anchor: 'middle', mono: true, weight: 700 });
    });
    rows.forEach(function (row, k) {
      var y = 76 + k * 40;
      b += tx(64, y + 16, row.name, { size: 12, fill: row.col, anchor: 'end', weight: 800 });
      refl.forEach(function (r, i) {
        var allowed = row.ok(sums[i]);
        var cx = x0 + i * cw + cw / 2;
        if (allowed) { b += rect(cx - 12, y, 24, 26, { rx: 4, fill: row.col, op: .82 }); b += tx(cx, y + 18, '●', { size: 11, fill: '#fff', anchor: 'middle' }); }
        else { b += rect(cx - 12, y, 24, 26, { rx: 4, fill: 'none', stroke: C.rule, w: 1.2, dash: '3 2' }); }
      });
    });
    b += tx(24, 208, 'Filled = allowed reflection.  Dashed = systematically absent.', { size: 10.2, fill: C.ink3 });
    b += bx(24, 220, 452, 'BCC: h+k+l even.   FCC: h, k, l all even or all odd.   SC: everything is allowed. Read a powder pattern by its ABSENCES, not only by its peaks — the missing lines are what identify the centring.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 283, b);
  };
})();

/* ── Topic 5 · crystal bonding ─────────────────────────────── */
(function () {
  'use strict';
  var P = window.PHY3201, H = P.diagramHelpers, D = P.diagrams;
  var svg = H.svg, tx = H.tx, txw = H.txw, txfit = H.txfit, bx = H.bx, arr = H.arr, ln = H.ln,
      dot = H.dot, ring = H.ring, path = H.path, rect = H.rect, ax = H.ax, fn = H.fn;
  var C = { ink: 'var(--ink)', ink2: 'var(--ink-2)', ink3: 'var(--ink-3)', navy: 'var(--navy)',
            blue: 'var(--structure)', purple: 'var(--diffraction)', green: 'var(--bonding)',
            amber: 'var(--phonon)', cyan: 'var(--electron)', crimson: 'var(--crimson)',
            rule: 'var(--rule)', paper: 'var(--paper)', paper2: 'var(--paper-2)' };

  /* 20 · Lennard-Jones: U(r), F(r), and where r0 comes from */
  D['lj-potential'] = function () {
    var b = '', ox = 60, oy = 178, w = 250, h = 150;
    var sig = 1, eps = 1;
    function U(x) { return 4 * eps * (Math.pow(sig / x, 12) - Math.pow(sig / x, 6)); }
    function F(x) { return 24 * eps / x * (2 * Math.pow(sig / x, 12) - Math.pow(sig / x, 6)); }
    var x0 = 0.94, x1 = 2.5, yS = 34, y0line = oy - 60;
    function SX(x) { return ox + (x - x0) / (x1 - x0) * w; }
    function SY(v) { return y0line - v * yS; }
    b += txfit(20, 20, 'The interatomic potential sets the equilibrium spacing AND the stiffness', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    /* axes */
    b += ln(ox, y0line, ox + w + 14, y0line, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy - 150, ox, oy + 26, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 18, y0line + 4, 'r', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox - 8, oy - 134, 'U(r)', { size: 11.5, fill: C.ink3, anchor: 'end', weight: 700 });
    /* the two terms */
    b += path(fn(function (x) { return Math.min(2.3, 4 * Math.pow(sig / x, 12)); }, x0, x1, 140, SX, SY), { stroke: C.crimson, w: 1.5, dash: '5 3', op: .75 });
    b += path(fn(function (x) { return Math.max(-2.3, -4 * Math.pow(sig / x, 6)); }, x0, x1, 140, SX, SY), { stroke: C.blue, w: 1.5, dash: '5 3', op: .75 });
    b += tx(SX(1.12), SY(1.85), 'repulsive  +A/r¹²', { size: 9.8, fill: C.crimson, weight: 700 });
    b += tx(SX(1.9), SY(-1.5), 'attractive  −B/r⁶', { size: 9.8, fill: C.blue, weight: 700 });
    /* total */
    b += path(fn(function (x) { return Math.max(-2.3, Math.min(2.3, U(x))); }, x0, x1, 200, SX, SY), { stroke: C.green, w: 2.8 });
    /* minimum */
    var rmin = Math.pow(2, 1 / 6) * sig;
    b += ln(SX(rmin), SY(0), SX(rmin), SY(U(rmin)), { color: C.ink3, w: 1.2, dash: '3 3' });
    b += dot(SX(rmin), SY(U(rmin)), 5, C.green);
    b += tx(SX(rmin), SY(0) - 4, 'r₀', { size: 12, fill: C.green, anchor: 'middle', weight: 800 });
    b += ln(ox, SY(U(rmin)), SX(rmin), SY(U(rmin)), { color: C.ink3, w: 1.2, dash: '3 3' });
    b += tx(ox - 8, SY(U(rmin)) + 4, '−ε', { size: 11, fill: C.green, anchor: 'end', weight: 800 });
    /* curvature annotation */
    b += path('M' + SX(rmin - 0.16) + ',' + SY(U(rmin) + 0.30) + ' Q' + SX(rmin) + ',' + SY(U(rmin) - 0.42) + ' ' + SX(rmin + 0.20) + ',' + SY(U(rmin) + 0.30), { stroke: C.amber, w: 2.4, dash: '3 3' });
    b += tx(SX(rmin) + 46, SY(U(rmin)) + 26, 'curvature d²U/dr² = K', { size: 9.8, fill: C.amber, weight: 700 });

    /* right panel */
    b += bx(342, 44, 142, 'At r₀:  dU/dr = 0  →  net force zero, and d²U/dr² > 0  →  the equilibrium is stable.', { size: 10.4, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += bx(342, 128, 142, 'Depth ε is the cohesive energy scale — it sets melting point and bond strength.', { size: 10.4, color: C.green, fill: '#EAF6F0', stroke: '#BFE0CF' });
    b += bx(342, 212, 142, 'Curvature K is the spring constant that Topic 6 turns into phonons. Bonding and vibration are the same physics.', { size: 10.4, color: C.amber, fill: 'var(--warn-bg)', stroke: '#EBD5A8' });
    return svg(500, 318, b);
  };

  /* 21 · the van der Waals-London mechanism */
  D['vdw-mechanism'] = function () {
    var b = '';
    b += tx(20, 20, 'Why two neutral, spherical atoms still attract', { size: 11.8, fill: C.navy, weight: 800 });
    var panels = [
      { t: 'Time-averaged', s: 'Both clouds are spherical. No permanent dipole on either atom.' },
      { t: 'An instant later', s: 'A quantum fluctuation displaces the cloud on the left atom. It now has an instantaneous dipole.' },
      { t: 'The response', s: 'That dipole field polarises the right atom. The induced dipole always points so the interaction is ATTRACTIVE.' }
    ];
    panels.forEach(function (p, k) {
      var ox = 18 + k * 160, cy = 106;
      b += rect(ox, 40, 148, 108, { rx: 8, fill: C.paper2, stroke: C.rule });
      b += tx(ox + 8, 58, p.t, { size: 10.8, fill: C.navy, weight: 800 });
      var ax1 = ox + 42, ax2 = ox + 106;
      if (k === 0) {
        b += '<circle cx="' + ax1 + '" cy="' + cy + '" r="20" fill="' + C.cyan + '" opacity=".22"/>' + dot(ax1, cy, 4, C.ink2);
        b += '<circle cx="' + ax2 + '" cy="' + cy + '" r="20" fill="' + C.cyan + '" opacity=".22"/>' + dot(ax2, cy, 4, C.ink2);
      } else {
        b += '<ellipse cx="' + (ax1 - 4) + '" cy="' + cy + '" rx="22" ry="18" fill="' + C.cyan + '" opacity=".22"/>' + dot(ax1 + 5, cy, 4, C.ink2);
        b += tx(ax1 - 18, cy - 24, '−', { size: 15, fill: C.blue, weight: 800 }); b += tx(ax1 + 16, cy - 24, '+', { size: 15, fill: C.crimson, weight: 800 });
        if (k === 1) { b += '<circle cx="' + ax2 + '" cy="' + cy + '" r="20" fill="' + C.cyan + '" opacity=".22"/>' + dot(ax2, cy, 4, C.ink2); }
        else {
          b += '<ellipse cx="' + (ax2 - 4) + '" cy="' + cy + '" rx="22" ry="18" fill="' + C.cyan + '" opacity=".22"/>' + dot(ax2 + 5, cy, 4, C.ink2);
          b += tx(ax2 - 18, cy - 24, '−', { size: 15, fill: C.blue, weight: 800 }); b += tx(ax2 + 16, cy - 24, '+', { size: 15, fill: C.crimson, weight: 800 });
          b += arr(ax1 + 26, cy + 26, ax2 - 12, cy + 26, { color: C.green, w: 2 });
          b += arr(ax2 - 4, cy + 26, ax1 + 34, cy + 26, { color: C.green, w: 2 });
        }
      }
      b += txw(ox + 8, 162, p.s, 30, { size: 9.8, fill: C.ink3 });
    });
    b += bx(24, 214, 452, 'The interaction energy falls off as −1/r⁶ because it is a dipole field (1/r³) acting on a dipole it induced itself (another 1/r³). It is weak, always present, and it is the ONLY thing holding an inert-gas crystal together — which is why solid argon melts at 84 K.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 306, b);
  };

  /* 22 · Madelung: why the 1-D chain sum converges to 2 ln 2 */
  D['madelung-chain'] = function () {
    var b = '', y = 92, sp = 46, x0 = 46, i;
    b += txfit(20, 20, 'The Madelung constant is an infinite alternating sum', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    for (i = 0; i < 9; i++) {
      var x = x0 + i * sp, pos = i % 2 === 0;
      b += '<circle cx="' + x + '" cy="' + y + '" r="15" fill="' + (pos ? C.crimson : C.blue) + '" opacity=".85"/>';
      b += tx(x, y + 5, pos ? '+' : '−', { size: 16, fill: '#fff', anchor: 'middle', weight: 800 });
    }
    var ref = x0 + 4 * sp;
    b += ring(ref, y, 22, C.navy, 2.4);
    b += tx(ref, y - 32, 'reference ion', { size: 10, fill: C.navy, anchor: 'middle', weight: 800 });
    /* neighbour shells */
    [[1, '−2/R', C.green], [2, '+2/2R', C.crimson], [3, '−2/3R', C.green], [4, '+2/4R', C.crimson]].forEach(function (t, k) {
      var yy = y + 40 + k * 21;
      b += ln(ref - t[0] * sp, yy, ref + t[0] * sp, yy, { color: t[2], w: 1.4 });
      b += tx(ref + t[0] * sp + 8, yy + 4, t[1] + (t[0] === 1 ? '  nearest' : '  shell ' + t[0]), { size: 9.8, fill: t[2], weight: 700 });
    });
    b += bx(24, 234, 452, 'α = 2(1 − 1/2 + 1/3 − 1/4 + …) = 2 ln 2 ≈ 1.386 for the 1-D chain. The series alternates and converges slowly — a nearest-neighbour-only estimate overshoots by nearly a third. In 3-D: α = 1.7476 (NaCl), 1.7627 (CsCl), 1.6381 (zincblende).', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 312, b);
  };

  /* 23 · the four bonding types, by where the electrons sit */
  D['bonding-types'] = function () {
    var b = '';
    var P4 = [
      { t: 'van der Waals', s: 'Closed shells. Only fluctuating-dipole attraction. Weak, non-directional.', e: '0.01 – 0.1 eV', ex: 'Ar, Ne, CH₄, graphite between sheets', col: C.cyan },
      { t: 'Ionic', s: 'One atom transfers an electron. Electrostatic attraction between closed-shell ions.', e: '5 – 10 eV', ex: 'NaCl, MgO, CsCl', col: C.crimson },
      { t: 'Covalent', s: 'Electrons SHARED in directional bonds. Strong and stiff, fixed bond angles.', e: '3 – 8 eV', ex: 'C (diamond), Si, Ge, SiC', col: C.green },
      { t: 'Metallic', s: 'Valence electrons delocalise over the whole crystal. Non-directional, so metals deform.', e: '1 – 5 eV', ex: 'Na, Cu, Al, Fe', col: C.amber }
    ];
    P4.forEach(function (p, k) {
      var ox = 14 + k * 121, cy = 92;
      b += rect(ox, 36, 112, 96, { rx: 8, fill: C.paper2, stroke: C.rule });
      b += tx(ox + 56, 30, p.t, { size: 11.4, fill: p.col, anchor: 'middle', weight: 800 });
      var a1 = ox + 34, a2 = ox + 78;
      if (k === 0) {
        b += '<circle cx="' + a1 + '" cy="' + cy + '" r="17" fill="' + p.col + '" opacity=".22"/>' + dot(a1, cy, 4, C.ink2);
        b += '<circle cx="' + a2 + '" cy="' + cy + '" r="17" fill="' + p.col + '" opacity=".22"/>' + dot(a2, cy, 4, C.ink2);
        b += ln(a1 + 19, cy, a2 - 19, cy, { color: p.col, w: 1.2, dash: '2 3' });
      } else if (k === 1) {
        b += '<circle cx="' + a1 + '" cy="' + cy + '" r="12" fill="' + C.crimson + '" opacity=".7"/>' + tx(a1, cy + 5, '+', { size: 15, fill: '#fff', anchor: 'middle', weight: 800 });
        b += '<circle cx="' + a2 + '" cy="' + cy + '" r="19" fill="' + C.blue + '" opacity=".55"/>' + tx(a2, cy + 5, '−', { size: 15, fill: '#fff', anchor: 'middle', weight: 800 });
        b += arr(a1 + 14, cy - 22, a2 - 6, cy - 22, { color: C.ink3, w: 1.4, label: 'e⁻', ly: -5, lsize: 9.5 });
      } else if (k === 2) {
        b += dot(a1, cy, 8, C.ink2) + dot(a2, cy, 8, C.ink2);
        b += '<ellipse cx="' + ((a1 + a2) / 2) + '" cy="' + cy + '" rx="26" ry="11" fill="' + p.col + '" opacity=".33"/>';
        b += dot((a1 + a2) / 2 - 6, cy, 3, p.col) + dot((a1 + a2) / 2 + 6, cy, 3, p.col);
      } else {
        b += rect(ox + 14, cy - 22, 84, 44, { rx: 6, fill: p.col, op: .18 });
        [0, 1, 2].forEach(function (i) { for (var j = 0; j < 2; j++) b += dot(ox + 30 + i * 26, cy - 10 + j * 20, 6.5, C.ink2); });
        [0, 1, 2, 3, 4, 5, 6].forEach(function (i) { b += dot(ox + 20 + i * 12, cy + (i % 2 ? -18 : 16), 2.6, p.col); });
      }
      b += tx(ox + 56, 148, p.e, { size: 10.6, fill: p.col, anchor: 'middle', weight: 800, mono: true });
      b += txw(ox, 164, p.s, 26, { size: 9.4, fill: C.ink3 });
      b += txw(ox, 214, p.ex, 26, { size: 9.2, fill: C.ink2, style: 'italic' });
    });
    b += txfit(250, 250, 'Cohesive energy per atom. Real solids mix these — Si has a little ionicity, graphite is covalent in-plane and van der Waals between planes.', { w: 476, size: 10.2, fill: C.ink3, anchor: 'middle', style: 'italic' });
    return svg(500, 274, b);
  };

  /* 24 · same element, different bonding geometry */
  D['diamond-vs-graphite'] = function () {
    var b = '';
    b += txfit(20, 20, 'Carbon: identical atoms, different bonding geometry, opposite properties', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    /* diamond: sp3 tetrahedron */
    b += tx(60, 48, 'Diamond — sp³', { size: 11.5, fill: C.green, weight: 800 });
    var cx = 108, cy = 122;
    b += dot(cx, cy, 9, C.ink2);
    [[0, -46], [-40, 24], [40, 24], [8, 16]].forEach(function (v, i) {
      b += ln(cx, cy, cx + v[0], cy + v[1], { color: C.green, w: i === 3 ? 1.5 : 2.4, dash: i === 3 ? '4 3' : '' });
      b += dot(cx + v[0], cy + v[1], 7, C.ink3);
    });
    b += tx(cx, cy + 68, '4 σ bonds, 109.5°, rigid 3-D net', { size: 9.8, fill: C.ink3, anchor: 'middle' });
    b += txw(30, 208, 'Every valence electron is locked into a bond. Hardest known material; wide band gap 5.5 eV → an electrical insulator; and the stiff, light lattice makes it the best bulk thermal conductor known.', 40, { size: 9.8, fill: C.ink3 });

    b += ln(250, 40, 250, 268, { color: C.rule, w: 1 });

    /* graphite: sp2 sheets */
    b += tx(292, 48, 'Graphite — sp²', { size: 11.5, fill: C.amber, weight: 800 });
    function hexrow(ox, oy) {
      var o = '', i, R = 17;
      for (i = 0; i < 3; i++) {
        var hx = ox + i * R * 3, hy = oy;
        var pts = [];
        for (var a = 0; a < 6; a++) { var t = Math.PI / 6 + a * Math.PI / 3; pts.push([hx + R * Math.cos(t), hy + R * Math.sin(t) * 0.55]); }
        o += '<polygon points="' + pts.map(function (p) { return p.join(','); }).join(' ') + '" fill="none" stroke="' + C.amber + '" stroke-width="1.8"/>';
      }
      return o;
    }
    b += hexrow(300, 96) + hexrow(300, 134) + hexrow(300, 172);
    b += arr(438, 96, 438, 134, { color: C.cyan, both: true, w: 1.4 });
    b += tx(444, 118, 'van der', { size: 9.2, fill: C.cyan, weight: 700 });
    b += tx(444, 129, 'Waals gap', { size: 9.2, fill: C.cyan, weight: 700 });
    b += tx(360, 200, '3 σ bonds + delocalised π, 120°', { size: 9.8, fill: C.ink3, anchor: 'middle' });
    b += txw(288, 216, 'The fourth electron delocalises within each sheet → conducts in-plane. Sheets are held only by van der Waals forces → they slide, so graphite is a lubricant and writes on paper.', 40, { size: 9.8, fill: C.ink3 });
    return svg(500, 277, b);
  };
})();

/* ── Topics 6–7 · lattice dynamics ─────────────────────────── */
(function () {
  'use strict';
  var P = window.PHY3201, H = P.diagramHelpers, D = P.diagrams;
  var svg = H.svg, tx = H.tx, txw = H.txw, txfit = H.txfit, bx = H.bx, arr = H.arr, ln = H.ln,
      dot = H.dot, ring = H.ring, path = H.path, rect = H.rect, ax = H.ax, fn = H.fn;
  var C = { ink: 'var(--ink)', ink2: 'var(--ink-2)', ink3: 'var(--ink-3)', navy: 'var(--navy)',
            blue: 'var(--structure)', purple: 'var(--diffraction)', green: 'var(--bonding)',
            amber: 'var(--phonon)', cyan: 'var(--electron)', crimson: 'var(--crimson)',
            rule: 'var(--rule)', paper: 'var(--paper)', paper2: 'var(--paper-2)' };

  function spring(x1, x2, y, col, coils) {
    coils = coils || 6;
    var d = 'M' + x1 + ',' + y, n = coils * 2, w = (x2 - x1) / n, i;
    for (i = 1; i <= n; i++) d += ' L' + (x1 + i * w) + ',' + (y + (i % 2 ? -6 : 6));
    d += ' L' + x2 + ',' + y;
    return path(d, { stroke: col || C.ink3, w: 1.4 });
  }

  /* 25 · the monatomic chain */
  D['monatomic-chain'] = function () {
    var b = '', y = 84, sp = 62, x0 = 44, i;
    b += tx(20, 20, 'The model: identical masses M, identical springs C, spacing a', { size: 11.8, fill: C.navy, weight: 800 });
    for (i = 0; i < 7; i++) {
      var x = x0 + i * sp;
      if (i < 6) b += spring(x + 15, x + sp - 15, y, C.ink3);
      var disp = (i === 3) ? 13 : 0;
      if (disp) b += ring(x, y, 15, C.rule, 1.2);
      b += '<circle cx="' + (x + disp) + '" cy="' + y + '" r="15" fill="' + (disp ? C.crimson : C.blue) + '" opacity=".85"/>';
      b += tx(x + disp, y + 5, 'M', { size: 11, fill: '#fff', anchor: 'middle', weight: 800 });
      b += tx(x, y + 34, 'u' + (i > 3 ? '' : '') + (['ₙ₋₃','ₙ₋₂','ₙ₋₁','ₙ','ₙ₊₁','ₙ₊₂','ₙ₊₃'][i]), { size: 10.5, fill: C.ink3, anchor: 'middle', mono: true });
    }
    b += arr(x0 + 3 * sp, y - 26, x0 + 3 * sp + 13, y - 26, { color: C.crimson, w: 1.8 });
    b += tx(x0 + 3 * sp + 20, y - 22, 'displacement uₙ', { size: 10, fill: C.crimson, weight: 700 });
    b += arr(x0, y + 52, x0 + sp, y + 52, { color: C.ink3, both: true, w: 1.3 });
    b += tx(x0 + sp / 2, y + 68, 'a', { size: 12, fill: C.ink3, anchor: 'middle', weight: 800, style: 'italic' });

    b += bx(24, 168, 452, 'Newton for atom n:   M · d²uₙ/dt² = C(uₙ₊₁ − uₙ) + C(uₙ₋₁ − uₙ) = C(uₙ₊₁ + uₙ₋₁ − 2uₙ)', { size: 12, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += txw(24, 222, 'Only the RELATIVE displacements matter. If every atom moves by the same amount the crystal simply translates and no force appears — which is why ω → 0 as k → 0.', 84, { size: 10.6, fill: C.ink3 });
    return svg(500, 246, b);
  };

  /* 26 · monatomic dispersion */
  D['dispersion-mono'] = function () {
    var b = '', ox = 250, oy = 190, w = 190, h = 132;
    b += tx(20, 20, 'One atom per cell: a single acoustic branch, flat at the zone boundary', { size: 11.8, fill: C.navy, weight: 800 });
    /* axes, k from -pi/a to pi/a */
    b += ln(ox - w, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy + 8, ox, oy - h - 14, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 16, oy + 4, 'k', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox + 6, oy - h - 18, 'ω', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox + w, oy + 18, 'π/a', { size: 10.5, fill: C.ink3, anchor: 'middle', weight: 700 });
    b += tx(ox - w, oy + 18, '−π/a', { size: 10.5, fill: C.ink3, anchor: 'middle', weight: 700 });
    b += tx(ox, oy + 18, '0', { size: 10.5, fill: C.ink3, anchor: 'middle' });
    /* BZ shading */
    b += rect(ox - w, oy - h - 6, 2 * w, h + 6, { fill: 'rgba(23,39,92,.045)' });
    b += ln(ox + w, oy, ox + w, oy - h - 6, { color: C.crimson, w: 1.6, dash: '5 4' });
    b += ln(ox - w, oy, ox - w, oy - h - 6, { color: C.crimson, w: 1.6, dash: '5 4' });
    /* the curve */
    b += path(fn(function (t) { return Math.abs(Math.sin(t * Math.PI / 2)); }, -1, 1, 200,
      function (t) { return ox + t * w; }, function (v) { return oy - v * h; }), { stroke: C.amber, w: 2.8 });
    /* long wavelength tangent */
    b += ln(ox, oy, ox + 0.55 * w, oy - 0.55 * h * (Math.PI / 2), { color: C.blue, w: 1.6, dash: '4 3' });
    b += tx(ox + 30, oy - 96, 'ω ≈ v_s k', { size: 10.4, fill: C.blue, weight: 700 });
    b += tx(ox + 30, oy - 84, 'sound', { size: 9.4, fill: C.blue });
    /* flat at boundary */
    b += ln(ox + w - 34, oy - h, ox + w + 4, oy - h, { color: C.green, w: 2, dash: '3 3' });
    b += tx(ox + w - 40, oy - h - 8, 'v_g = dω/dk = 0', { size: 10.2, fill: C.green, anchor: 'end', weight: 700 });
    b += tx(ox - w + 6, oy - h - 8, 'ω_max = 2√(C/M)', { size: 10.2, fill: C.amber, weight: 700 });

    b += bx(24, 212, 452, 'ω(k) = 2√(C/M) · |sin(ka/2)|.   Outside the first zone the pattern of ATOMIC motion simply repeats — a k beyond π/a describes no new physical mode, only the same displacements relabelled. That is why the whole of lattice dynamics is discussed inside one Brillouin zone.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 304, b);
  };

  /* 27 · aliasing: why k outside the zone is not new */
  D['zone-aliasing'] = function () {
    var b = '', y = 78, sp = 48, x0 = 50, i;
    b += tx(20, 20, 'Two very different wavelengths, the SAME atomic displacements', { size: 11.8, fill: C.navy, weight: 800 });
    b += path(fn(function (x) { return Math.sin(2 * Math.PI * x / (2)); }, 0, 8, 200,
      function (x) { return x0 + x * sp; }, function (v) { return y - v * 22; }), { stroke: C.blue, w: 2, op: .85 });
    b += path(fn(function (x) { return Math.sin(2 * Math.PI * x * 1.5 / 2 + Math.PI); }, 0, 8, 300,
      function (x) { return x0 + x * sp; }, function (v) { return y - v * 22; }), { stroke: C.crimson, w: 1.6, dash: '5 3', op: .8 });
    for (i = 0; i <= 8; i++) {
      var x = x0 + i * sp, v = Math.sin(2 * Math.PI * i / 2);
      b += ln(x, y, x, y - v * 22, { color: C.rule, w: 1 });
      b += dot(x, y - v * 22, 6, C.ink2);
    }
    b += ln(x0 - 10, y, x0 + 8 * sp + 10, y, { color: C.rule, w: 1, dash: '3 3' });
    b += tx(x0, y + 42, 'k inside the zone', { size: 10.2, fill: C.blue, weight: 700 });
    b += txfit(x0 + 200, y + 42, 'k outside — through the same atoms', { w: 238, size: 10.2, fill: C.crimson, weight: 700 });
    b += txw(24, 142, 'The atoms only sample the wave at discrete positions x = na. Any wave shorter than 2a is indistinguishable, at those sampling points, from a longer one inside the first zone. Restricting k to −π/a ≤ k ≤ π/a removes the duplicates and nothing else.', 84, { size: 10.6, fill: C.ink3 });
    return svg(500, 180, b);
  };

  /* 28 · diatomic chain and its two branches */
  D['diatomic-dispersion'] = function () {
    var b = '', y = 78, sp = 54, x0 = 40, i;
    b += txfit(20, 20, 'Two atoms per primitive cell → two branches, and a forbidden frequency gap', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    for (i = 0; i < 8; i++) {
      var x = x0 + i * sp * 0.62, big = i % 2 === 0;
      if (i < 7) b += spring(x + (big ? 13 : 9), x + sp * 0.62 - (big ? 9 : 13), y, C.ink3, 4);
      b += '<circle cx="' + x + '" cy="' + y + '" r="' + (big ? 13 : 9) + '" fill="' + (big ? C.blue : C.amber) + '" opacity=".85"/>';
    }
    b += tx(x0, y + 30, 'M', { size: 10.5, fill: C.blue, anchor: 'middle', weight: 800 });
    b += tx(x0 + sp * 0.62, y + 30, 'm', { size: 10.5, fill: C.amber, anchor: 'middle', weight: 800 });
    b += tx(x0 + 56, y + 30, 'alternating masses · one repeat = a', { size: 10, fill: C.ink3 });

    var ox = 300, oy = 236, w = 168, h = 150;
    b += ln(ox, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy + 6, ox, oy - h - 14, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 16, oy + 4, 'k', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox + 6, oy - h - 18, 'ω', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox + w, oy + 18, 'π/a', { size: 10.5, fill: C.ink3, anchor: 'middle', weight: 700 });
    b += tx(ox, oy + 18, '0', { size: 10.5, fill: C.ink3, anchor: 'middle' });
    var M = 2, m = 1, Cc = 1;
    function branches(t) {
      var ka = t * Math.PI, s = Math.sin(ka / 2);
      var A = Cc * (1 / M + 1 / m), B = Math.sqrt(Math.max(0, A * A - 4 * Cc * Cc * s * s / (M * m)));
      return [Math.sqrt(A - B), Math.sqrt(A + B)];
    }
    var wmax = branches(0.0001)[1] * 1.06;
    b += path(fn(function (t) { return branches(t)[0]; }, 0.0001, 1, 120,
      function (t) { return ox + t * w; }, function (v) { return oy - v / wmax * h; }), { stroke: C.green, w: 2.6 });
    b += path(fn(function (t) { return branches(t)[1]; }, 0.0001, 1, 120,
      function (t) { return ox + t * w; }, function (v) { return oy - v / wmax * h; }), { stroke: C.crimson, w: 2.6 });
    var gLo = branches(1)[0] / wmax * h, gHi = branches(1)[1] / wmax * h, gTop = branches(0)[1] / wmax * h;
    b += rect(ox, oy - gHi, w, gHi - gLo, { fill: 'rgba(158,27,50,.11)' });
    b += tx(ox + w / 2, oy - (gHi + gLo) / 2 + 4, 'FORBIDDEN', { size: 9.6, fill: C.crimson, anchor: 'middle', weight: 800 });
    b += tx(ox + 6, oy - gTop - 8, 'optical branch', { size: 10.2, fill: C.crimson, weight: 700 });
    b += tx(ox + w - 4, oy - 26, 'acoustic branch', { size: 10.2, fill: C.green, anchor: 'end', weight: 700 });

    b += bx(24, 128, 250, 'Acoustic branch: the two atoms move IN PHASE. At long wavelength this is an ordinary sound wave, ω → 0.', { size: 10.6, color: C.green, fill: '#EAF6F0', stroke: '#BFE0CF' });
    b += bx(24, 196, 250, 'Optical branch: the two atoms move OUT OF PHASE against each other. Finite ω even at k = 0. If the atoms carry opposite charge, this motion is an oscillating dipole — which is why it couples to infrared light and gets its name.', { size: 10.6, color: C.crimson, fill: 'var(--stop-bg)', stroke: '#EECAD1' });
    return svg(500, 313, b);
  };

  /* 29 · what acoustic and optical motion actually look like */
  D['acoustic-vs-optical'] = function () {
    var b = '', sp = 46, x0 = 60, i;
    b += tx(20, 20, 'The same chain, the same k — two different patterns of motion', { size: 11.8, fill: C.navy, weight: 800 });
    [{ y: 76, t: 'ACOUSTIC · in phase', c: C.green, ph: 0 },
     { y: 168, t: 'OPTICAL · out of phase', c: C.crimson, ph: Math.PI }].forEach(function (row) {
      b += tx(24, row.y - 30, row.t, { size: 11, fill: row.c, weight: 800 });
      for (i = 0; i < 8; i++) {
        var x = x0 + i * sp, big = i % 2 === 0;
        var env = Math.sin(2 * Math.PI * i / 8);
        var d = env * 13 * (big ? 1 : Math.cos(row.ph));
        b += ring(x, row.y, big ? 12 : 8, C.rule, 1);
        b += '<circle cx="' + (x + d) + '" cy="' + row.y + '" r="' + (big ? 12 : 8) + '" fill="' + (big ? C.blue : C.amber) + '" opacity=".85"/>';
        if (Math.abs(d) > 2) b += arr(x, row.y + (big ? 20 : 16), x + d, row.y + (big ? 20 : 16), { color: row.c, w: 1.4 });
      }
    });
    b += tx(x0, 214, 'Heavy atom', { size: 9.8, fill: C.blue, weight: 700 });
    b += tx(x0 + 96, 214, 'Light atom', { size: 9.8, fill: C.amber, weight: 700 });
    b += tx(x0 + 200, 214, 'Grey outline = equilibrium position', { size: 9.8, fill: C.ink3, style: 'italic' });
    b += bx(24, 228, 452, 'In the acoustic mode the pair moves together, so the CENTRE OF MASS of each cell oscillates — that is sound. In the optical mode the centre of mass stays put and the two sublattices beat against each other — that is what an infrared photon or a Raman shift measures.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 320, b);
  };

  /* 30 · Einstein vs Debye vs data */
  D['einstein-vs-debye'] = function () {
    var b = '', ox = 62, oy = 214, w = 250, h = 156;
    b += tx(20, 20, 'Three models of the lattice heat capacity, and where each one fails', { size: 11.8, fill: C.navy, weight: 800 });
    b += ln(ox, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy + 6, ox, oy - h - 14, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 14, oy + 4, 'T / Θ', { size: 11, fill: C.ink3, weight: 700 });
    b += tx(ox - 6, oy - h - 18, 'C_V', { size: 11.5, fill: C.ink3, anchor: 'middle', weight: 700 });
    b += ln(ox, oy - h, ox + w, oy - h, { color: C.ink3, w: 1.2, dash: '4 4' });
    b += tx(ox - 8, oy - h + 4, '3Nk_B', { size: 10.4, fill: C.ink3, anchor: 'end', weight: 700 });
    b += tx(ox - 8, oy + 4, '0', { size: 10.4, fill: C.ink3, anchor: 'end' });
    /* classical */
    b += tx(ox + w - 6, oy - h - 8, 'Dulong–Petit (classical)', { size: 10, fill: C.ink3, anchor: 'end', weight: 700 });
    /* Einstein */
    function ein(t) { if (t < 0.02) return 0; var x = 1 / t; var e = Math.exp(x); return x * x * e / ((e - 1) * (e - 1)); }
    b += path(fn(ein, 0.02, 1.6, 160, function (t) { return ox + t / 1.6 * w; }, function (v) { return oy - v * h; }), { stroke: C.purple, w: 2.2, dash: '6 4' });
    /* Debye (3-term approx of the integral) */
    function deb(t) {
      var n = 40, s = 0, i, x, dx = (1 / t) / n;
      if (t < 0.02) return 0;
      for (i = 1; i <= n; i++) { x = i * dx; var e = Math.exp(x); if (!isFinite(e)) continue; s += Math.pow(x, 4) * e / ((e - 1) * (e - 1)) * dx; }
      return 9 * Math.pow(t, 3) * s;
    }
    b += path(fn(deb, 0.02, 1.6, 120, function (t) { return ox + t / 1.6 * w; }, function (v) { return oy - Math.min(1.02, v) * h; }), { stroke: C.green, w: 2.8 });
    b += tx(ox + 96, oy - 62, 'Einstein', { size: 10.6, fill: C.purple, weight: 800 });
    b += tx(ox + 150, oy - 132, 'Debye', { size: 10.6, fill: C.green, weight: 800 });
    /* low-T inset annotation */
    b += rect(ox + 4, oy - 40, 62, 36, { rx: 5, fill: 'none', stroke: C.crimson, w: 1.4, dash: '3 3' });
    b += arr(ox + 68, oy - 24, ox + 116, oy - 24, { color: C.crimson, w: 1.4 });
    b += tx(ox + 122, oy - 20, 'the low-T region', { size: 9.8, fill: C.crimson, weight: 700 });

    b += bx(334, 44, 150, 'HIGH T — all three agree. Every mode is thermally excited, each contributes k_B, and C_V → 3Nk_B.', { size: 10.2, color: C.ink2, fill: C.paper2, stroke: C.rule });
    b += bx(334, 124, 150, 'LOW T — Einstein falls off EXPONENTIALLY because his single frequency freezes out all at once. Too fast.', { size: 10.2, color: C.purple, fill: '#F5F1F9', stroke: '#D7C8E8' });
    b += bx(334, 208, 150, 'Debye gives T³ because long-wavelength acoustic modes have arbitrarily low ω and never fully freeze. Matches experiment.', { size: 10.2, color: C.green, fill: '#EAF6F0', stroke: '#BFE0CF' });
    return svg(500, 321, b);
  };

  /* 31 · normal vs umklapp */
  D['umklapp'] = function () {
    var b = '';
    b += tx(20, 20, 'Only umklapp processes destroy heat flow', { size: 11.8, fill: C.navy, weight: 800 });
    [{ ox: 40, t: 'NORMAL (N) process', s: 'k₁ + k₂ = k₃, and k₃ stays inside the zone. Total crystal momentum is unchanged, so the heat current keeps flowing. This does NOT give thermal resistance on its own.', col: C.green },
     { ox: 272, t: 'UMKLAPP (U) process', s: 'k₁ + k₂ lands outside the zone. Adding a reciprocal-lattice vector G folds it back — and the resulting phonon travels BACKWARDS. Momentum is dumped into the lattice: this is what resists heat flow.', col: C.crimson }
    ].forEach(function (p, k) {
      var ox = p.ox, cx = ox + 92, cy = 132, R = 66;
      b += tx(ox, 46, p.t, { size: 11.2, fill: p.col, weight: 800 });
      b += rect(cx - R, cy - R, 2 * R, 2 * R, { rx: 4, fill: 'rgba(23,39,92,.05)', stroke: C.ink3, w: 1.5, dash: '5 4' });
      b += tx(cx + R - 5, cy + R - 7, 'BZ', { size: 9.6, fill: C.ink3, anchor: 'end', weight: 700 });
      b += ln(cx - R, cy, cx + R, cy, { color: C.rule, w: 1 });
      b += ln(cx, cy - R, cx, cy + R, { color: C.rule, w: 1 });
      b += arr(cx, cy, cx + 40, cy - 26, { color: C.blue, w: 2.2, label: 'k₁', ly: -6, lsize: 10.5 });
      if (k === 0) {
        b += arr(cx + 40, cy - 26, cx + 58, cy - 46, { color: C.amber, w: 2.2, label: 'k₂', ly: -6, lsize: 10.5 });
        b += arr(cx, cy, cx + 58, cy - 46, { color: C.green, w: 2.6, dash: '4 3' });
        b += tx(cx + 62, cy - 52, 'k₃', { size: 11, fill: C.green, weight: 800 });
      } else {
        b += arr(cx + 40, cy - 26, cx + 92, cy - 62, { color: C.amber, w: 2.2, label: 'k₂', ly: -6, lsize: 10.5 });
        b += dot(cx + 92, cy - 62, 4, C.ink3);
        b += tx(cx + 88, cy - 68, 'outside!', { size: 9.4, fill: C.ink3, weight: 700, anchor: 'end' });
        b += arr(cx + 92, cy - 62, cx - 40, cy - 62, { color: C.ink3, w: 1.6, dash: '4 3' });
        b += tx(cx + 26, cy - 70, '+G', { size: 10.5, fill: C.ink3, anchor: 'middle', weight: 800 });
        b += arr(cx, cy, cx - 40, cy - 62, { color: C.crimson, w: 2.8 });
        b += tx(cx - 48, cy - 66, 'k₃', { size: 11, fill: C.crimson, weight: 800, anchor: 'end' });
      }
      b += txw(ox, 216, p.s, 40, { size: 9.9, fill: C.ink3 });
    });
    b += txfit(24, 296, 'U processes need phonons with k of order π/a, so they freeze out at low temperature — which is why κ RISES on cooling before boundary scattering takes over.', { w: 464, size: 10.2, fill: C.ink3, style: 'italic' });
    return svg(500, 320, b);
  };

  /* 32 · thermal conductivity vs temperature */
  D['kappa-vs-T'] = function () {
    var b = '', ox = 66, oy = 206, w = 260, h = 156;
    b += txfit(20, 20, 'κ(T) for a good crystalline insulator: three regimes, three limits', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    b += ln(ox, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy + 6, ox, oy - h - 14, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 16, oy + 4, 'T', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox - 4, oy - h - 18, 'κ', { size: 12, fill: C.ink3, anchor: 'middle', weight: 800, style: 'italic' });
    function K(t) { /* t in 0..1 arbitrary */
      var rise = Math.pow(t / 0.28, 3);
      var fall = 0.30 / Math.max(t, 0.02);
      return Math.min(rise, fall);
    }
    var peak = 0;
    for (var s = 0.02; s < 1; s += 0.005) peak = Math.max(peak, K(s));
    b += path(fn(function (t) { return K(t) / peak; }, 0.02, 1, 220,
      function (t) { return ox + t * w; }, function (v) { return oy - v * h; }), { stroke: C.amber, w: 3 });
    /* regime shading */
    b += rect(ox, oy - h, w * 0.26, h, { fill: 'rgba(20,122,94,.07)' });
    b += rect(ox + w * 0.26, oy - h, w * 0.16, h, { fill: 'rgba(193,112,26,.09)' });
    b += rect(ox + w * 0.42, oy - h, w * 0.58, h, { fill: 'rgba(158,27,50,.06)' });
    b += tx(ox + w * 0.13, oy - h - 4, 'κ ∝ T³', { size: 10.4, fill: C.green, anchor: 'middle', weight: 800 });
    b += tx(ox + w * 0.34, oy - h - 4, 'peak', { size: 10.4, fill: C.amber, anchor: 'middle', weight: 800 });
    b += tx(ox + w * 0.71, oy - h - 4, 'κ ∝ 1/T', { size: 10.4, fill: C.crimson, anchor: 'middle', weight: 800 });

    b += bx(348, 46, 136, 'LOW T: ℓ is fixed by the sample boundary or by grain size. κ then follows c_V, which is Debye T³.', { size: 10, color: C.green, fill: '#EAF6F0', stroke: '#BFE0CF' });
    b += bx(348, 124, 136, 'PEAK: boundary scattering hands over to umklapp. Its height is a purity and perfection test.', { size: 10, color: C.amber, fill: 'var(--warn-bg)', stroke: '#EBD5A8' });
    b += bx(348, 206, 136, 'HIGH T: c_V saturates at 3Nk_B, umklapp rate ∝ T, so ℓ ∝ 1/T and κ falls.', { size: 10, color: C.crimson, fill: 'var(--stop-bg)', stroke: '#EECAD1' });
    b += txfit(24, 288, 'κ = ⅓ c_V v ℓ.  Reading the curve is reading which of the three factors is doing the work at that temperature.', { w: 464, size: 10.4, fill: C.ink2, weight: 600 });
    return svg(500, 314, b);
  };
})();

/* ── Topics 8–9 · electrons and bands ──────────────────────── */
(function () {
  'use strict';
  var P = window.PHY3201, H = P.diagramHelpers, D = P.diagrams;
  var svg = H.svg, tx = H.tx, txw = H.txw, txfit = H.txfit, bx = H.bx, arr = H.arr, ln = H.ln,
      dot = H.dot, ring = H.ring, path = H.path, rect = H.rect, ax = H.ax, fn = H.fn;
  var C = { ink: 'var(--ink)', ink2: 'var(--ink-2)', ink3: 'var(--ink-3)', navy: 'var(--navy)',
            blue: 'var(--structure)', purple: 'var(--diffraction)', green: 'var(--bonding)',
            amber: 'var(--phonon)', cyan: 'var(--electron)', crimson: 'var(--crimson)',
            rule: 'var(--rule)', paper: 'var(--paper)', paper2: 'var(--paper-2)' };

  /* 33 · Drude: drift is a tiny bias on top of huge random motion */
  D['drude-drift'] = function () {
    var b = '', i;
    b += tx(20, 20, 'Drift velocity is a small BIAS on top of large random motion', { size: 11.8, fill: C.navy, weight: 800 });
    [{ y: 46, t: 'No field', c: C.ink3, bias: 0 }, { y: 168, t: 'Field E applied to the right', c: C.cyan, bias: 1 }].forEach(function (row) {
      b += rect(30, row.y + 14, 296, 96, { rx: 7, fill: C.paper2, stroke: C.rule });
      b += tx(30, row.y + 8, row.t, { size: 11, fill: row.c, weight: 800 });
      /* fixed ion cores */
      for (i = 0; i < 12; i++) b += dot(52 + (i % 6) * 50, row.y + 42 + Math.floor(i / 6) * 44, 6, C.rule);
      /* electron paths */
      var seeds = [[46, 34], [128, 74], [212, 30], [268, 82], [92, 58]];
      seeds.forEach(function (s, j) {
        var x = 30 + s[0], y = row.y + 14 + s[1], d = 'M' + x + ',' + y;
        var ang = j * 1.3;
        for (var k = 0; k < 5; k++) {
          ang += (j * 7 + k * 13) % 5 - 2;
          x += Math.cos(ang) * 20 + row.bias * 11;
          y += Math.sin(ang) * 14;
          y = Math.max(row.y + 22, Math.min(row.y + 102, y));
          x = Math.max(36, Math.min(320, x));
          d += ' L' + x.toFixed(1) + ',' + y.toFixed(1);
        }
        b += path(d, { stroke: row.c === C.ink3 ? C.ink3 : C.cyan, w: 1.5, op: .8 });
        b += dot(30 + s[0], row.y + 14 + s[1], 3.4, C.crimson);
      });
      if (row.bias) {
        b += arr(40, row.y + 122, 316, row.y + 122, { color: C.cyan, w: 2, label: 'E', ly: -6, lsize: 12 });
        b += arr(198, row.y + 4, 250, row.y + 4, { color: C.crimson, w: 2.4 });
        b += tx(256, row.y + 8, 'net drift  v_d', { size: 10.4, fill: C.crimson, weight: 800 });
      }
    });
    b += bx(344, 60, 140, 'In a metal v_F ≈ 10⁶ m s⁻¹, but v_d under an ordinary field is of order 10⁻⁴ m s⁻¹ — ten orders of magnitude smaller.', { size: 10.2, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += bx(344, 168, 140, 'σ = ne²τ/m. Everything the material contributes sits in n and τ. Doubling τ doubles σ.', { size: 10.2, color: C.cyan, fill: '#EAF4F7', stroke: '#BCDAE4' });
    b += txfit(24, 312, 'The current is not fast electrons — it is an almost imperceptible asymmetry imposed on a very fast, otherwise cancelling, distribution.', { w: 464, size: 10.2, fill: C.ink3, style: 'italic' });
    return svg(500, 338, b);
  };

  /* 34 · the Fermi sphere and its shift */
  D['fermi-sphere'] = function () {
    var b = '', cy = 148, R = 76;
    b += tx(20, 20, 'The Fermi sphere: occupied states in k-space, and what a field does to it', { size: 11.6, fill: C.navy, weight: 800 });
    [{ cx: 122, t: 'Equilibrium', s: 'Sphere centred on k = 0. Every occupied +k has an occupied −k, so the velocities cancel: no current.', shift: 0 },
     { cx: 340, t: 'Field applied', s: 'Shifts by δk = −eEτ/ħ. Only the thin crescent is unbalanced — that is the current.', shift: 16 }
    ].forEach(function (p) {
      b += tx(p.cx - R, 46, p.t, { size: 11.2, fill: C.navy, weight: 800 });
      b += ln(p.cx - R - 22, cy, p.cx + R + 22, cy, { color: C.rule, w: 1.1 });
      b += ln(p.cx, cy - R - 22, p.cx, cy + R + 22, { color: C.rule, w: 1.1 });
      b += tx(p.cx + R + 26, cy + 4, 'kₓ', { size: 10.5, fill: C.ink3, weight: 700 });
      if (p.shift) {
        b += '<circle cx="' + p.cx + '" cy="' + cy + '" r="' + R + '" fill="none" stroke="' + C.rule + '" stroke-width="1.4" stroke-dasharray="4 4"/>';
        b += '<circle cx="' + (p.cx + p.shift) + '" cy="' + cy + '" r="' + R + '" fill="' + C.cyan + '" opacity=".24" stroke="' + C.cyan + '" stroke-width="2"/>';
        b += path('M' + (p.cx + R) + ',' + cy + ' A' + R + ',' + R + ' 0 0 1 ' + (p.cx + R * 0.2) + ',' + (cy + R * 0.98) +
                  ' A' + R + ',' + R + ' 0 0 0 ' + (p.cx + p.shift + R) + ',' + cy + ' Z', { fill: C.crimson, op: .5, stroke: 'none' });
        b += arr(p.cx, cy - R - 14, p.cx + p.shift, cy - R - 14, { color: C.crimson, w: 2 });
        b += tx(p.cx + p.shift + 8, cy - R - 16, 'δk', { size: 11, fill: C.crimson, weight: 800 });
      } else {
        b += '<circle cx="' + p.cx + '" cy="' + cy + '" r="' + R + '" fill="' + C.cyan + '" opacity=".24" stroke="' + C.cyan + '" stroke-width="2"/>';
        b += arr(p.cx, cy, p.cx + R, cy, { color: C.navy, w: 1.8 });
        b += tx(p.cx + R / 2, cy - 8, 'k_F', { size: 11, fill: C.navy, anchor: 'middle', weight: 800 });
        b += arr(p.cx, cy, p.cx - 44, cy - 30, { color: C.ink3, w: 1.3 });
        b += arr(p.cx, cy, p.cx + 44, cy + 30, { color: C.ink3, w: 1.3 });
        b += tx(p.cx - 50, cy - 34, 'cancel', { size: 9.6, fill: C.ink3, anchor: 'end', weight: 700 });
      }
      b += txw(p.cx - R - 6, cy + R + 34, p.s, 34, { size: 10, fill: C.ink3 });
    });
    b += txfit(250, 300, 'Only electrons within ~k_BT of the Fermi surface can be scattered or excited — the deep states have no empty neighbours to move into. That single fact explains the electronic heat capacity, the conductivity and the Pauli susceptibility.', { w: 476, size: 10.2, fill: C.ink2, anchor: 'middle', style: 'italic' });
    return svg(500, 342, b);
  };

  /* 35 · Fermi-Dirac at T = 0 and T > 0, and why C_el is small */
  D['fermi-dirac'] = function () {
    var b = '', ox = 56, oy = 176, w = 210, h = 120;
    b += tx(20, 20, 'Only a sliver of the electron gas can absorb heat', { size: 11.8, fill: C.navy, weight: 800 });
    b += ln(ox, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy + 6, ox, oy - h - 16, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 16, oy + 4, 'E', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox - 4, oy - h - 20, 'f(E)', { size: 11.5, fill: C.ink3, anchor: 'middle', weight: 700 });
    b += tx(ox - 8, oy - h + 4, '1', { size: 10.4, fill: C.ink3, anchor: 'end' });
    b += tx(ox - 8, oy + 4, '0', { size: 10.4, fill: C.ink3, anchor: 'end' });
    var Ef = 0.5;
    /* T = 0 step */
    b += path('M' + ox + ',' + (oy - h) + ' L' + (ox + Ef * w) + ',' + (oy - h) + ' L' + (ox + Ef * w) + ',' + oy + ' L' + (ox + w) + ',' + oy,
      { stroke: C.ink3, w: 1.8, dash: '5 4' });
    /* T > 0 */
    var kT = 0.055;
    b += path(fn(function (E) { return 1 / (1 + Math.exp((E - Ef) / kT)); }, 0, 1, 200,
      function (E) { return ox + E * w; }, function (v) { return oy - v * h; }), { stroke: C.cyan, w: 2.8 });
    b += ln(ox + Ef * w, oy, ox + Ef * w, oy - h - 8, { color: C.crimson, w: 1.4, dash: '3 3' });
    b += tx(ox + Ef * w, oy + 18, 'E_F', { size: 11.5, fill: C.crimson, anchor: 'middle', weight: 800 });
    /* smear band */
    b += rect(ox + (Ef - 2.2 * kT) * w, oy - h - 6, 4.4 * kT * w, h + 6, { fill: 'rgba(158,27,50,.13)' });
    b += arr(ox + (Ef - 2.2 * kT) * w, oy - h - 16, ox + (Ef + 2.2 * kT) * w, oy - h - 16, { color: C.crimson, both: true, w: 1.4 });
    b += tx(ox + Ef * w, oy - h - 22, '~ few k_BT', { size: 10, fill: C.crimson, anchor: 'middle', weight: 800 });
    b += tx(ox + 16, oy - h + 18, 'T = 0 step', { size: 10, fill: C.ink3, weight: 700 });
    b += tx(ox + w - 6, oy - 22, 'T > 0', { size: 10.4, fill: C.cyan, anchor: 'end', weight: 800 });

    b += bx(298, 50, 186, 'At room temperature k_BT ≈ 0.025 eV while E_F for a metal is 3–10 eV. The fraction of electrons that can be thermally excited is roughly k_BT/E_F ≈ 1 %.', { size: 10.4, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += bx(298, 148, 186, 'So the classical prediction C_el = (3/2)Nk_B is wrong by two orders of magnitude. The correct result, C_el = γT, is LINEAR in T and small.', { size: 10.4, color: C.cyan, fill: '#EAF4F7', stroke: '#BCDAE4' });
    b += bx(298, 236, 186, 'Below ~5 K the linear γT term overtakes the lattice βT³ term. Plotting C/T against T² separates them: intercept γ, slope β.', { size: 10.4, color: C.ink2, fill: C.paper2, stroke: C.rule });
    return svg(500, 324, b);
  };

  /* 36 · density of states in 3-D */
  D['dos-3d'] = function () {
    var b = '', ox = 66, oy = 200, w = 190, h = 148;
    b += tx(20, 20, 'g(E) ∝ √E, and the shaded area is the electron count', { size: 11.8, fill: C.navy, weight: 800 });
    b += ln(ox, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox, oy + 6, ox, oy - h - 14, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 16, oy + 4, 'E', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox - 4, oy - h - 18, 'g(E)', { size: 11.5, fill: C.ink3, anchor: 'middle', weight: 700 });
    var Ef = 0.62;
    var d = 'M' + ox + ',' + oy;
    for (var i = 0; i <= 100; i++) { var E = Ef * i / 100; d += ' L' + (ox + E * w) + ',' + (oy - Math.sqrt(E) * h * 1.05); }
    d += ' L' + (ox + Ef * w) + ',' + oy + ' Z';
    b += path(d, { fill: 'rgba(14,124,153,.30)', stroke: 'none' });
    b += path(fn(function (E) { return Math.sqrt(E) * 1.05; }, 0, 1, 120,
      function (E) { return ox + E * w; }, function (v) { return oy - v * h; }), { stroke: C.cyan, w: 2.8 });
    b += ln(ox + Ef * w, oy, ox + Ef * w, oy - Math.sqrt(Ef) * h * 1.05 - 10, { color: C.crimson, w: 1.5, dash: '3 3' });
    b += tx(ox + Ef * w, oy + 18, 'E_F', { size: 11.5, fill: C.crimson, anchor: 'middle', weight: 800 });
    b += tx(ox + Ef * w * 0.42, oy - 42, 'occupied', { size: 10.4, fill: C.cyan, anchor: 'middle', weight: 800 });
    b += tx(ox + w - 6, oy - 20, 'empty', { size: 10.4, fill: C.ink3, anchor: 'end', weight: 700 });
    b += dot(ox + Ef * w, oy - Math.sqrt(Ef) * h * 1.05, 4.5, C.crimson);
    b += txfit(ox + Ef * w + 8, oy - 96, 'g(E_F) sets σ, C_el, χ', { w: 94, size: 9.4, fill: C.crimson, weight: 700 });

    b += bx(288, 52, 196, 'Counting: each k-state occupies a volume (2π/L)³, each holds 2 electrons by spin, and the number of states inside a sphere of radius k goes as k³. Since E ∝ k², dN/dE comes out proportional to √E.', { size: 10.3, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += bx(288, 172, 196, 'E_F = (ħ²/2m)(3π²n)^{2/3}. Only n — the electron density — enters. Sodium: E_F ≈ 3.2 eV, T_F ≈ 37 000 K. A metal at room temperature is a COLD Fermi gas.', { size: 10.3, color: C.cyan, fill: '#EAF4F7', stroke: '#BCDAE4' });
    return svg(500, 273, b);
  };

  /* 37 · Hall effect geometry */
  D['hall-geometry'] = function () {
    var b = '', ox = 60, oy = 78, w = 250, h = 96;
    b += tx(20, 20, 'The Hall effect: the sign of V_H tells you the sign of the carrier', { size: 11.8, fill: C.navy, weight: 800 });
    b += rect(ox, oy, w, h, { rx: 4, fill: 'rgba(14,124,153,.10)', stroke: C.ink3, w: 1.6 });
    b += arr(ox - 34, oy + h / 2, ox, oy + h / 2, { color: C.crimson, w: 2.4 });
    b += tx(ox - 38, oy + h / 2 + 4, 'I', { size: 13, fill: C.crimson, anchor: 'end', weight: 800, style: 'italic' });
    b += arr(ox + w, oy + h / 2, ox + w + 34, oy + h / 2, { color: C.crimson, w: 2.4 });
    /* B out of page */
    [0, 1, 2].forEach(function (i) {
      var cx = ox + 62 + i * 62, cy = oy + h / 2;
      b += ring(cx, cy, 8, C.purple, 1.6) + dot(cx, cy, 2.6, C.purple);
    });
    b += tx(ox + 124, oy - 10, 'B out of the page', { size: 10.4, fill: C.purple, anchor: 'middle', weight: 800 });
    /* charge accumulation */
    b += tx(ox + w / 2, oy - 24, '', {});
    b += rect(ox, oy, w, 9, { fill: C.blue, op: .55 });
    b += rect(ox, oy + h - 9, w, 9, { fill: C.crimson, op: .5 });
    b += tx(ox + w + 12, oy + 8, '−', { size: 17, fill: C.blue, weight: 800 });
    b += tx(ox + w + 12, oy + h - 1, '+', { size: 17, fill: C.crimson, weight: 800 });
    b += arr(ox + w + 30, oy + h - 8, ox + w + 30, oy + 10, { color: C.ink3, w: 1.6, both: true });
    b += tx(ox + w + 38, oy + h / 2 + 4, 'V_H', { size: 12, fill: C.ink2, weight: 800, style: 'italic' });
    /* the force */
    b += arr(ox + 124, oy + h / 2, ox + 124, oy + 20, { color: C.green, w: 2.2 });
    b += tx(ox + 130, oy + 30, 'F = −e(v × B)', { size: 10.4, fill: C.green, weight: 800 });

    b += bx(24, 196, 452, 'Carriers are deflected sideways until the transverse electric field balances the magnetic force. R_H = E_y/(J_x B) = −1/(ne) for a single band of electrons. Reverse the carrier sign and V_H reverses — this is how p-type and n-type semiconductors are told apart experimentally.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    b += txfit(24, 292, 'Caution: n = −1/(eR_H) assumes ONE carrier type. Multi-band metals give Hall coefficients that this formula cannot interpret — several metals even show a positive R_H.', { w: 464, size: 10.2, fill: C.crimson, weight: 600 });
    return svg(500, 330, b);
  };

  /* 38 · why a gap opens at the zone boundary */
  D['nfe-gap'] = function () {
    var b = '', ox = 44, oy = 214, w = 200, h = 168;
    b += tx(20, 20, 'A weak periodic potential splits the two standing waves at k = ±π/a', { size: 11.6, fill: C.navy, weight: 800 });
    /* left: E vs k */
    b += ln(ox - 8, oy, ox + w + 12, oy, { color: C.ink3, w: 1.3 });
    b += ln(ox + w / 2, oy + 6, ox + w / 2, oy - h - 14, { color: C.ink3, w: 1.3 });
    b += tx(ox + w + 16, oy + 4, 'k', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    b += tx(ox + w / 2 + 8, oy - h - 2, 'E', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });
    var kb = 0.62; /* fraction of half-width at zone boundary */
    b += ln(ox + w / 2 + kb * w / 2, oy, ox + w / 2 + kb * w / 2, oy - h, { color: C.crimson, w: 1.4, dash: '4 3' });
    b += ln(ox + w / 2 - kb * w / 2, oy, ox + w / 2 - kb * w / 2, oy - h, { color: C.crimson, w: 1.4, dash: '4 3' });
    b += tx(ox + w / 2 + kb * w / 2, oy + 18, 'π/a', { size: 10.4, fill: C.crimson, anchor: 'middle', weight: 800 });
    b += tx(ox + w / 2 - kb * w / 2, oy + 18, '−π/a', { size: 10.4, fill: C.crimson, anchor: 'middle', weight: 800 });
    /* free parabola */
    b += path(fn(function (t) { return t * t; }, -1, 1, 120,
      function (t) { return ox + w / 2 + t * w / 2; }, function (v) { return oy - v * h * 0.94; }), { stroke: C.rule, w: 2, dash: '5 4' });
    b += tx(ox + w / 2 - 8, oy - h - 2, 'free electron', { size: 9.8, fill: C.ink3, anchor: 'end', weight: 700 });
    /* lower band */
    var g = 0.16;
    b += path(fn(function (t) { var a = Math.abs(t) / kb; return Math.min(kb * kb, t * t) * (a < 1 ? 1 : 1) - (a < 1 ? g * kb * kb * Math.pow(a, 6) : 0); }, -kb, kb, 120,
      function (t) { return ox + w / 2 + t * w / 2; }, function (v) { return oy - v * h * 0.94; }), { stroke: C.cyan, w: 3 });
    /* upper band */
    b += path(fn(function (t) { var a = Math.min(1, Math.abs(t) / kb); return t * t + g * kb * kb * (2 - Math.pow(a, 6)); }, -1, -kb, 60,
      function (t) { return ox + w / 2 + t * w / 2; }, function (v) { return oy - v * h * 0.94; }), { stroke: C.purple, w: 3 });
    b += path(fn(function (t) { var a = Math.min(1, Math.abs(t) / kb); return t * t + g * kb * kb * (2 - Math.pow(a, 6)); }, kb, 1, 60,
      function (t) { return ox + w / 2 + t * w / 2; }, function (v) { return oy - v * h * 0.94; }), { stroke: C.purple, w: 3 });
    /* gap bracket */
    var yLo = oy - kb * kb * (1 - g) * h * 0.94, yHi = oy - kb * kb * (1 + g) * h * 0.94;
    b += rect(ox + w / 2 - kb * w / 2, yHi, kb * w, yLo - yHi, { fill: 'rgba(158,27,50,.14)' });
    b += tx(ox + w / 2, (yLo + yHi) / 2 + 4, 'E_g', { size: 12, fill: C.crimson, anchor: 'middle', weight: 800 });

    /* right: the two standing waves against the ion cores */
    var o2 = 292, base = 138, sp = 44;
    b += txw(o2, 46, 'Why the two states differ in energy', 22, { size: 11, fill: C.navy, weight: 800 });
    for (var i = 0; i < 5; i++) b += dot(o2 + 18 + i * sp, base + 6, 7, C.crimson);
    b += tx(o2, base + 30, 'ion cores (attractive)', { size: 9.6, fill: C.crimson });
    b += path(fn(function (x) { return Math.cos(Math.PI * x); }, -0.35, 4.25, 200,
      function (x) { return o2 + 18 + x * sp; }, function (v) { return base - 22 - v * 20; }), { stroke: C.cyan, w: 2.2 });
    b += tx(o2 + 200, base - 50, 'ψ₊ ∝ cos', { size: 10.2, fill: C.cyan, anchor: 'end', weight: 800 });
    b += txw(o2, base - 64, 'piles charge ON the ions → LOWER energy', 26, { size: 9.6, fill: C.cyan, weight: 600 });
    b += path(fn(function (x) { return Math.sin(Math.PI * x); }, -0.35, 4.25, 200,
      function (x) { return o2 + 18 + x * sp; }, function (v) { return base + 96 - v * 20; }), { stroke: C.purple, w: 2.2 });
    for (i = 0; i < 5; i++) b += dot(o2 + 18 + i * sp, base + 124, 7, C.crimson);
    b += tx(o2 + 200, base + 150, 'ψ₋ ∝ sin', { size: 10.2, fill: C.purple, anchor: 'end', weight: 800 });
    b += txw(o2, base + 152, 'has NODES at the ions → HIGHER energy', 26, { size: 9.6, fill: C.purple, weight: 600 });
    b += arr(o2 + 96, base + 42, o2 + 96, base + 74, { color: C.ink3, w: 1.5, both: true });
    b += tx(o2 + 104, base + 62, 'this gap IS E_g', { size: 9.8, fill: C.ink2, weight: 700 });

    b += bx(24, 320, 452, 'Band folding alone creates NO gap — folding is only a way of drawing the same free-electron branches inside one zone. The gap appears because the periodic potential COUPLES the degenerate states at the boundary and splits them.', { size: 11, color: 'var(--stop)', fill: 'var(--stop-bg)', stroke: '#EECAD1' });
    return svg(500, 400, b);
  };

  /* 39 · Kronig-Penney potential */
  D['kronig-penney'] = function () {
    var b = '', base = 130, sp = 78, x0 = 44, i;
    b += txfit(20, 20, 'Kronig–Penney: a periodic square well, solved exactly', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    var d = 'M' + x0 + ',' + base;
    for (i = 0; i < 5; i++) {
      var x = x0 + i * sp;
      d += ' L' + (x + 52) + ',' + base + ' L' + (x + 52) + ',' + (base - 58) + ' L' + (x + sp) + ',' + (base - 58) + ' L' + (x + sp) + ',' + base;
    }
    b += path(d, { stroke: C.navy, w: 2.4 });
    b += ln(x0 - 10, base, x0 + 5 * sp + 14, base, { color: C.rule, w: 1.2, dash: '3 3' });
    b += arr(x0, base + 24, x0 + 52, base + 24, { color: C.green, both: true, w: 1.3 });
    b += tx(x0 + 26, base + 40, 'a  (well)', { size: 10.4, fill: C.green, anchor: 'middle', weight: 700 });
    b += arr(x0 + 52, base + 24, x0 + sp, base + 24, { color: C.crimson, both: true, w: 1.3 });
    b += tx(x0 + 65, base + 40, 'b', { size: 10.4, fill: C.crimson, anchor: 'middle', weight: 700 });
    b += arr(x0 + 130, base - 58, x0 + 130, base, { color: C.ink3, both: true, w: 1.3 });
    b += tx(x0 + 136, base - 26, 'V₀  (barrier)', { size: 10.4, fill: C.ink3, weight: 700 });
    b += tx(x0 + 5 * sp + 18, base + 4, 'x', { size: 12, fill: C.ink3, weight: 800, style: 'italic' });

    b += bx(24, 186, 452, 'Solve the Schrödinger equation in each region, then impose Bloch’s theorem across one period. The matching conditions collapse to a single transcendental relation:   P·sin(αa)/(αa) + cos(αa) = cos(ka)', { size: 11.2, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });

    /* the graphical solution */
    var ox = 66, oy = 372, w = 250, h = 62;
    b += tx(24, 272, 'The right-hand side is cos(ka), which can never leave [−1, +1]:', { size: 10.8, fill: C.ink2, weight: 600 });
    b += ln(ox, oy, ox + w + 10, oy, { color: C.ink3, w: 1.2 });
    b += ln(ox, oy - h - 26, ox, oy + h + 12, { color: C.ink3, w: 1.2 });
    b += ln(ox, oy - h, ox + w, oy - h, { color: C.crimson, w: 1.4, dash: '4 3' });
    b += ln(ox, oy + h, ox + w, oy + h, { color: C.crimson, w: 1.4, dash: '4 3' });
    b += tx(ox - 8, oy - h + 4, '+1', { size: 10, fill: C.crimson, anchor: 'end', weight: 700 });
    b += tx(ox - 8, oy + h + 4, '−1', { size: 10, fill: C.crimson, anchor: 'end', weight: 700 });
    b += rect(ox, oy - h, w, 2 * h, { fill: 'rgba(20,122,94,.09)' });
    function LHS(t) { var a = t * 12 + 0.4; return 2.4 * Math.sin(a) / a + Math.cos(a); }
    b += path(fn(function (t) { return Math.max(-2.1, Math.min(2.1, LHS(t))); }, 0, 1, 300,
      function (t) { return ox + t * w; }, function (v) { return oy - v * h; }), { stroke: C.navy, w: 2.2 });
    b += tx(ox + w + 14, oy + 4, 'αa', { size: 11, fill: C.ink3, weight: 700 });
    b += txfit(ox + w / 2, oy + h + 30, 'Where the curve lies inside the band: ALLOWED. Where it leaves: FORBIDDEN — a band gap.', { w: 356, size: 10.2, fill: C.ink2, anchor: 'middle', weight: 600 });
    b += bx(336, 300, 148, 'Bands and gaps drop out of nothing more than periodicity plus wave mechanics. No detailed knowledge of the real potential is needed.', { size: 10.2, color: C.green, fill: '#EAF6F0', stroke: '#BFE0CF' });
    return svg(500, 492, b);
  };

  /* 40 · metal, semiconductor, insulator */
  D['band-filling'] = function () {
    var b = '';
    var P4 = [
      { t: 'Metal', s: 'Partly filled band. Empty states sit just above the occupied ones, so any field drives current.', gap: 0, fill: 0.55, col: C.cyan },
      { t: 'Semimetal / overlap', s: 'A full band overlapping an empty one, giving small carrier densities in both.', gap: -1, fill: 1, col: C.green },
      { t: 'Semiconductor', s: 'Full band, empty band, small gap (Si 1.12 eV). Thermal excitation at 300 K gives usable carriers.', gap: 0.28, fill: 1, col: C.amber },
      { t: 'Insulator', s: 'Same picture, large gap (diamond 5.5 eV). k_BT ≈ 0.025 eV at 300 K excites essentially nothing.', gap: 0.78, fill: 1, col: C.crimson }
    ];
    b += txfit(20, 20, 'Metal, semiconductor, insulator: same physics, different filling', { w: 468, size: 10.8, fill: C.navy, weight: 800 });
    P4.forEach(function (p, k) {
      var ox = 16 + k * 121, top = 62, H0 = 150;
      b += tx(ox + 52, 40, p.t, { size: 11.4, fill: p.col, anchor: 'middle', weight: 800 });
      b += rect(ox, top, 104, H0, { rx: 6, fill: C.paper2, stroke: C.rule });
      if (p.gap === 0) {
        b += rect(ox + 8, top + 40, 88, 70, { rx: 3, fill: C.rule });
        b += rect(ox + 8, top + 40 + 70 * (1 - p.fill), 88, 70 * p.fill, { rx: 3, fill: p.col, op: .6 });
        b += ln(ox + 8, top + 40 + 70 * (1 - p.fill), ox + 96, top + 40 + 70 * (1 - p.fill), { color: C.crimson, w: 2 });
        b += tx(ox + 100, top + 40 + 70 * (1 - p.fill) + 4, 'E_F', { size: 9.6, fill: C.crimson, weight: 800 });
      } else if (p.gap < 0) {
        b += rect(ox + 6, top + 62, 46, 62, { rx: 3, fill: p.col, op: .55 });
        b += rect(ox + 52, top + 34, 46, 62, { rx: 3, fill: C.rule });
        b += rect(ox + 52, top + 82, 46, 14, { rx: 3, fill: p.col, op: .55 });
        b += ln(ox + 6, top + 88, ox + 98, top + 88, { color: C.crimson, w: 2 });
      } else {
        /* anchor both bands from the BOTTOM of the panel so a wide gap cannot push the
           conduction band off the top — that is what happened for the insulator column. */
        var gh = p.gap * 46, vy = top + H0 - 56, cy2 = vy - gh - 40;
        b += rect(ox + 8, vy, 88, 44, { rx: 3, fill: p.col, op: .6 });
        b += rect(ox + 8, cy2, 88, 40, { rx: 3, fill: C.rule });
        b += ln(ox + 8, vy - gh / 2, ox + 96, vy - gh / 2, { color: C.crimson, w: 1.6, dash: '4 3' });
        b += arr(ox + 52, vy, ox + 52, vy - gh, { color: C.ink2, both: true, w: 1.4 });
        b += tx(ox + 58, vy - gh / 2 + 4, 'E_g', { size: 10, fill: C.ink2, weight: 800 });
        b += tx(ox + 12, vy + 22, 'valence', { size: 8.8, fill: '#fff', weight: 700 });
        b += tx(ox + 12, cy2 + 24, 'conduction', { size: 8.8, fill: C.ink3, weight: 700 });
      }
      b += txw(ox, top + H0 + 18, p.s, 22, { size: 9.4, fill: C.ink3 });
    });
    b += bx(16, 286, 460, 'A band holds exactly 2N states for N primitive cells. A crystal with an EVEN number of valence electrons per cell can fill its bands exactly and be an insulator; an odd number guarantees a partly filled band and metallic behaviour. That counting rule is the whole of Topic 9 in one sentence.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 378, b);
  };

  /* 41 · the whole course as one chain */
  D['course-chain'] = function () {
    var b = '';
    var steps = [
      { t: 'Atoms arrange', s: 'lattice + basis', n: 'T1–T2', col: C.blue },
      { t: 'We can MEASURE it', s: 'diffraction, reciprocal space', n: 'T3–T4', col: C.purple },
      { t: 'Bonds hold it together', s: 'U(r), r₀, curvature K', n: 'T5', col: C.green },
      { t: 'That stiffness lets it vibrate', s: 'phonons, ω(k)', n: 'T6', col: C.amber },
      { t: 'Vibrations carry heat', s: 'C_V, κ', n: 'T7', col: C.amber },
      { t: 'Electrons carry charge', s: 'E_F, σ, Ohm’s law', n: 'T8', col: C.cyan },
      { t: 'Periodicity makes bands', s: 'gaps, metal vs semiconductor', n: 'T9', col: C.navy }
    ];
    var y = 56;
    steps.forEach(function (s, k) {
      var x = 16 + (k % 4) * 121;
      var yy = y + Math.floor(k / 4) * 118;
      b += rect(x, yy, 108, 88, { rx: 8, fill: C.paper, stroke: s.col, w: 1.8 });
      b += tx(x + 8, yy + 18, s.n, { size: 9.6, fill: s.col, weight: 800 });
      b += txw(x + 8, yy + 36, s.t, 15, { size: 9.8, fill: C.ink, weight: 700 });
      b += txw(x + 8, yy + 70, s.s, 18, { size: 9.2, fill: C.ink3 });
      if (k < steps.length - 1) {
        if (k % 4 !== 3) b += arr(x + 108, yy + 44, x + 119, yy + 44, { color: C.ink3, w: 1.6 });
        else b += arr(x + 54, yy + 88, x + 54 - 363, yy + 112, { color: C.ink3, w: 1.6, curve: -40 });
      }
    });
    b += bx(16, 292, 460, 'Every exam question in PHY3201 asks you to walk some part of this chain — usually from a structural fact to a material property, and to say what the model does NOT license you to conclude.', { size: 11, color: C.navy, fill: '#FBF6F7', stroke: '#E8D5DA' });
    return svg(500, 355, b);
  };
})();
