/* PHY3201 — interactive explorers.
   Each widget is a function(el) that fills the element passed to it.
   Register with:  P.widgets['my-id'] = function (el) { ... }
   and place it in content with  { t:'widget', id:'my-id', title:'…' }. */
(function () {
  'use strict';
  var P = window.PHY3201 = window.PHY3201 || {};
  var W = P.widgets = P.widgets || {};
  var H = P.diagramHelpers;

  /* physical constants (CODATA 2019 exact values where applicable) */
  var K = {
    e:    1.602176634e-19,   // C
    me:   9.1093837015e-31,  // kg
    hbar: 1.054571817e-34,   // J s
    h:    6.62607015e-34,    // J s
    kB:   1.380649e-23,      // J/K
    NA:   6.02214076e23      // /mol
  };
  P.K = K;

  /* ── small DOM helpers ────────────────────────────────────── */
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }
  function slider(label, min, max, step, val, fmt) {
    var c = el('div', 'ctrl');
    var id = 'sl' + Math.random().toString(36).slice(2, 8);
    c.innerHTML = '<label for="' + id + '">' + label + ' <span class="val"></span></label>' +
      '<input id="' + id + '" type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + val + '">';
    c._input = c.querySelector('input');
    c._val = c.querySelector('.val');
    c._fmt = fmt || function (v) { return v; };
    c._sync = function () { c._val.textContent = c._fmt(Number(c._input.value)); };
    c._input.addEventListener('input', c._sync);
    c._sync();
    return c;
  }
  function seg(options, val, onChange) {
    var c = el('div', 'segmented');
    options.forEach(function (o) {
      var b = el('button', o.v === val ? 'is-on' : '', o.t);
      b.addEventListener('click', function () {
        Array.prototype.forEach.call(c.children, function (x) { x.classList.remove('is-on'); });
        b.classList.add('is-on'); onChange(o.v);
      });
      c.appendChild(b);
    });
    return c;
  }
  function stats(list) {
    var c = el('div', 'readout');
    list.forEach(function (s) {
      var d = el('div', 'stat', '<div class="stat__k">' + s.k + '</div><div class="stat__v" data-k="' + s.k + '">—</div>');
      c.appendChild(d);
    });
    c.set = function (k, v) {
      var n = c.querySelector('[data-k="' + k + '"]');
      if (n) n.innerHTML = v;
    };
    return c;
  }
  function stage() { var s = el('div', 'svgstage'); return s; }
  function num(x, d) { return Number(x).toFixed(d == null ? 3 : d); }
  function sci(x, d) {
    if (x === 0) return '0';
    var e = Math.floor(Math.log10(Math.abs(x)));
    var m = x / Math.pow(10, e);
    return num(m, d == null ? 2 : d) + '×10<sup style="font-size:.62em">' + e + '</sup>';
  }

  /* ── 1 · cubic lattice explorer (Topic 1) ─────────────────── */
  W['lattice-explorer'] = function (root) {
    var type = 'sc';
    var data = {
      sc:  { name: 'Simple cubic',       n: 1, cn: 6,  apf: Math.PI / 6,             rel: 'a = 2R',    aR: 2,             ex: 'α-Po is the only element that adopts it at ambient conditions.' },
      bcc: { name: 'Body-centred cubic', n: 2, cn: 8,  apf: Math.sqrt(3) * Math.PI / 8, rel: '√3 a = 4R', aR: 4 / Math.sqrt(3), ex: 'α-Fe, Cr, W, Mo, Na, K.' },
      fcc: { name: 'Face-centred cubic', n: 4, cn: 12, apf: Math.PI / (3 * Math.SQRT2), rel: '√2 a = 4R', aR: 4 / Math.SQRT2, ex: 'Cu, Al, Ag, Au, Ni, γ-Fe. Close-packed.' }
    };
    var ctl = el('div', 'controls');
    ctl.appendChild(seg([{ v: 'sc', t: 'SC' }, { v: 'bcc', t: 'BCC' }, { v: 'fcc', t: 'FCC' }], 'sc', function (v) { type = v; draw(); }));
    var aS = slider('Lattice parameter a (nm)', 0.20, 0.70, 0.005, 0.361, function (v) { return num(v, 3) + ' nm'; });
    aS._input.addEventListener('input', draw);
    ctl.appendChild(aS);
    var st = stage();
    var out = stats([{ k: 'Atoms / cell' }, { k: 'Coordination' }, { k: 'APF' }, { k: 'Atomic radius R' }, { k: 'Cell volume' }]);
    var note = el('p', '', '');
    note.style.cssText = 'font-size:13.6px;color:var(--ink-3);margin:10px 0 0';
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out); root.appendChild(note);

    function draw() {
      var d = data[type], a = Number(aS._input.value);
      var Rr = a / d.aR;
      var ox = 150, oy = 220, s = 150, dx = 0.44 * s, dy = 0.30 * s;
      function p(x, y, z) { return [ox + x * s + z * dx, oy - y * s - z * dy]; }
      var b = '', E = [[0,0,0,1,0,0],[1,0,0,1,1,0],[1,1,0,0,1,0],[0,1,0,0,0,0],
                       [0,0,1,1,0,1],[1,0,1,1,1,1],[1,1,1,0,1,1],[0,1,1,0,0,1],
                       [0,0,0,0,0,1],[1,0,0,1,0,1],[1,1,0,1,1,1],[0,1,0,0,1,1]];
      E.forEach(function (e, i) {
        var A = p(e[0], e[1], e[2]), B = p(e[3], e[4], e[5]);
        var back = (i === 4 || i === 7 || i === 8 || i === 11);
        b += H.ln(A[0], A[1], B[0], B[1], { color: back ? 'var(--rule)' : 'var(--ink-3)', w: back ? 1 : 1.5, dash: back ? '3 3' : '' });
      });
      var pts = [[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
      var extra = [];
      if (type === 'bcc') extra = [[0.5,0.5,0.5]];
      if (type === 'fcc') extra = [[0.5,0.5,0],[0.5,0.5,1],[0.5,0,0.5],[0.5,1,0.5],[0,0.5,0.5],[1,0.5,0.5]];
      pts.forEach(function (v) { var q = p(v[0], v[1], v[2]); b += H.dot(q[0], q[1], 8, 'var(--structure)'); });
      extra.forEach(function (v) { var q = p(v[0], v[1], v[2]); b += H.dot(q[0], q[1], 8.5, 'var(--phonon)'); });
      /* contact line */
      var cline = { sc: [[0,0,0],[1,0,0]], bcc: [[0,0,0],[1,1,1]], fcc: [[0,0,0],[1,1,0]] }[type];
      var c1 = p(cline[0][0], cline[0][1], cline[0][2]), c2 = p(cline[1][0], cline[1][1], cline[1][2]);
      b += H.ln(c1[0], c1[1], c2[0], c2[1], { color: 'var(--crimson)', w: 3 });
      b += H.tx(320, 40, d.name, { size: 15, fill: 'var(--navy)', weight: 800 });
      b += H.tx(320, 62, d.rel, { size: 14, fill: 'var(--crimson)', weight: 800, mono: true });
      b += H.tx(320, 78, 'contact direction shown in red', { size: 10.5, fill: 'var(--ink-3)' });
      b += H.arr(ox, oy + 26, ox + s, oy + 26, { color: 'var(--ink-3)', both: true, w: 1.3 });
      b += H.tx(ox + s / 2, oy + 44, 'a = ' + num(a, 3) + ' nm', { size: 12, fill: 'var(--ink-2)', anchor: 'middle', weight: 700 });
      st.innerHTML = H.svg(500, 270, b);

      out.set('Atoms / cell', d.n);
      out.set('Coordination', d.cn);
      out.set('APF', num(d.apf, 3) + ' <small>(' + num(d.apf * 100, 0) + '%)</small>');
      out.set('Atomic radius R', num(Rr, 4) + ' <small>nm</small>');
      out.set('Cell volume', num(a * a * a, 4) + ' <small>nm³</small>');
      note.innerHTML = '<b>' + d.name + '.</b> ' + d.ex +
        ' The contact relation ' + d.rel + ' is what converts a hard-sphere radius into a measurable lattice parameter — ' +
        'it is the step students most often skip.';
    }
    draw();
  };

  /* ── 2 · Miller plane and direction explorer (Topic 2) ────── */
  W['miller-explorer'] = function (root) {
    var mode = 'plane', rot = 0;
    var ctl = el('div', 'controls');
    ctl.appendChild(seg([{ v: 'plane', t: '(hkl) plane' }, { v: 'direction', t: '[uvw] direction' }], 'plane', function (v) { mode = v; draw(); }));
    var inputs = {};
    ['h', 'k', 'l'].forEach(function (n, i) {
      var c = el('div', 'ctrl');
      c.innerHTML = '<label>' + n + '</label><input type="number" value="' + [1, 1, 0][i] + '" min="-4" max="4" step="1" style="width:70px">';
      c.querySelector('input').addEventListener('input', draw);
      inputs[n] = c.querySelector('input');
      c.style.minWidth = '80px';
      ctl.appendChild(c);
    });
    var rs = slider('Rotate view', -40, 40, 1, 0, function (v) { return v + '°'; });
    rs._input.addEventListener('input', function () { rot = Number(rs._input.value); draw(); });
    ctl.appendChild(rs);
    var st = stage();
    var out = stats([{ k: 'Notation' }, { k: 'Intercepts' }, { k: 'd/a for cubic' }]);
    var note = el('div', 'callout callout--note', '');
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out); root.appendChild(note);

    function draw() {
      var h = Number(inputs.h.value) || 0, k = Number(inputs.k.value) || 0, l = Number(inputs.l.value) || 0;
      if (!h && !k && !l) { h = 1; inputs.h.value = 1; }
      var s = 170, ox = 150, oy = 230, dx = (0.44 + rot / 400) * s, dy = (0.30 - rot / 900) * s;
      function p(x, y, z) { return [ox + x * s + z * dx, oy - y * s - z * dy]; }
      var b = '', E = [[0,0,0,1,0,0],[1,0,0,1,1,0],[1,1,0,0,1,0],[0,1,0,0,0,0],
                       [0,0,1,1,0,1],[1,0,1,1,1,1],[1,1,1,0,1,1],[0,1,1,0,0,1],
                       [0,0,0,0,0,1],[1,0,0,1,0,1],[1,1,0,1,1,1],[0,1,0,0,1,1]];
      E.forEach(function (e, i) {
        var A = p(e[0], e[1], e[2]), B = p(e[3], e[4], e[5]);
        var back = (i === 4 || i === 7 || i === 8 || i === 11);
        b += H.ln(A[0], A[1], B[0], B[1], { color: back ? 'var(--rule)' : 'var(--ink-3)', w: back ? 1 : 1.4, dash: back ? '3 3' : '' });
      });
      /* axes */
      var O = p(0, 0, 0);
      b += H.tx(O[0] - 14, O[1] + 6, 'O', { size: 11, fill: 'var(--ink-3)', weight: 700 });
      var Xa = p(1.16, 0, 0), Ya = p(0, 1.16, 0), Za = p(0, 0, 1.16);
      b += H.arr(O[0], O[1], Xa[0], Xa[1], { color: 'var(--rule)', w: 1.2 });
      b += H.arr(O[0], O[1], Ya[0], Ya[1], { color: 'var(--rule)', w: 1.2 });
      b += H.arr(O[0], O[1], Za[0], Za[1], { color: 'var(--rule)', w: 1.2 });
      b += H.tx(Xa[0] + 6, Xa[1] + 4, 'x', { size: 11, fill: 'var(--ink-3)', style: 'italic' });
      b += H.tx(Ya[0] - 4, Ya[1] - 6, 'y', { size: 11, fill: 'var(--ink-3)', style: 'italic' });
      b += H.tx(Za[0] + 6, Za[1] - 4, 'z', { size: 11, fill: 'var(--ink-3)', style: 'italic' });

      var interText, dText;
      if (mode === 'direction') {
        var mx = Math.max(Math.abs(h), Math.abs(k), Math.abs(l)) || 1;
        var T = p(h / mx, k / mx, l / mx);
        b += H.arr(O[0], O[1], T[0], T[1], { color: 'var(--structure)', w: 3 });
        b += H.dot(T[0], T[1], 5, 'var(--structure)');
        interText = 'components ' + h + ', ' + k + ', ' + l;
        dText = '—';
      } else {
        /* intercepts at 1/h, 1/k, 1/l; build the polygon inside the cube */
        var verts = [];
        function addIfIn(x, y, z) {
          if (x >= -1e-9 && x <= 1 + 1e-9 && y >= -1e-9 && y <= 1 + 1e-9 && z >= -1e-9 && z <= 1 + 1e-9) verts.push([x, y, z]);
        }
        /* plane: hx + ky + lz = 1 (in units of a). Intersect with the 12 cube edges. */
        var edges = [[[0,0,0],[1,0,0]],[[0,1,0],[1,1,0]],[[0,0,1],[1,0,1]],[[0,1,1],[1,1,1]],
                     [[0,0,0],[0,1,0]],[[1,0,0],[1,1,0]],[[0,0,1],[0,1,1]],[[1,0,1],[1,1,1]],
                     [[0,0,0],[0,0,1]],[[1,0,0],[1,0,1]],[[0,1,0],[0,1,1]],[[1,1,0],[1,1,1]]];
        edges.forEach(function (E2) {
          var A = E2[0], B = E2[1];
          var fA = h * A[0] + k * A[1] + l * A[2] - 1, fB = h * B[0] + k * B[1] + l * B[2] - 1;
          if (Math.abs(fA - fB) < 1e-12) return;
          var t = fA / (fA - fB);
          if (t < -1e-9 || t > 1 + 1e-9) return;
          addIfIn(A[0] + t * (B[0] - A[0]), A[1] + t * (B[1] - A[1]), A[2] + t * (B[2] - A[2]));
        });
        /* de-duplicate and sort around the centroid in screen space */
        var uniq = [];
        verts.forEach(function (v) {
          if (!uniq.some(function (u) { return Math.abs(u[0]-v[0]) < 1e-6 && Math.abs(u[1]-v[1]) < 1e-6 && Math.abs(u[2]-v[2]) < 1e-6; })) uniq.push(v);
        });
        var scr = uniq.map(function (v) { return p(v[0], v[1], v[2]); });
        if (scr.length >= 3) {
          var cx = scr.reduce(function (a, q) { return a + q[0]; }, 0) / scr.length;
          var cy = scr.reduce(function (a, q) { return a + q[1]; }, 0) / scr.length;
          scr.sort(function (a, q) { return Math.atan2(a[1] - cy, a[0] - cx) - Math.atan2(q[1] - cy, q[0] - cx); });
          b += '<polygon points="' + scr.map(function (q) { return q[0].toFixed(1) + ',' + q[1].toFixed(1); }).join(' ') +
            '" fill="rgba(107,63,160,.24)" stroke="var(--diffraction)" stroke-width="2.4"/>';
          scr.forEach(function (q) { b += H.dot(q[0], q[1], 4, 'var(--diffraction)'); });
        } else {
          b += H.tx(250, 130, 'This plane does not cut the cube drawn — try smaller indices.', { size: 12, fill: 'var(--ink-3)', anchor: 'middle' });
        }
        interText = [h, k, l].map(function (v) { return v === 0 ? '∞' : (v === 1 ? '1' : '1/' + v); }).join(',  ');
        var sum = h * h + k * k + l * l;
        dText = sum ? '1/√' + sum + ' = ' + num(1 / Math.sqrt(sum), 4) : '—';
      }
      st.innerHTML = H.svg(500, 280, b);
      function fmt(v) { return v < 0 ? '<span style="text-decoration:overline">' + Math.abs(v) + '</span>' : String(v); }
      out.set('Notation', mode === 'plane' ? '(' + fmt(h) + fmt(k) + fmt(l) + ')' : '[' + fmt(h) + fmt(k) + fmt(l) + ']');
      out.set('Intercepts', interText);
      out.set('d/a for cubic', dText);
      note.innerHTML = mode === 'plane'
        ? '<div class="callout__title">◆ Reading it</div><p>A <b>zero</b> index means the plane never cuts that axis — it is parallel to it. ' +
          'For a cubic crystal only, d<sub>hkl</sub> = a/√(h²+k²+l²), and the direction [hkl] is normal to the plane (hkl).</p>'
        : '<div class="callout__title">◆ Reading it</div><p>Square brackets give a <b>vector from the origin</b>: h steps along a, k along b, l along c, reduced to smallest integers. ' +
          'Angle brackets ⟨hkl⟩ mean the whole family of symmetry-equivalent directions.</p>';
    }
    draw();
  };

  /* ── 3 · Bragg + simulated powder pattern (Topic 3) ───────── */
  W['bragg-explorer'] = function (root) {
    var ctl = el('div', 'controls');
    var lam = slider('Wavelength λ (nm)', 0.05, 0.30, 0.001, 0.15406, function (v) { return num(v, 5) + ' nm'; });
    var aP  = slider('Lattice parameter a (nm)', 0.20, 0.70, 0.001, 0.361, function (v) { return num(v, 3) + ' nm'; });
    var lat = 'fcc';
    [lam, aP].forEach(function (s) { s._input.addEventListener('input', draw); });
    ctl.appendChild(lam); ctl.appendChild(aP);
    ctl.appendChild(seg([{ v: 'sc', t: 'SC' }, { v: 'bcc', t: 'BCC' }, { v: 'fcc', t: 'FCC' }], 'fcc', function (v) { lat = v; draw(); }));
    var st = stage();
    var tb = el('div', '');
    root.appendChild(ctl); root.appendChild(st); root.appendChild(tb);

    function allowed(h, k, l) {
      if (lat === 'sc') return true;
      if (lat === 'bcc') return (h + k + l) % 2 === 0;
      var ev = [h, k, l].filter(function (x) { return x % 2 === 0; }).length;
      return ev === 3 || ev === 0;
    }
    function draw() {
      var L = Number(lam._input.value), a = Number(aP._input.value);
      var peaks = [], h, k, l, seen = {};
      for (h = 0; h <= 4; h++) for (k = 0; k <= 4; k++) for (l = 0; l <= 4; l++) {
        var s2 = h * h + k * k + l * l;
        if (!s2 || s2 > 16) continue;
        if (!allowed(h, k, l)) continue;
        var d = a / Math.sqrt(s2);
        var sn = L / (2 * d);
        if (sn > 1) continue;
        var two = 2 * Math.asin(sn) * 180 / Math.PI;
        var key = s2;
        if (seen[key]) continue;
        seen[key] = 1;
        peaks.push({ hkl: '' + h + k + l, s2: s2, d: d, th: Math.asin(sn) * 180 / Math.PI, two: two });
      }
      peaks.sort(function (x, y) { return x.two - y.two; });

      var ox = 52, oy = 200, w = 400, hh = 140;
      var b = '';
      b += H.ln(ox, oy, ox + w + 10, oy, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy + 6, ox, oy - hh - 14, { color: 'var(--ink-3)', w: 1.3 });
      b += H.tx(ox + w + 14, oy + 4, '2θ', { size: 12, fill: 'var(--ink-3)', weight: 800 });
      b += H.tx(ox - 6, oy - hh - 18, 'Intensity', { size: 11, fill: 'var(--ink-3)', anchor: 'middle', weight: 700 });
      var t;
      for (t = 0; t <= 140; t += 20) {
        var xx = ox + t / 140 * w;
        b += H.ln(xx, oy, xx, oy + 5, { color: 'var(--ink-3)', w: 1 });
        b += H.tx(xx, oy + 18, t + '°', { size: 10, fill: 'var(--ink-3)', anchor: 'middle' });
      }
      peaks.forEach(function (pk, i) {
        var xx = ox + pk.two / 140 * w;
        var inten = Math.max(0.22, Math.exp(-pk.s2 / 11));
        b += H.ln(xx, oy, xx, oy - inten * hh, { color: 'var(--diffraction)', w: 2.6 });
        b += H.tx(xx, oy - inten * hh - 6, pk.hkl, { size: 9.6, fill: 'var(--diffraction)', anchor: 'middle', weight: 800, mono: true });
      });
      if (!peaks.length) b += H.tx(ox + w / 2, oy - 60, 'No reflections: λ is too long for this lattice parameter.', { size: 12, fill: 'var(--crimson)', anchor: 'middle', weight: 700 });
      b += H.tx(ox, 24, 'Simulated powder pattern — ' + lat.toUpperCase() + ', λ = ' + num(L, 5) + ' nm, a = ' + num(a, 3) + ' nm', { size: 12, fill: 'var(--navy)', weight: 800 });
      b += H.tx(ox, 40, 'Peak heights are an illustrative envelope only — real intensities also carry multiplicity, Lorentz–polarisation and the atomic form factor.', { size: 9.6, fill: 'var(--ink-3)', style: 'italic' });
      st.innerHTML = H.svg(500, 228, b);

      tb.innerHTML = '<div class="tablewrap"><table><thead><tr><th>hkl</th><th class="num">h²+k²+l²</th><th class="num">d (nm)</th><th class="num">θ (°)</th><th class="num">2θ (°)</th></tr></thead><tbody>' +
        peaks.map(function (pk) {
          return '<tr><td><code>' + pk.hkl + '</code></td><td class="num">' + pk.s2 + '</td><td class="num">' + num(pk.d, 4) +
            '</td><td class="num">' + num(pk.th, 2) + '</td><td class="num">' + num(pk.two, 2) + '</td></tr>';
        }).join('') + '</tbody></table></div>' +
        '<p style="font-size:13.4px;color:var(--ink-3);margin:8px 0 0">Cu Kα is λ = 0.15406 nm — the default. Note how the ratio of the h²+k²+l² column identifies the lattice: 1:2:3:4… for SC, 2:4:6:8… for BCC, 3:4:8:11… for FCC.</p>';
    }
    draw();
  };

  /* ── 4 · structure factor / selection rules (Topic 4) ─────── */
  W['structure-factor-explorer'] = function (root) {
    var lat = 'bcc';
    var ctl = el('div', 'controls');
    ctl.appendChild(seg([{ v: 'sc', t: 'SC' }, { v: 'bcc', t: 'BCC' }, { v: 'fcc', t: 'FCC' }, { v: 'diamond', t: 'Diamond' }], 'bcc', function (v) { lat = v; draw(); }));
    var inputs = {};
    ['h', 'k', 'l'].forEach(function (n, i) {
      var c = el('div', 'ctrl');
      c.innerHTML = '<label>' + n + '</label><input type="number" value="' + [1, 0, 0][i] + '" min="0" max="6" step="1" style="width:66px">';
      c.querySelector('input').addEventListener('input', draw);
      inputs[n] = c.querySelector('input'); c.style.minWidth = '76px';
      ctl.appendChild(c);
    });
    var out = stats([{ k: 'Basis positions' }, { k: '|F| / f' }, { k: 'Verdict' }]);
    var work = el('div', 'eq');
    var rule = el('div', 'callout callout--key', '');
    root.appendChild(ctl); root.appendChild(out); root.appendChild(work); root.appendChild(rule);

    var BASES = {
      sc:      { pts: [[0,0,0]], label: '(0,0,0)' },
      bcc:     { pts: [[0,0,0],[0.5,0.5,0.5]], label: '(0,0,0), (½,½,½)' },
      fcc:     { pts: [[0,0,0],[0.5,0.5,0],[0.5,0,0.5],[0,0.5,0.5]], label: '(0,0,0), (½,½,0), (½,0,½), (0,½,½)' },
      diamond: { pts: [[0,0,0],[0.5,0.5,0],[0.5,0,0.5],[0,0.5,0.5],[0.25,0.25,0.25],[0.75,0.75,0.25],[0.75,0.25,0.75],[0.25,0.75,0.75]], label: 'FCC sites plus the same set displaced by (¼,¼,¼)' }
    };
    var RULES = {
      sc: 'Every (hkl) is allowed — a monatomic SC basis can never cancel.',
      bcc: 'Allowed when h + k + l is EVEN.',
      fcc: 'Allowed when h, k and l are ALL EVEN or ALL ODD (unmixed parity).',
      diamond: 'FCC rule, and in addition: if all indices are even, h + k + l must be divisible by 4. This is why (200) and (222) are absent in silicon.'
    };
    function draw() {
      var h = Number(inputs.h.value) || 0, k = Number(inputs.k.value) || 0, l = Number(inputs.l.value) || 0;
      var B = BASES[lat];
      var re = 0, im = 0, terms = [];
      B.pts.forEach(function (p2) {
        var ph = 2 * Math.PI * (h * p2[0] + k * p2[1] + l * p2[2]);
        re += Math.cos(ph); im += Math.sin(ph);
        terms.push('exp[2πi(' + num(h * p2[0], 2) + ' + ' + num(k * p2[1], 2) + ' + ' + num(l * p2[2], 2) + ')]');
      });
      var mag = Math.sqrt(re * re + im * im);
      var isZero = mag < 1e-9;
      out.set('Basis positions', '<small style="font-family:var(--sans);font-size:11.5px">' + B.label + '</small>');
      out.set('|F| / f', num(mag, 3));
      out.set('Verdict', isZero
        ? '<span style="color:var(--crimson)">ABSENT</span>'
        : '<span style="color:var(--ok)">ALLOWED</span>');
      work.innerHTML = '<div class="eq__body">F(' + h + k + l + ') / f  =  ' + terms.join('\n                 + ') +
        '\n\n                 =  ' + num(re, 3) + (im >= 0 ? ' + ' : ' − ') + num(Math.abs(im), 3) + 'i' +
        '\n         |F| / f  =  ' + num(mag, 3) + '</div>' +
        '<div class="eq__note">' + (isZero
          ? 'The complex amplitudes sum to zero. Bragg’s law may be satisfied for this plane family, but no intensity reaches the detector.'
          : 'A non-zero sum: this reflection appears in the pattern.') + '</div>';
      rule.innerHTML = '<div class="callout__title">◆ Selection rule for ' + lat.toUpperCase() + '</div><p>' + RULES[lat] + '</p>';
    }
    draw();
  };

  /* ── 5 · bond energy explorer (Topic 5) ───────────────────── */
  W['bond-energy-explorer'] = function (root) {
    var ctl = el('div', 'controls');
    var eps = slider('Well depth ε (eV)', 0.005, 1.2, 0.005, 0.35, function (v) { return num(v, 3) + ' eV'; });
    var sig = slider('σ (nm)', 0.15, 0.45, 0.005, 0.34, function (v) { return num(v, 3) + ' nm'; });
    [eps, sig].forEach(function (s) { s._input.addEventListener('input', draw); });
    ctl.appendChild(eps); ctl.appendChild(sig);
    var preset = seg([{ v: 'ar', t: 'Ar' }, { v: 'kr', t: 'Kr' }, { v: 'xe', t: 'Xe' }, { v: 'custom', t: 'Custom' }], 'custom', function (v) {
      var d = { ar: [0.0104, 0.340], kr: [0.0140, 0.365], xe: [0.0200, 0.398] }[v];
      if (d) { eps._input.value = d[0]; sig._input.value = d[1]; eps._sync(); sig._sync(); draw(); }
    });
    ctl.appendChild(preset);
    var st = stage();
    var out = stats([{ k: 'r₀ = 2^(1/6)σ' }, { k: 'U(r₀)' }, { k: 'Force constant K' }, { k: 'Est. ω (rad/s)' }]);
    var note = el('div', 'callout callout--note', '');
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out); root.appendChild(note);

    function draw() {
      var E = Number(eps._input.value), S = Number(sig._input.value);
      var r0 = Math.pow(2, 1 / 6) * S;
      /* K = d2U/dr2 at r0 = 72*2^(-1/3) * eps / sigma^2  (standard Lennard-Jones result) */
      var Knm = 72 * Math.pow(2, -1 / 3) * E / (S * S);          // eV / nm^2
      var Ksi = Knm * K.e / 1e-18;                                 // J/m^2 = N/m
      var mAr = 39.948 / (K.NA * 1000);                            // kg, argon as the reference mass
      var omega = Math.sqrt(Ksi / mAr);

      var ox = 62, oy = 210, w = 380, hh = 150, zero = oy - 88;
      function U(r) { return 4 * E * (Math.pow(S / r, 12) - Math.pow(S / r, 6)); }
      var rMin = S * 0.92, rMax = S * 2.9;
      function SX(r) { return ox + (r - rMin) / (rMax - rMin) * w; }
      var yscale = 78 / Math.max(E, 1e-6);
      function SY(u) { return Math.max(oy - hh - 10, Math.min(oy + 26, zero - u * yscale)); }
      var b = '';
      b += H.ln(ox, zero, ox + w + 10, zero, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy + 26, ox, oy - hh - 14, { color: 'var(--ink-3)', w: 1.3 });
      b += H.tx(ox + w + 14, zero + 4, 'r', { size: 12, fill: 'var(--ink-3)', weight: 800, style: 'italic' });
      b += H.tx(ox - 6, oy - hh - 18, 'U(r)', { size: 11, fill: 'var(--ink-3)', anchor: 'middle', weight: 700 });
      b += H.path(H.fn(U, rMin, rMax, 320, SX, SY), { stroke: 'var(--bonding)', w: 2.8 });
      b += H.ln(SX(r0), zero, SX(r0), SY(U(r0)), { color: 'var(--ink-3)', w: 1.2, dash: '3 3' });
      b += H.dot(SX(r0), SY(U(r0)), 5.5, 'var(--bonding)');
      b += H.tx(SX(r0), zero - 6, 'r₀', { size: 12, fill: 'var(--bonding)', anchor: 'middle', weight: 800 });
      b += H.ln(ox, SY(U(r0)), SX(r0), SY(U(r0)), { color: 'var(--ink-3)', w: 1.2, dash: '3 3' });
      b += H.tx(ox - 8, SY(U(r0)) + 4, '−ε', { size: 11, fill: 'var(--bonding)', anchor: 'end', weight: 800 });
      /* harmonic parabola fitted at r0 */
      b += H.path(H.fn(function (r) { return U(r0) + 0.5 * Knm * (r - r0) * (r - r0); },
        r0 - 0.6 * S, r0 + 0.6 * S, 80, SX, SY), { stroke: 'var(--phonon)', w: 2, dash: '5 3' });
      b += H.tx(SX(r0) + 96, SY(U(r0)) - 34, 'harmonic fit', { size: 10.4, fill: 'var(--phonon)', weight: 700 });
      var rt;
      for (rt = 0.4; rt <= rMax; rt += 0.1) { if (rt < rMin) continue; b += H.tx(SX(rt), zero + 18, num(rt, 1), { size: 9.6, fill: 'var(--ink-3)', anchor: 'middle' }); }
      b += H.tx(ox + w / 2, oy + 46, 'separation r (nm)', { size: 10.6, fill: 'var(--ink-3)', anchor: 'middle' });
      st.innerHTML = H.svg(500, 260, b);

      out.set('r₀ = 2^(1/6)σ', num(r0, 4) + ' <small>nm</small>');
      out.set('U(r₀)', '−' + num(E, 4) + ' <small>eV</small>');
      out.set('Force constant K', num(Ksi, 2) + ' <small>N/m</small>');
      out.set('Est. ω (rad/s)', sci(omega, 2));
      note.innerHTML = '<div class="callout__title">· What the two knobs actually control</div>' +
        '<p><b>ε sets the energy scale</b> — cohesive energy, melting point, how hard the solid is to pull apart. ' +
        '<b>σ sets the length scale</b> — equilibrium spacing and therefore lattice parameter. ' +
        'The <b>curvature</b> at r₀ is not an independent knob: it follows from both, as K = 72·2<sup>−1/3</sup>·ε/σ². ' +
        'That K is the spring constant Topic 6 uses to build phonons — the ω shown here uses the argon atomic mass as a reference.</p>';
    }
    draw();
  };

  /* ── 6 · phonon dispersion explorer (Topic 6) ─────────────── */
  W['phonon-explorer'] = function (root) {
    var chain = 'mono';
    var ctl = el('div', 'controls');
    ctl.appendChild(seg([{ v: 'mono', t: 'Monatomic' }, { v: 'di', t: 'Diatomic' }], 'mono', function (v) { chain = v; ratio.style.display = v === 'di' ? '' : 'none'; draw(); }));
    var kS = slider('Wavevector  ka/π', 0.02, 1, 0.01, 0.35, function (v) { return num(v, 2) + ' × π/a'; });
    var ratio = slider('Mass ratio M/m', 1.05, 6, 0.05, 2, function (v) { return num(v, 2); });
    ratio.style.display = 'none';
    [kS, ratio].forEach(function (s) { s._input.addEventListener('input', draw); });
    ctl.appendChild(kS); ctl.appendChild(ratio);
    var st = stage();
    var out = stats([{ k: 'ω / ω_max' }, { k: 'Group velocity' }, { k: 'Wavelength' }, { k: 'Motion' }]);
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out);

    function draw() {
      var t = Number(kS._input.value), Mr = Number(ratio._input.value);
      var b = '';
      /* left: real-space motion */
      var y1 = 66, sp = 34, x0 = 30, i;
      var branch = 'acoustic';
      var wA, wO, wmax, vg;
      if (chain === 'mono') {
        wmax = 2;
        var w = 2 * Math.abs(Math.sin(t * Math.PI / 2));
        vg = Math.cos(t * Math.PI / 2);
        for (i = 0; i < 11; i++) {
          var x = x0 + i * sp;
          var d = 12 * Math.sin(Math.PI * t * i);
          b += H.ring(x, y1, 8, 'var(--rule)', 1);
          b += H.dot(x + d, y1, 8, 'var(--structure)');
        }
        b += H.tx(x0, y1 + 34, 'Monatomic chain — displacement pattern at this k', { size: 10.6, fill: 'var(--ink-3)' });
        out.set('ω / ω_max', num(w / wmax, 3));
        out.set('Group velocity', num(vg, 3) + ' <small>× a√(C/M)</small>');
        out.set('Wavelength', t > 0.001 ? num(2 / t, 2) + ' <small>× a</small>' : '—');
        out.set('Motion', vg < 0.02 ? 'standing wave' : 'travelling');
      } else {
        var M = Mr, m = 1, Cc = 1;
        function br(tt) {
          var ka = tt * Math.PI, s = Math.sin(ka / 2);
          var A = Cc * (1 / M + 1 / m);
          var B = Math.sqrt(Math.max(0, A * A - 4 * Cc * Cc * s * s / (M * m)));
          return [Math.sqrt(A - B), Math.sqrt(A + B)];
        }
        wmax = br(0.0001)[1];
        var vv = br(t); wA = vv[0]; wO = vv[1];
        var d2 = br(Math.min(1, t + 0.01)), vgA = (d2[0] - wA) / 0.01;
        for (i = 0; i < 11; i++) {
          var x2 = x0 + i * sp, big = i % 2 === 0;
          var dd = 11 * Math.sin(Math.PI * t * Math.floor(i / 2) * 2 / 2) * (big ? 1 : 1);
          b += H.ring(x2, y1, big ? 9 : 6.5, 'var(--rule)', 1);
          b += H.dot(x2 + dd, y1, big ? 9 : 6.5, big ? 'var(--structure)' : 'var(--phonon)');
          var dd2 = 11 * Math.sin(Math.PI * t * Math.floor(i / 2) * 2 / 2) * (big ? 1 : -M / m * 0.5);
          b += H.ring(x2, y1 + 56, big ? 9 : 6.5, 'var(--rule)', 1);
          b += H.dot(x2 + dd2, y1 + 56, big ? 9 : 6.5, big ? 'var(--structure)' : 'var(--phonon)');
        }
        b += H.tx(x0, y1 - 18, 'ACOUSTIC — in phase', { size: 10.4, fill: 'var(--bonding)', weight: 800 });
        b += H.tx(x0, y1 + 38, 'OPTICAL — out of phase', { size: 10.4, fill: 'var(--crimson)', weight: 800 });
        out.set('ω / ω_max', 'ac ' + num(wA / wmax, 3) + ' · op ' + num(wO / wmax, 3));
        out.set('Group velocity', 'ac ' + num(vgA, 3) + ' <small>(arb.)</small>');
        out.set('Wavelength', t > 0.001 ? num(2 / t, 2) + ' <small>× a</small>' : '—');
        out.set('Motion', 'gap ' + num((wO - wA) / wmax, 3) + ' at this k');
      }

      /* right: dispersion */
      var ox = 300, oy = 236, w2 = 170, h2 = 150;
      b += H.ln(ox, oy, ox + w2 + 12, oy, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy + 6, ox, oy - h2 - 14, { color: 'var(--ink-3)', w: 1.3 });
      b += H.tx(ox + w2 + 16, oy + 4, 'k', { size: 12, fill: 'var(--ink-3)', weight: 800, style: 'italic' });
      b += H.tx(ox + 6, oy - h2 - 18, 'ω', { size: 12, fill: 'var(--ink-3)', weight: 800, style: 'italic' });
      b += H.tx(ox + w2, oy + 18, 'π/a', { size: 10.4, fill: 'var(--crimson)', anchor: 'middle', weight: 700 });
      b += H.tx(ox, oy + 18, '0', { size: 10.4, fill: 'var(--ink-3)', anchor: 'middle' });
      b += H.ln(ox + w2, oy, ox + w2, oy - h2, { color: 'var(--crimson)', w: 1.4, dash: '5 4' });
      if (chain === 'mono') {
        b += H.path(H.fn(function (tt) { return 2 * Math.abs(Math.sin(tt * Math.PI / 2)) / 2; }, 0.001, 1, 140,
          function (tt) { return ox + tt * w2; }, function (v) { return oy - v * h2; }), { stroke: 'var(--phonon)', w: 2.8 });
        var wc = 2 * Math.abs(Math.sin(t * Math.PI / 2)) / 2;
        b += H.dot(ox + t * w2, oy - wc * h2, 6, 'var(--crimson)');
      } else {
        var M2 = Mr, m2 = 1;
        function br2(tt) {
          var ka = tt * Math.PI, s = Math.sin(ka / 2), A = (1 / M2 + 1 / m2);
          var B = Math.sqrt(Math.max(0, A * A - 4 * s * s / (M2 * m2)));
          return [Math.sqrt(A - B), Math.sqrt(A + B)];
        }
        var wm = br2(0.0001)[1];
        b += H.path(H.fn(function (tt) { return br2(tt)[0] / wm; }, 0.001, 1, 120,
          function (tt) { return ox + tt * w2; }, function (v) { return oy - v * h2; }), { stroke: 'var(--bonding)', w: 2.6 });
        b += H.path(H.fn(function (tt) { return br2(tt)[1] / wm; }, 0.001, 1, 120,
          function (tt) { return ox + tt * w2; }, function (v) { return oy - v * h2; }), { stroke: 'var(--crimson)', w: 2.6 });
        var lo = br2(1)[0] / wm, hi = br2(1)[1] / wm;
        b += H.rect(ox, oy - hi * h2, w2, (hi - lo) * h2, { fill: 'rgba(158,27,50,.11)' });
        b += H.tx(ox + w2 / 2, oy - (hi + lo) / 2 * h2 + 4, 'gap', { size: 9.6, fill: 'var(--crimson)', anchor: 'middle', weight: 800 });
        var cur = br2(t);
        b += H.dot(ox + t * w2, oy - cur[0] / wm * h2, 5.5, 'var(--bonding)');
        b += H.dot(ox + t * w2, oy - cur[1] / wm * h2, 5.5, 'var(--crimson)');
      }
      st.innerHTML = H.svg(500, 262, b);
    }
    draw();
  };

  /* ── 7 · heat capacity + thermal conductivity (Topic 7) ───── */
  W['heat-capacity-explorer'] = function (root) {
    var ctl = el('div', 'controls');
    var TD = slider('Debye temperature Θ_D (K)', 80, 2300, 5, 428, function (v) { return v + ' K'; });
    var TT = slider('Temperature T (K)', 2, 900, 1, 300, function (v) { return v + ' K'; });
    [TD, TT].forEach(function (s) { s._input.addEventListener('input', draw); });
    ctl.appendChild(TD); ctl.appendChild(TT);
    ctl.appendChild(seg([{ v: 428, t: 'Cu 343' }, { v: 645, t: 'Si 645' }, { v: 2230, t: 'C 2230' }, { v: 105, t: 'Pb 105' }].map(function (o) { return { v: o.v, t: o.t }; }), null, function (v) {
      TD._input.value = v; TD._sync(); draw();
    }));
    var st = stage();
    var out = stats([{ k: 'T / Θ_D' }, { k: 'C_V (Debye)' }, { k: 'C_V (Einstein)' }, { k: 'Regime' }]);
    var note = el('div', 'callout callout--note', '');
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out); root.appendChild(note);

    function debye(x) {                 /* x = T/Θ_D, returns C_V / 3Nk_B */
      if (x <= 0.001) return 0;
      var n = 300, s = 0, i, u, dx = (1 / x) / n;
      for (i = 1; i <= n; i++) {
        u = i * dx;
        var e = Math.exp(u);
        if (!isFinite(e)) break;
        s += Math.pow(u, 4) * e / ((e - 1) * (e - 1)) * dx;
      }
      return Math.min(1, 3 * Math.pow(x, 3) * s);
    }
    function einstein(x) {              /* x = T/Θ_E, returns C_V / 3Nk_B */
      if (x <= 0.001) return 0;
      var u = 1 / x, e = Math.exp(u);
      if (!isFinite(e)) return 0;
      return u * u * e / ((e - 1) * (e - 1));
    }
    function draw() {
      var Th = Number(TD._input.value), T = Number(TT._input.value);
      var x = T / Th;
      var cd = debye(x), ce = einstein(T / (0.75 * Th));   /* Θ_E ≈ 0.75 Θ_D is the usual matching */
      var ox = 62, oy = 214, w = 380, hh = 156;
      var b = '';
      b += H.ln(ox, oy, ox + w + 12, oy, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy + 6, ox, oy - hh - 16, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy - hh, ox + w, oy - hh, { color: 'var(--ink-3)', w: 1.2, dash: '4 4' });
      b += H.tx(ox - 8, oy - hh + 4, '3Nk_B', { size: 10.4, fill: 'var(--ink-3)', anchor: 'end', weight: 700 });
      b += H.tx(ox + w + 16, oy + 4, 'T/Θ', { size: 11, fill: 'var(--ink-3)', weight: 700 });
      b += H.tx(ox - 6, oy - hh - 20, 'C_V', { size: 11.5, fill: 'var(--ink-3)', anchor: 'middle', weight: 700 });
      var XM = 1.6, tt;
      for (tt = 0; tt <= XM; tt += 0.4) {
        b += H.ln(ox + tt / XM * w, oy, ox + tt / XM * w, oy + 5, { color: 'var(--ink-3)', w: 1 });
        b += H.tx(ox + tt / XM * w, oy + 18, num(tt, 1), { size: 10, fill: 'var(--ink-3)', anchor: 'middle' });
      }
      b += H.path(H.fn(function (u) { return einstein(u / 0.75); }, 0.02, XM, 90,
        function (u) { return ox + u / XM * w; }, function (v) { return oy - v * hh; }), { stroke: 'var(--diffraction)', w: 2.2, dash: '6 4' });
      b += H.path(H.fn(debye, 0.02, XM, 90,
        function (u) { return ox + u / XM * w; }, function (v) { return oy - v * hh; }), { stroke: 'var(--bonding)', w: 3 });
      if (x <= XM) {
        b += H.ln(ox + x / XM * w, oy, ox + x / XM * w, oy - hh - 6, { color: 'var(--crimson)', w: 1.5, dash: '4 3' });
        b += H.dot(ox + x / XM * w, oy - cd * hh, 6, 'var(--bonding)');
        b += H.dot(ox + x / XM * w, oy - ce * hh, 5, 'var(--diffraction)');
        b += H.tx(ox + x / XM * w, oy - hh - 12, 'T = ' + T + ' K', { size: 10.4, fill: 'var(--crimson)', anchor: 'middle', weight: 800 });
      } else {
        b += H.tx(ox + w - 4, oy - hh - 12, 'T is off scale — both models have saturated', { size: 10.2, fill: 'var(--crimson)', anchor: 'end', weight: 700 });
      }
      b += H.tx(ox + w - 4, oy - 30, 'Debye', { size: 11, fill: 'var(--bonding)', anchor: 'end', weight: 800 });
      b += H.tx(ox + w - 4, oy - 16, 'Einstein (Θ_E = 0.75 Θ_D)', { size: 10, fill: 'var(--diffraction)', anchor: 'end', weight: 700 });
      st.innerHTML = H.svg(500, 246, b);

      out.set('T / Θ_D', num(x, 3));
      out.set('C_V (Debye)', num(cd, 3) + ' <small>× 3Nk_B</small>');
      out.set('C_V (Einstein)', num(ce, 3) + ' <small>× 3Nk_B</small>');
      out.set('Regime', x < 0.1 ? 'low T — T³ law' : (x > 1 ? 'classical — Dulong–Petit' : 'crossover'));
      note.innerHTML = '<div class="callout__title">· Reading the two curves</div><p>' +
        (x < 0.1
          ? 'Below about Θ_D/10 the Debye result becomes C_V ≈ 234 Nk_B (T/Θ_D)³. Einstein has already dropped far below it, because his single frequency freezes out exponentially while real long-wavelength acoustic modes never do.'
          : x > 1
            ? 'Above Θ_D every mode is thermally excited, each contributes k_B, and both models return the classical Dulong–Petit value 3Nk_B. This is why the classical law works for lead at room temperature but fails badly for diamond.'
            : 'In the crossover the two models differ most. Θ_D is essentially a stiffness-and-mass thermometer: light, stiffly bonded diamond has Θ_D ≈ 2230 K, heavy, softly bonded lead only about 105 K.') + '</p>';
    }
    draw();
  };

  /* ── 8 · free-electron Fermi gas (Topic 8) ────────────────── */
  W['fermi-explorer'] = function (root) {
    var ctl = el('div', 'controls');
    var nS = slider('Electron density n (10²⁸ m⁻³)', 0.5, 25, 0.1, 8.5, function (v) { return num(v, 1) + '×10²⁸'; });
    var TS = slider('Temperature T (K)', 1, 3000, 1, 300, function (v) { return v + ' K'; });
    [nS, TS].forEach(function (s) { s._input.addEventListener('input', draw); });
    ctl.appendChild(nS); ctl.appendChild(TS);
    ctl.appendChild(seg([{ v: 2.65, t: 'Na' }, { v: 8.47, t: 'Cu' }, { v: 5.86, t: 'Ag' }, { v: 18.1, t: 'Al' }], null, function (v) {
      nS._input.value = v; nS._sync(); draw();
    }));
    var st = stage();
    var out = stats([{ k: 'E_F' }, { k: 'k_F' }, { k: 'v_F' }, { k: 'T_F' }, { k: 'k_BT / E_F' }]);
    var note = el('div', 'callout callout--note', '');
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out); root.appendChild(note);

    function draw() {
      var n = Number(nS._input.value) * 1e28, T = Number(TS._input.value);
      var kF = Math.pow(3 * Math.PI * Math.PI * n, 1 / 3);
      var EF = K.hbar * K.hbar * kF * kF / (2 * K.me);
      var vF = K.hbar * kF / K.me;
      var TF = EF / K.kB;
      var ratio = K.kB * T / EF;

      var ox = 58, oy = 200, w = 380, hh = 150;
      var b = '';
      b += H.ln(ox, oy, ox + w + 12, oy, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy + 6, ox, oy - hh - 16, { color: 'var(--ink-3)', w: 1.3 });
      b += H.tx(ox + w + 16, oy + 4, 'E', { size: 12, fill: 'var(--ink-3)', weight: 800, style: 'italic' });
      b += H.tx(ox - 4, oy - hh - 20, 'g(E)·f(E)', { size: 10.6, fill: 'var(--ink-3)', anchor: 'middle', weight: 700 });
      var EMAX = 1.7;                       /* in units of E_F */
      function g(x) { return Math.sqrt(Math.max(0, x)); }
      function f(x) { return 1 / (1 + Math.exp((x - 1) / Math.max(1e-9, ratio))); }
      /* g(E) envelope */
      b += H.path(H.fn(function (x) { return g(x) / Math.sqrt(EMAX); }, 0, EMAX, 160,
        function (x) { return ox + x / EMAX * w; }, function (v) { return oy - v * hh; }), { stroke: 'var(--rule)', w: 2, dash: '5 4' });
      /* occupied area */
      var d = 'M' + ox + ',' + oy, i;
      for (i = 0; i <= 200; i++) {
        var x = EMAX * i / 200;
        d += ' L' + (ox + x / EMAX * w) + ',' + (oy - g(x) * f(x) / Math.sqrt(EMAX) * hh);
      }
      d += ' L' + (ox + w) + ',' + oy + ' Z';
      b += H.path(d, { fill: 'rgba(14,124,153,.32)', stroke: 'none' });
      b += H.path(H.fn(function (x) { return g(x) * f(x) / Math.sqrt(EMAX); }, 0, EMAX, 220,
        function (x) { return ox + x / EMAX * w; }, function (v) { return oy - v * hh; }), { stroke: 'var(--electron)', w: 2.8 });
      b += H.ln(ox + w / EMAX, oy, ox + w / EMAX, oy - hh - 8, { color: 'var(--crimson)', w: 1.5, dash: '4 3' });
      b += H.tx(ox + w / EMAX, oy + 18, 'E_F', { size: 11.5, fill: 'var(--crimson)', anchor: 'middle', weight: 800 });
      b += H.tx(ox + w / EMAX, oy - hh - 12, num(EF / K.e, 2) + ' eV', { size: 10.4, fill: 'var(--crimson)', anchor: 'middle', weight: 700 });
      /* smear width */
      var half = Math.max(2, 2.2 * ratio / EMAX * w);
      b += H.rect(ox + w / EMAX - half, oy - hh, 2 * half, hh, { fill: 'rgba(158,27,50,.12)' });
      b += H.tx(ox + 8, oy - hh + 12, 'g(E) ∝ √E', { size: 10.4, fill: 'var(--ink-3)', weight: 700 });
      b += H.tx(ox + w - 4, oy - 24, 'thermally smeared over ~ few k_BT', { size: 10, fill: 'var(--crimson)', anchor: 'end', weight: 700 });
      st.innerHTML = H.svg(500, 234, b);

      out.set('E_F', num(EF / K.e, 3) + ' <small>eV</small>');
      out.set('k_F', sci(kF, 3) + ' <small>m⁻¹</small>');
      out.set('v_F', sci(vF, 3) + ' <small>m/s</small>');
      out.set('T_F', Math.round(TF).toLocaleString() + ' <small>K</small>');
      out.set('k_BT / E_F', num(ratio, 4));
      note.innerHTML = '<div class="callout__title">· What the numbers are telling you</div>' +
        '<p>T_F is <b>' + Math.round(TF).toLocaleString() + ' K</b> while the sample is at ' + T + ' K. ' +
        'A metal at room temperature is a <b>cold</b> Fermi gas: only about ' + num(ratio * 100, 2) + '% of the electrons sit close enough to E_F to be thermally excited. ' +
        'That is why the measured electronic heat capacity is roughly a hundred times smaller than the classical (3/2)Nk_B, and why the free-electron model — which failed so badly for Drude — works once Fermi–Dirac statistics are put in.</p>';
    }
    draw();
  };

  /* ── 9 · band structure explorer (Topic 9) ────────────────── */
  W['band-explorer'] = function (root) {
    var ctl = el('div', 'controls');
    var VS = slider('Potential strength |U|  (gap size)', 0, 0.60, 0.01, 0.18, function (v) { return num(v, 2); });
    var FS = slider('Valence electrons per cell', 1, 4, 1, 1, function (v) { return v; });
    [VS, FS].forEach(function (s) { s._input.addEventListener('input', draw); });
    ctl.appendChild(VS); ctl.appendChild(FS);
    var scheme = 'reduced';
    ctl.appendChild(seg([{ v: 'reduced', t: 'Reduced zone' }, { v: 'extended', t: 'Extended zone' }], 'reduced', function (v) { scheme = v; draw(); }));
    var st = stage();
    var out = stats([{ k: 'Gap at π/a' }, { k: 'Bands filled' }, { k: 'Character' }]);
    var note = el('div', 'callout callout--key', '');
    root.appendChild(ctl); root.appendChild(st); root.appendChild(out); root.appendChild(note);

    function draw() {
      var U = Number(VS._input.value), Z = Number(FS._input.value);
      var ox = 250, oy = 250, w = 190, hh = 200;
      var b = '';
      b += H.ln(ox - w - 12, oy, ox + w + 12, oy, { color: 'var(--ink-3)', w: 1.3 });
      b += H.ln(ox, oy + 6, ox, oy - hh - 16, { color: 'var(--ink-3)', w: 1.3 });
      b += H.tx(ox + w + 16, oy + 4, 'k', { size: 12, fill: 'var(--ink-3)', weight: 800, style: 'italic' });
      b += H.tx(ox + 8, oy - hh - 20, 'E', { size: 12, fill: 'var(--ink-3)', weight: 800, style: 'italic' });
      b += H.tx(ox + w, oy + 18, 'π/a', { size: 10.4, fill: 'var(--crimson)', anchor: 'middle', weight: 700 });
      b += H.tx(ox - w, oy + 18, '−π/a', { size: 10.4, fill: 'var(--crimson)', anchor: 'middle', weight: 700 });
      b += H.ln(ox + w, oy, ox + w, oy - hh, { color: 'var(--crimson)', w: 1.3, dash: '5 4' });
      b += H.ln(ox - w, oy, ox - w, oy - hh, { color: 'var(--crimson)', w: 1.3, dash: '5 4' });

      /* free electron reference (extended zone) */
      var ESC = hh / 4.2;   /* energy scale: E in units where E(π/a) = 1 */
      function Efree(q) { return q * q; }                            /* q in units of π/a */
      /* band n in the reduced scheme: fold q -> q + 2n, then split at the boundaries */
      function bandE(nb, q) {
        /* nb = 0,1,2,3 ; q in [-1,1] */
        var base, sign;
        if (nb === 0) { base = Efree(q); }
        else if (nb === 1) { base = Efree(Math.abs(q) - 2); }
        else if (nb === 2) { base = Efree(Math.abs(q) + 2); }
        else { base = Efree(Math.abs(q) - 4); }
        /* open a gap of 2U at |q| = 1 for the lower pair, at q = 0 for the next */
        var edge = (nb === 0 || nb === 1) ? 1 : 0;
        var dist = Math.abs(Math.abs(q) - edge);
        var split = U * Math.exp(-8 * dist * dist);
        return base + (nb === 0 || nb === 2 ? -split : +split);
      }
      var cols = ['var(--electron)', 'var(--diffraction)', 'var(--phonon)', 'var(--bonding)'];
      var nb;
      if (scheme === 'extended') {
        b += H.path(H.fn(function (q) { return Efree(q); }, -2.2, 2.2, 200,
          function (q) { return ox + q / 2.2 * (w + 10); }, function (v) { return oy - v / 4.84 * hh; }), { stroke: 'var(--rule)', w: 2, dash: '5 4' });
        for (nb = 0; nb < 2; nb++) {
          b += H.path(H.fn(function (q) { return bandE(nb, q); }, -1, 1, 160,
            function (q) { return ox + q * w; }, function (v) { return oy - v * ESC; }), { stroke: cols[nb], w: 2.8 });
        }
        b += H.tx(ox - w - 8, oy - hh - 4, 'grey dashed = free electron parabola, unfolded', { size: 10, fill: 'var(--ink-3)' });
      } else {
        for (nb = 0; nb < 4; nb++) {
          b += H.path(H.fn(function (q) { return bandE(nb, q); }, -1, 1, 160,
            function (q) { return ox + q * w; }, function (v) { return oy - v * ESC; }), { stroke: cols[nb], w: 2.6 });
        }
      }
      /* gap shading at the boundary */
      var lo = bandE(0, 1), hi = bandE(1, 1);
      if (hi > lo) {
        b += H.rect(ox - w, oy - hi * ESC, 2 * w, (hi - lo) * ESC, { fill: 'rgba(158,27,50,.13)' });
        b += H.tx(ox, oy - (hi + lo) / 2 * ESC + 4, 'E_g', { size: 12, fill: 'var(--crimson)', anchor: 'middle', weight: 800 });
      }
      /* Fermi level from the filling */
      var bandsFilled = Z / 2;
      var EFy;
      if (bandsFilled % 1 === 0 && U > 0.02) {
        /* exactly filled bands: E_F sits in a gap */
        EFy = (bandE(bandsFilled - 1, 1) + bandE(bandsFilled, 1)) / 2;
      } else {
        EFy = bandE(Math.floor(bandsFilled), Math.min(1, (bandsFilled % 1) * 2 || 0.5));
      }
      b += H.ln(ox - w - 8, oy - EFy * ESC, ox + w + 8, oy - EFy * ESC, { color: 'var(--crimson)', w: 2 });
      b += H.tx(ox + w + 12, oy - EFy * ESC + 4, 'E_F', { size: 11, fill: 'var(--crimson)', weight: 800 });
      st.innerHTML = H.svg(500, 288, b);

      var isMetal = (Z % 2 === 1) || U < 0.02;
      out.set('Gap at π/a', U < 0.02 ? 'none' : num(2 * U, 2) + ' <small>(arb.)</small>');
      out.set('Bands filled', Z % 2 === 0 ? (Z / 2) + ' exactly' : Math.floor(Z / 2) + ' + a half-filled band');
      out.set('Character', isMetal
        ? '<span style="color:var(--electron)">METAL</span>'
        : (U < 0.25 ? '<span style="color:var(--phonon)">SEMICONDUCTOR</span>' : '<span style="color:var(--crimson)">INSULATOR</span>'));
      note.innerHTML = '<div class="callout__title">◆ The counting rule</div><p>' +
        (Z % 2 === 1
          ? 'An <b>odd</b> number of valence electrons per primitive cell leaves the top band half full. There are empty states immediately above the occupied ones, so any field at all produces current. This crystal is a metal <em>whatever the gap size</em>.'
          : 'An <b>even</b> number of valence electrons fills bands exactly. Whether the crystal conducts then depends entirely on the gap: small enough and thermal excitation supplies carriers (semiconductor), large enough and it does not (insulator). Set the potential to zero and the gap closes — the bands overlap and even this crystal becomes metallic.') +
        '</p>';
    }
    draw();
  };

  /* ── 10 · practice hub engine ─────────────────────────────── */
  W['practice-hub'] = function (root) {
    var BANK = (P.practiceBank || []);
    var f = { topic: 'all', level: 'all', type: 'all' };
    var bar = el('div', '');
    var list = el('div', '');
    root.appendChild(bar); root.appendChild(list);

    function pills(key, label, values) {
      var wrap = el('div', 'filters');
      wrap.appendChild(el('span', '', '<span style="font-size:11.5px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--ink-3);align-self:center;padding-right:4px">' + label + '</span>'));
      values.forEach(function (v) {
        var b = el('button', 'pill' + (f[key] === v.v ? ' is-on' : ''), v.t);
        b.addEventListener('click', function () {
          f[key] = v.v;
          Array.prototype.forEach.call(wrap.querySelectorAll('.pill'), function (x) { x.classList.remove('is-on'); });
          b.classList.add('is-on'); render();
        });
        wrap.appendChild(b);
      });
      return wrap;
    }
    var topics = [{ v: 'all', t: 'All topics' }].concat(
      [1,2,3,4,5,6,7,8,9].map(function (i) { return { v: i, t: 'T' + i }; }));
    bar.appendChild(pills('topic', 'Topic', topics));
    bar.appendChild(pills('level', 'Level', [{ v: 'all', t: 'All' }, { v: 'Foundation', t: '🟢 Foundation' }, { v: 'Connect', t: '🟠 Connect' }, { v: 'Materials Challenge', t: '🔵 Materials challenge' }]));
    /* Put the live count on each Type pill. Without it a reader has no way to tell that
       there are 32 calculation questions in here without clicking through every filter. */
    function nOf(pred) { return BANK.filter(pred).length; }
    bar.appendChild(pills('type', 'Type', [
      { v: 'all', t: 'All (' + BANK.length + ')' },
      { v: 'Calculation', t: 'Calculation (' + nOf(function (q) { return q.type === 'Calculation'; }) + ')' },
      { v: 'MCQ', t: 'MCQ (' + nOf(function (q) { return q.type === 'MCQ'; }) + ')' },
      { v: 'Explain', t: 'Explain (' + nOf(function (q) { return q.type === 'Explain'; }) + ')' },
      { v: 'Spot the Error', t: 'Spot the error (' + nOf(function (q) { return q.type === 'Spot the Error'; }) + ')' },
      { v: 'Materials', t: 'Materials (' + nOf(function (q) { return q.type === 'Materials'; }) + ')' }
    ]));

    function render() {
      var qs = BANK.filter(function (q) {
        return (f.topic === 'all' || q.topic === f.topic) &&
               (f.level === 'all' || q.level === f.level) &&
               (f.type === 'all' || q.type === f.type);
      });
      if (!qs.length) { list.innerHTML = '<div class="empty">No questions match these filters. Widen one of them.</div>'; return; }
      list.innerHTML = '<p style="font-size:13.4px;color:var(--ink-3);margin:6px 0 14px">Showing <b>' + qs.length + '</b> of ' + BANK.length + ' questions.</p>' +
        qs.map(function (q) {
          var lvl = { 'Foundation': 'f', 'Connect': 'c', 'Materials Challenge': 'm' }[q.level] || 'f';
          var opts = q.options ? '<div class="check__opts" style="margin-top:8px">' + q.options.map(function (o, i) {
            return '<button class="opt" data-k="' + i + '"><span class="k">' + 'ABCD'[i] + '</span><span>' + P.md(o) + '</span></button>';
          }).join('') + '</div>' : '';
          return '<div class="q" data-answer="' + (q.answerIndex == null ? -1 : q.answerIndex) + '">' +
            '<div class="q__head"><span class="q__id">' + q.id + '</span>' +
            '<span class="badge badge--' + lvl + '">' + q.level + '</span>' +
            '<span class="badge">' + q.type + '</span>' +
            '<span class="badge">Topic ' + q.topic + '</span>' +
            '<span class="badge">' + q.clo + '</span></div>' +
            '<div class="q__body"><div class="q__prompt">' + P.md(q.prompt) + '</div>' + opts +
            (q.workspace ? '<p style="font-size:13.6px;color:var(--ink-3);margin:8px 0 0"><b>Approach.</b> ' + P.md(q.workspace) + '</p>' : '') +
            '<div class="q__tools">' +
              (q.hint1 ? '<button class="btn btn--ghost" data-act="h1">Hint 1</button>' : '') +
              (q.hint2 ? '<button class="btn btn--ghost" data-act="h2">Hint 2</button>' : '') +
              '<button class="btn" data-act="sol">Show worked answer</button></div>' +
            '<div class="q__reveal hidden" data-r="h1"><span class="lbl">Hint 1</span>' + P.md(q.hint1 || '') + '</div>' +
            '<div class="q__reveal hidden" data-r="h2"><span class="lbl">Hint 2</span>' + P.md(q.hint2 || '') + '</div>' +
            '<div class="q__reveal hidden" data-r="sol">' +
              (q.equation ? '<span class="lbl">Result</span><code>' + P.esc(q.equation) + '</code>' : '') +
              '<span class="lbl">Worked answer</span>' + P.md(q.solution) +
              '<span class="lbl">What it means</span>' + P.md(q.meaning) + '</div>' +
            '</div></div>';
        }).join('');
    }
    list.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-act]');
      if (btn) {
        var card = btn.closest('.q');
        var r = card.querySelector('[data-r="' + btn.dataset.act + '"]');
        if (r) { r.classList.toggle('hidden'); btn.textContent = r.classList.contains('hidden') ? btn.textContent.replace('Hide', 'Show') : btn.textContent.replace('Show', 'Hide'); }
        return;
      }
      var opt = e.target.closest('.q .opt');
      if (opt) {
        var q = opt.closest('.q'), ans = Number(q.dataset.answer);
        Array.prototype.forEach.call(q.querySelectorAll('.opt'), function (o, i) {
          o.disabled = true;
          if (i === ans) o.classList.add('is-right');
          else if (o === opt) o.classList.add('is-wrong');
        });
      }
    });
    render();
  };

  /* ── 11 · P4PH project planner ────────────────────────────── */
  W['p4ph-planner'] = function (root) {
    var KEY = 'phy3201.p4ph.v1';
    var STEPS = [
      { k: 'problem',   t: '1 · The planetary-health problem', p: 'State the problem in one sentence, with a number attached. Not "pollution" — "Malaysian households still use X TWh on lighting each year."' },
      { k: 'tech',      t: '2 · The material or technology',   p: 'Name the specific material or device. Not "solar" — "single-crystal silicon in a PERC cell."' },
      { k: 'concepts',  t: '3 · At least TWO PHY3201 concepts', p: 'Name them and say which topic each comes from. Two is the minimum; a chain of three is stronger.' },
      { k: 'chain',     t: '4 · The full physics chain',        p: 'Structure → mechanism → property → device behaviour → planetary-health outcome. Every arrow must be a physics statement, not an association.' },
      { k: 'evidence',  t: '5 · Evidence and the trade-off',    p: 'One sourced number with its date, and one honest limitation or trade-off. A project with no trade-off has not been thought through.' }
    ];
    var state = {};
    try { state = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { state = {}; }

    var wrap = el('div', '');
    root.appendChild(wrap);
    wrap.innerHTML = STEPS.map(function (s) {
      return '<div class="card" style="margin-bottom:12px">' +
        '<h3 style="margin-top:0">' + s.t + '</h3>' +
        '<p style="font-size:13.6px;color:var(--ink-3)">' + s.p + '</p>' +
        '<textarea data-k="' + s.k + '" rows="3" style="width:100%;font:inherit;font-size:14.5px;padding:9px;border:1px solid var(--rule);border-radius:8px;background:var(--paper-2);color:var(--ink);resize:vertical"></textarea>' +
        '</div>';
    }).join('') +
      '<div class="readout"><div class="stat"><div class="stat__k">Checkpoint</div><div class="stat__v" id="p4phScore">0 / 5</div></div></div>' +
      '<div class="q__tools" style="margin-top:12px">' +
        '<button class="btn" data-act="copy">Copy my plan</button>' +
        '<button class="btn btn--ghost" data-act="clear">Clear</button></div>' +
      '<div class="callout callout--warn" style="margin-top:14px"><div class="callout__title">! Before you film anything</div>' +
      '<p>All five boxes must be filled and checked by your group. A video made before step 4 exists will describe a technology rather than explain its physics — and the rubric marks the physics chain, not the production quality.</p></div>' +
      '<p style="font-size:12.6px;color:var(--ink-3)">Saved in this browser only. It is not submitted, not shared with your group, and not visible to the lecturer — copy it out when you are done.</p>';

    function sync() {
      var done = 0;
      Array.prototype.forEach.call(wrap.querySelectorAll('textarea'), function (t) {
        if (state[t.dataset.k]) t.value = state[t.dataset.k];
        if (t.value.trim().length > 25) done++;
      });
      var n = wrap.querySelector('#p4phScore');
      if (n) n.innerHTML = done + ' / 5' + (done === 5 ? ' <small style="color:var(--ok)">ready</small>' : '');
    }
    wrap.addEventListener('input', function (e) {
      if (e.target.tagName !== 'TEXTAREA') return;
      state[e.target.dataset.k] = e.target.value;
      try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (err) { /* private mode */ }
      sync();
    });
    wrap.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      if (b.dataset.act === 'clear') {
        state = {};
        try { localStorage.removeItem(KEY); } catch (err) {}
        Array.prototype.forEach.call(wrap.querySelectorAll('textarea'), function (t) { t.value = ''; });
        sync();
      } else {
        var txt = STEPS.map(function (s) { return s.t + '\n' + (state[s.k] || '(not yet written)') + '\n'; }).join('\n');
        if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { b.textContent = 'Copied'; setTimeout(function () { b.textContent = 'Copy my plan'; }, 1600); });
      }
    });
    sync();
  };
})();

/* ── 12 · glossary list (References page) ───────────────────── */
(function () {
  'use strict';
  var P = window.PHY3201;
  P.widgets['glossary-list'] = function (root) {
    var g = P.glossary || {};
    var keys = Object.keys(g).sort(function (a, b) { return a.localeCompare(b); });
    root.className += ' noglos';
    root.innerHTML =
      '<p style="font-size:13.4px;color:var(--ink-3);margin:0 0 12px">' + keys.length +
      ' terms, auto-linked on first occurrence throughout the studio.</p>' +
      '<div class="tablewrap" style="max-height:520px;overflow:auto"><table><thead><tr>' +
      '<th style="width:220px">Term</th><th>Definition</th></tr></thead><tbody>' +
      keys.map(function (k) {
        return '<tr><td><b style="color:var(--navy)">' + P.esc(k) + '</b></td><td>' + P.esc(g[k]) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  };
})();
