window.PHY3201.pages.map = {
  title: '14-Week Teaching Map',
  navShort: '14-week map',
  accent: 'brand',
  eyebrow: ['Week 1 · Introduction', 'Step 2 of 4'],
  lede: 'The whole semester on one page: 14 teaching weeks, 42 lecture contact hours, 9 topics, 120 hours of total student learning time. Built directly from the approved Rangka Kursus.',
  blocks: [

  { t: 'callout', kind: 'warn', title: 'Read this before you plan anything around these dates',
    x: 'The week numbers below come from the approved course outline and are the *planned* journey. **Always follow the lecturer’s current announcement for confirmed assessment dates and the exact assessed coverage.** Semester calendars shift; this page does not.' },

  { t: 'h2', x: 'The shape of the semester' },
  { t: 'grid', cols: 4, cards: [
    { k: 'Teaching weeks', big: '14' },
    { k: 'Lecture contact', big: '42 h' },
    { k: 'Topics', big: '9' },
    { k: 'Total learning time', big: '120 h' }
  ]},
  { t: 'p', x: 'Three lecture hours per week for fourteen weeks gives the 42 contact hours. The remaining time in the 120-hour student learning total is self-directed: roughly three hours of independent study per teaching week, plus the preparation hours attached to each assessment. That ratio is deliberate — this is a course where the reading and the problem practice have to happen between lectures, not during them.' },

  { t: 'h2', x: 'Week by week' },
  { t: 'table',
    head: ['Week', 'Topic', 'Content', 'Delivery', '~h', 'Assessment'],
    rows: [
      ['1', '[Topic 1 · Crystal Structure](#topic01)', 'Crystal systems, crystal symmetry, crystal lattice, and applications of material structure', 'Lecture · Quiz', '3', 'Continuous assessment begins'],
      ['2', '[Topic 2 · Crystal Analysis](#topic02)', 'Directions and planes, Miller indices, atomic packing factor', 'Lecture', '3', 'Continuous assessment'],
      ['3', '[Topic 2 · Crystal Analysis](#topic02)', 'Surface density, volume density, real crystal structure, and applications in green building and infrastructure', 'Lecture', '3', 'Continuous assessment'],
      ['4', '[Topic 3 · Wave Diffraction](#topic03)', 'Atomic and crystal scattering, reciprocal lattice, Bragg’s law in materials technology applications', 'Lecture', '3', 'PBL / self-reflection report begins'],
      ['5', '[Topic 4 · Amplitude Wave Scattering](#topic04)', 'Fourier analysis, Brillouin zones in cubic lattices, structure factor', 'Lecture', '3', '**Test 1 preparation** (1 h test + 4 h independent study)'],
      ['**6**', '[Topic 5 · Crystal Bonding](#topic05)', 'Noble gas crystal systems, attractive and repulsive energy, van der Waals–London interaction', 'Lecture · Problem-based learning', '3', '**TEST 1 · 15 %**'],
      ['7', '[Topic 5 · Crystal Bonding](#topic05)', 'Types of bonding, ionic crystals, covalent crystals, and applications of crystal bonding in green building materials', 'Lecture · Problem-based learning', '3', 'PBL'],
      ['8', '[Topic 6 · Phonons I](#topic06)', 'Crystal vibrations, monoatomic system, diatomic system', 'Lecture · Quiz', '3', 'Continuous assessment'],
      ['9', '[Topic 6 · Phonons I](#topic06)', 'Phonon dispersion, phonon branches, phonon interactions and thermal management', 'Lecture', '3', 'Test 2 preparation'],
      ['**10**', '[Topic 7 · Phonons II](#topic07)', 'Heat capacity, ideal gas model, harmonic oscillator model', 'Lecture', '3', '**TEST 2 · 15 %**'],
      ['11', '[Topic 7 · Phonons II](#topic07)', 'Einstein model, Debye model, thermal conductivity', 'Lecture · Problem-based learning', '3', 'PBL / self-reflection report'],
      ['12', '[Topic 8 · Free Electrons and Fermi Gas](#topic08)', 'Free electrons in 1-D, free electrons in 3-D, heat capacity of the electron gas', 'Lecture', '3', 'Continuous assessment'],
      ['13', '[Topic 8 · Free Electrons and Fermi Gas](#topic08)', 'Electrical conductivity and applications in sustainable technology, Ohm’s law, motion of free electrons in a magnetic field', 'Lecture · Problem-based learning', '3', 'Final assessment preparation'],
      ['**14**', '[Topic 9 · Band Theory](#topic09)', 'Nearly free electron model in semiconductors, Bloch theory, Kronig–Penney model of energy band structure', 'Lecture', '3', '**PBL submission · 20 %** · final assessment'],
      ['—', '**Total**', '', '', '**42**', '**Final assessment · 40 %**']
    ],
    caption: 'Weeks in bold carry a summative assessment. The sustainability and green-building application hooks in Weeks 3, 7 and 13 are where the [Physics for Planetary Health](#p4ph) project connects to the lecture material.' },

  { t: 'h2', x: 'How the nine topics group' },
  { t: 'topicgrid' },

  { t: 'h2', x: 'The chain the course is actually teaching' },
  { t: 'diagram', id: 'course-chain', label: 'Figure M.1',
    caption: 'Each topic hands a specific, named quantity to the next one. Losing sight of this is how a solid-state course turns into nine disconnected sets of equations.' },
  { t: 'p', x: 'The ordering is not arbitrary and it is worth saying out loud in Week 1. Topics 1 and 2 establish that a crystal has a describable structure. Topics 3 and 4 establish that we can *measure* it — and hand back the lattice parameters the earlier topics assumed. Topic 5 explains why the structure holds together, and produces a spring constant. Topics 6 and 7 hang phonons on those springs and get thermal behaviour. Topic 8 lets electrons move and gets electrical behaviour, but fails in a specific and informative way. Topic 9 repairs the failure by putting the lattice back in, and lands on the band gap — the number that makes semiconductor technology possible.' },

  { t: 'h2', x: 'What to do between lectures' },
  { t: 'grid', cols: 3, cards: [
    { k: 'Every week', h: 'Read one section', x: 'Each topic page ends with a **Where to read more** panel mapping that week’s content to specific chapters and sections in the five prescribed books. Read one, not all five — they say the same things at different levels.' },
    { k: 'Every week', h: 'Work three questions', x: 'The [Practice Hub](#practice) is filterable by topic and by level. Do one Foundation, one Connect and one Materials Challenge. Three questions understood beats twenty skimmed.' },
    { k: 'Every fortnight', h: 'Advance the PBL project', x: 'The [P4PH](#p4ph) project runs from Week 2 to Week 14. It is 20 % of the mark and it cannot be assembled in the last fortnight — the scientific checkpoint deliberately blocks that.' }
  ]},

  { t: 'callout', kind: 'key', title: 'One habit worth forming now',
    x: 'After every lecture, write down in one sentence what quantity that lecture handed to the next topic. By Week 14 you will have the whole chain in your own words, and the final assessment is largely a test of whether you can walk along it in both directions.' }
  ]
};
