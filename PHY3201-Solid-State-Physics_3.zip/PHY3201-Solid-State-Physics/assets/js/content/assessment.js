window.PHY3201.pages.assessment = {
  title: 'Assessment Hub',
  navShort: 'Assessment hub',
  accent: 'brand',
  eyebrow: ['Week 1 · Introduction', 'Step 3 of 4'],
  lede: 'Where the marks come from, what each Course Learning Outcome actually asks of you, and how to revise so that the effort lands where it is assessed.',
  blocks: [

  { t: 'callout', kind: 'warn', title: 'Authoritative source',
    x: 'The weightings on this page follow the approved **Assessment Plan and CAP/COPO mapping for Semester 1, 2026/2027**. Week numbers are the planned journey — confirm dates and coverage against the lecturer’s current announcement.' },

  { t: 'h2', x: 'Where your marks come from' },
  { t: 'grid', cols: 3, cards: [
    { k: 'Week 6 · Summative', big: '15 %', h: 'Test 1', x: 'Core concepts and reasoning from Topics 1–4. Assesses CLO1 at C1–C4.' },
    { k: 'Week 10 · Summative', big: '15 %', h: 'Test 2', x: 'Building on Topics 5–7. Assesses CLO1 and CLO2 at C4 and CTPS.' },
    { k: 'Weeks 2–13 · Formative', big: '10 %', h: 'Continuous assessment', x: 'Short tasks that keep the practice going through the semester. CLO1 at C1–C3.' },
    { k: 'Weeks 2–14 · Formative', big: '20 %', h: 'PBL — Physics for Planetary Health', x: 'The authentic assessment. Assesses CLO3 at A3 and lifelong-learning level. [Open the P4PH Studio →](#p4ph)' },
    { k: 'End of semester · Summative', big: '40 %', h: 'Final assessment', x: 'Comprehensive: conceptual understanding, calculation and explanation across all nine topics, at C1–C4.' },
    { k: 'Split', big: '60 / 40', h: 'Coursework and final', x: 'Coursework 60 % (Test 1 + Test 2 + continuous + PBL) and final assessment 40 %.' }
  ]},

  { t: 'h2', x: 'Course Learning Outcomes and their programme mapping' },
  { t: 'table',
    head: ['CLO', 'Statement', 'Level', 'Maps to', '~Weight'],
    rows: [
      ['**CLO1**', 'Describe material properties based on the fundamental concepts of atomic arrangement and crystal bonding', 'C4 · Analyse', 'PO1 — Knowledge (C)', '60 %'],
      ['**CLO2**', 'Relate crystal structure to the properties of materials', 'CTPS · Critical thinking and problem solving', 'PO3 — CTPS', '20 %'],
      ['**CLO3**', 'Explain the fundamental concepts and technologies based on solid state physics', 'A3 · Valuing · LL · Lifelong learning', 'PO7 — Lifelong learning', '20 %']
    ],
    caption: 'Every assessment on this page carries at least one CLO. Note that CLO3 is carried almost entirely by the PBL project — which is why that project is not optional decoration.' },
  { t: 'table',
    head: ['Assessment', 'Type', 'Week', '~PO1 (C)', '~PO3 (CTPS)', '~PO7 (LL)', '~Total', 'CLO · level'],
    rows: [
      ['Test 1', 'Summative', '6', '10', '5', '—', '15', 'CLO1 · C1–C4'],
      ['Test 2', 'Summative', '10', '10', '5', '—', '15', 'CLO1, CLO2 · C4, CTPS'],
      ['Continuous assessment', 'Formative', '2–13', '10', '—', '—', '10', 'CLO1 · C1–C3'],
      ['PBL (LL)', 'Formative', '2–14', '—', '—', '20', '20', 'CLO3 · A3, LL'],
      ['Final assessment', 'Summative', 'End', '30', '10', '—', '40', 'C1–C4'],
      ['**Grand total**', '', '', '**60**', '**20**', '**20**', '**100**', '']
    ],
    caption: 'The CAP/COPO mapping, reproduced from the approved assessment plan. The three programme-outcome columns are what the faculty reports on — which is why the balance of question types in the papers is not arbitrary.' },

  { t: 'h2', x: 'What each question level is really asking' },
  { t: 'grid', cols: 3, cards: [
    { k: '🟢 Foundation · C1–C2', h: 'Do you know it?', x: 'Recognise the notation, recall the model, choose the right relation, perform a direct calculation. **Ask yourself:** what is given, and which relation applies?' },
    { k: '🟠 Connect · C3–C4', h: 'Can you explain why?', x: 'Explain why a quantity changes, and connect equation → mechanism → property. **Ask yourself:** what physically causes this trend?' },
    { k: '🔵 Materials challenge · C4–C5', h: 'Can you judge it?', x: 'Interpret evidence about an unfamiliar material and reach a justified, appropriately cautious conclusion. **Ask yourself:** what can I conclude — and what can I *not* conclude?' }
  ]},
  { t: 'callout', kind: 'key', title: 'The shape of a strong PHY3201 answer',
    x: '**Identify the model → apply the physics correctly → interpret the result → connect it to the material → state the limitation.** Five moves. Most answers that lose marks have done two or three of them and stopped. An answer that produces a correct number and says nothing about what it means has done the easy half of the work.' },

  { t: 'h2', x: 'Where marks are actually lost' },
  { t: 'table',
    head: ['Mistake', 'What it looks like', 'The fix'],
    rows: [
      ['**Notation slips**', '[uvw] written for (hkl); θ used where 2θ was measured', 'Read the bracket. Halve the diffractometer angle. Both take two seconds and cost whole questions.'],
      ['**Equation with no stated assumption**', 'Using d = a/√(h²+k²+l²) on a tetragonal crystal', 'Name the model every time: *cubic only*, *harmonic*, *free-electron*, *single-carrier*. Examiners award marks for this explicitly.'],
      ['**Number with no interpretation**', '“APF = 0.68.” Full stop.', 'Add one sentence: what does 0.68 tell you about this material, and what does it not tell you?'],
      ['**Over-claiming**', '“One XRD peak matched, so the phase is identified”', 'A single result rarely establishes complete material behaviour. Say what further evidence would be needed.'],
      ['**Mixing incompatible models**', 'Combining a Drude relaxation time with a Fermi-surface argument without comment', 'You may combine them — but say why the combination is legitimate.'],
      ['**Memorising without connecting**', 'Reciting the Debye T³ law with no idea where the T³ comes from', 'Most PHY3201 questions test the *chain* from structure to property, not the endpoints.']
    ]},

  { t: 'h2', x: 'The PBL project at a glance' },
  { t: 'p', x: 'The Physics for Planetary Health project carries the whole of CLO3 and 20 % of the course mark. It runs from Week 2 to Week 14 and cannot be assembled at the end — the scientific checkpoint in Stage 3 is there specifically to stop a video being produced around a misconception.' },
  { t: 'table',
    head: ['Component', '~Weight', 'What is being assessed'],
    rows: [
      ['Solid-state physics accuracy and reasoning', '5 %', 'Is the physics correct, and is the chain from structure to property explicit?'],
      ['Planetary Health analysis', '4 %', 'Is the problem real, specific and quantified?'],
      ['Public science communication', '3 %', 'Would a non-physicist understand it without being misled?'],
      ['Evidence and responsible claims', '2 %', 'Are sources credible and traceable, and are the claims proportionate to them?'],
      ['Public engagement', '1 %', 'Was genuine communication attempted, and was the response learned from?'],
      ['Individual micro-viva', '3 %', 'Can *each* member explain the physics unscripted?'],
      ['Individual reflection', '2 %', 'What changed in your understanding, and what would you do differently?'],
      ['**Total**', '**20 %**', '']
    ],
    caption: 'Note that 5 of the 20 marks are individual (micro-viva plus reflection). A group cannot carry a member who has not understood the physics. [Open the full P4PH Studio →](#p4ph)' },

  { t: 'h2', x: 'How to revise' },
  { t: 'grid', cols: 4, cards: [
    { k: '01', h: 'Diagnose, do not reread', x: 'Work a question first. Only go back to the topic page for the specific thing you could not do. Rereading from Topic 1 feels productive and is not.', href: '#practice' },
    { k: '02', h: 'Change a parameter', x: 'Use the explorers on each topic page. If you cannot predict which way a curve moves before you drag the slider, you do not yet understand the relationship.', href: '#topic01' },
    { k: '03', h: 'Climb the levels', x: 'Foundation → Connect → Materials Challenge, in that order, on the same topic. Do not do twenty Foundation questions and call it revision.', href: '#practice' },
    { k: '04', h: 'Walk the chain out loud', x: 'Pick a material — silicon, copper, diamond — and talk through all nine topics for it without notes. Gaps in the chain are exactly where the final assessment will find you.', href: '#map' }
  ]},

  { t: 'h2', x: 'Final revision: the whole-course chain' },
  { t: 'diagram', id: 'course-chain', label: 'Figure A.1',
    caption: 'If you can walk this chain for a real material, with equations and evidence, using correct notation and stating your assumptions — you are doing what this course assesses.' },
  { t: 'callout', kind: 'key', title: 'The question behind every question',
    x: 'Can you explain not only *what* happens, but *why* — and say honestly what your reasoning does not establish? Every assessment in PHY3201 is evidence about whether you can move from structure → physical mechanism → property → material behaviour, and stop at the point where the evidence stops.' }
  ]
};
