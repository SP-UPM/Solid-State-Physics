window.PHY3201.pages.topic03 = {
  title: 'Wave Diffraction',
  navShort: 'Wave Diffraction',
  accent: 'diffraction',
  hours: '3 lecture hours',
  weeks: 'Week 4',
  question: 'How can waves reveal a structure we cannot see?',
  eyebrow: ['Topic 03', '3 lecture hours', 'CLO1 · C4'],
  lede: 'Atomic and crystal scattering · reciprocal lattice · Bragg’s law. Topics 1 and 2 asserted that atoms sit on a lattice. This topic is how we know.',
  blocks: [

  { t: 'callout', kind: 'key', title: 'What you should be able to do by the end of this topic',
    x: 'Explain the physical process of X-ray scattering by atoms and crystals, and how interference of the scattered waves leads to Bragg’s law and to diffraction patterns · describe the operation of an X-ray diffractometer and the diffraction methods used for crystal structure analysis.' },

  { t: 'h2', x: 'Start here' },
  { t: 'p', x: 'An atom is about 0.1 nm across; the spacing between lattice planes is a few tenths of a nanometre. Visible light has a wavelength of 400–700 nm — three orders of magnitude too long. You cannot see atoms with light for the same reason you cannot feel the grain of sandpaper through a boxing glove.' },
  { t: 'p', x: 'So we use a probe whose wavelength matches the length scale we want to resolve. X-rays with λ ≈ 0.1 nm do exactly that. What comes back is not an image — it is an **interference pattern**, and the whole skill of this topic is learning to read structural information out of it.' },
  { t: 'table',
    head: ['Probe', '~Typical λ', 'Scatters from', 'Best for'],
    rows: [
      ['X-rays', '0.05–0.25 nm', 'The electron cloud', 'Routine structure and phase identification; weak for hydrogen'],
      ['Neutrons', '0.1–0.5 nm', 'The nucleus, and magnetic moments', 'Light elements, isotopes, magnetic order, phonons (Topic 6)'],
      ['Electrons', '0.001–0.01 nm', 'The electrostatic potential', 'Thin films and surfaces — they interact strongly and do not penetrate far']
    ],
    caption: 'Cu Kα, λ = 0.15406 nm, is the laboratory workhorse and the default in every worked example below.' },

  { t: 'h2', x: '1 · What actually scatters' },
  { t: 'p', x: 'An incoming X-ray is an oscillating electromagnetic field. It drives the electrons in an atom into oscillation, and an accelerating charge radiates. Each atom therefore becomes a **secondary source** emitting at the same frequency — this is elastic (Thomson) scattering, and the wavelength is unchanged.' },
  { t: 'diagram', id: 'atomic-scattering', label: 'Figure 3.1',
    caption: 'A single atom scattering. Because the electron cloud has a size comparable to λ, waves from different parts of the same atom fall progressively out of step as the scattering angle grows. That decaying envelope is the atomic form factor f.' },
  { t: 'callout', kind: 'note', title: 'Two consequences worth remembering',
    x: '**(i)** Scattering strength scales roughly with atomic number Z, because heavier atoms carry more electrons. Lead scatters strongly; hydrogen is nearly invisible to X-rays, which is why neutron diffraction exists. **(ii)** The form factor f falls with angle, so intensities decay at high 2θ. Any real powder pattern gets weaker towards the right-hand side, and that decay is physics, not a fault in the instrument.' },

  { t: 'h2', x: '2 · Bragg’s law' },
  { t: 'p', x: 'W. L. Bragg\'s 1912 argument is disarmingly simple, and it is worth being able to reconstruct it rather than quote it. Treat the crystal as a stack of parallel planes, each partially reflecting. Two rays reflect from adjacent planes. The lower one travels further. Work out how much further.' },
  { t: 'diagram', id: 'bragg-mechanism', label: 'Figure 3.2',
    caption: 'The geometry. The extra path is d sin θ on the way in and d sin θ on the way out, giving 2d sin θ in total. Constructive interference requires that to be a whole number of wavelengths.' },
  { t: 'eq', x: 'n λ  =  2 d sin θ',
    note: 'n is the order of reflection (an integer), λ the wavelength, d the interplanar spacing, and **θ the angle between the incident beam and the plane** — not the normal, and not the detector reading.' },
  { t: 'h3', x: 'What the law does and does not tell you' },
  { t: 'ul', items: [
    '**It is a necessary condition, not a sufficient one.** A reflection that satisfies Bragg’s law can still have zero intensity if the atoms within the unit cell cancel. That is the structure factor, and it is Topic 4.',
    '**Since sin θ ≤ 1, we need λ ≤ 2d.** With Cu Kα at 0.15406 nm the smallest resolvable spacing is 0.077 nm. Use too long a wavelength and whole families of planes become unobservable.',
    '**The nth-order reflection from (hkl) is arithmetically identical to the first-order reflection from (nh nk nl).** So we set n = 1 always and let the indices do the work: the "second order from (111)" is simply (222).'
  ]},
  { t: 'diagram', id: 'theta-vs-2theta', label: 'Figure 3.3',
    caption: 'θ, 2θ, and the number your diffractometer actually prints. This is the single most common numerical error in the course.' },
  { t: 'error',
    claim: '"The peak is at 43.3°, so sin θ = sin 43.3°."',
    why: 'A diffractometer reports **2θ**, the angle between the incident beam direction and the detector. Bragg’s law needs **θ**. A peak listed at 2θ = 43.3° means θ = 21.65°. Substituting 43.3° gives a d-spacing wrong by roughly a factor of two, and every quantity derived from it — lattice parameter, phase identification, strain — is then wrong as well. Halve it before you do anything else.' },
  { t: 'calc',
    title: 'From a measured peak to a lattice parameter — copper',
    known: 'Cu Kα radiation, λ = 0.15406 nm.\nThe first strong peak of an FCC metal appears at 2θ = 43.32°.\nFor FCC the first allowed reflection is (111).',
    find: 'The interplanar spacing d and the lattice parameter a',
    equation: 'θ = 2θ / 2\nd = λ / (2 sin θ)          [Bragg, with n = 1]\na = d √(h² + k² + l²)      [cubic]',
    substitution: 'θ  = 43.32° / 2 = 21.66°\nsin θ = 0.36910\nd  = 0.15406 / (2 × 0.36910) = 0.20870 nm\na  = 0.20870 × √3 = 0.20870 × 1.73205',
    answer: 'd(111) = 0.2087 nm,   a = 0.3615 nm',
    meaning: 'The accepted lattice parameter of copper is 0.3615 nm. One peak position, read correctly, has given the cell edge to four significant figures. This is why XRD is the standard first measurement on any new crystalline sample.' },
  { t: 'widget', id: 'bragg-explorer', title: 'Bragg law and simulated powder pattern' },

  { t: 'h2', x: '3 · The reciprocal lattice' },
  { t: 'p', x: 'Bragg’s law works, but it is awkward: it treats planes as mirrors, which they are not, and it hides the three-dimensional geometry. The reciprocal lattice is the reformulation that makes diffraction natural rather than clever.' },
  { t: 'eq', x: 'b₁ = 2π (a₂ × a₃)/V        b₂ = 2π (a₃ × a₁)/V        b₃ = 2π (a₁ × a₂)/V\n\nwhere V = a₁ · (a₂ × a₃) is the primitive cell volume.\n\nKey property:      bᵢ · aⱼ  =  2π δᵢⱼ',
    note: 'Every reciprocal lattice vector G = h b₁ + k b₂ + l b₃ satisfies exp(iG·R) = 1 for every direct lattice vector R. G is perpendicular to the plane family (hkl), and its magnitude is |G| = 2π/d_hkl.' },
  { t: 'diagram', id: 'reciprocal-bridge', label: 'Figure 3.4',
    caption: 'Real and reciprocal space are inverse pictures of the same crystal. A large real-space spacing becomes a short reciprocal vector, and vice versa.' },
  { t: 'callout', kind: 'key', title: 'The inversion is the whole point',
    x: 'Widely spaced planes → small |G| → diffraction at *low* angle. Closely spaced planes → large |G| → diffraction at *high* angle. This is why the left-hand end of a powder pattern carries the large-scale structure and the right-hand end carries the fine detail — and why a poorly resolved high-angle region means you have lost your precision on the lattice parameter.' },
  { t: 'table',
    head: ['Direct lattice', 'Its reciprocal lattice'],
    rows: [
      ['Simple cubic, parameter a', 'Simple cubic, parameter 2π/a'],
      ['Body-centred cubic, parameter a', '**Face-centred cubic**, parameter 4π/a'],
      ['Face-centred cubic, parameter a', '**Body-centred cubic**, parameter 4π/a']
    ],
    caption: 'BCC and FCC are reciprocal to each other. This is not a coincidence and it becomes important in Topic 4, where the shape of the Brillouin zone follows from the reciprocal lattice, not the direct one.' },

  { t: 'h2', x: '4 · The Laue condition and the Ewald construction' },
  { t: 'p', x: 'Write the incident wavevector as k and the scattered one as k′. Elastic scattering means |k| = |k′| = 2π/λ. The diffraction condition is then simply:' },
  { t: 'eq', x: 'Δk  =  k′ − k  =  G\n\nequivalently:      2 k · G  +  G²  =  0',
    note: 'This is the **Laue condition**. It is completely equivalent to Bragg’s law — just written as a vector equation, which makes the three-dimensional bookkeeping automatic instead of manual.' },
  { t: 'diagram', id: 'ewald', label: 'Figure 3.5',
    caption: 'The Ewald construction turns the Laue condition into a picture: a reflection occurs only when a reciprocal-lattice point falls exactly on a sphere of radius |k|.' },
  { t: 'p', x: 'The Ewald picture explains the experimental methods immediately. A stationary single crystal in a monochromatic beam gives almost nothing, because generically no reciprocal-lattice point sits on the sphere. To get data you must either rotate the crystal (sweeping points through the sphere), use a range of wavelengths so the sphere becomes a shell (the Laue method), or use a **powder** — millions of randomly oriented crystallites, so that statistically some grain is always correctly aligned for every reflection at once.' },

  { t: 'h2', x: '5 · Reading a powder pattern' },
  { t: 'table',
    head: ['Feature of the peak', 'What it is controlled by', 'What you may conclude'],
    rows: [
      ['**Position** (2θ)', 'Interplanar spacing d, via Bragg', 'Lattice parameter; phase identity; strain if it shifts'],
      ['**Intensity**', 'Structure factor |F|², multiplicity, form factor, Lorentz–polarisation', 'Which atoms sit where in the cell; preferred orientation'],
      ['**Absence**', 'Structure factor = 0', 'Lattice centring — see Topic 4'],
      ['**Width**', 'Crystallite size, microstrain, instrument', 'Nanocrystallinity via the Scherrer relation; defect content'],
      ['**Background**', 'Amorphous content, fluorescence, air scatter', 'Whether the sample is fully crystalline at all']
    ]},
  { t: 'callout', kind: 'warn', title: 'Peak width: use Scherrer carefully',
    x: 'The Scherrer equation D = Kλ/(β cos θ) converts peak broadening into a crystallite size, with K ≈ 0.9. It is widely used and widely abused. It assumes broadening comes from size *alone*, so you must first subtract the instrumental width, and it becomes unreliable above roughly 100 nm where the size contribution is smaller than the instrument resolution. Microstrain broadens peaks too, and with a different angular dependence — which is how Williamson–Hall analysis separates the two.' },
  { t: 'error',
    claim: '"One peak matched the reference, so the phase is identified."',
    why: 'Different phases routinely have reflections at similar d-spacings — the pattern is only distinctive as a *set*. Reliable identification needs several peak positions **and** their relative intensities to match, and it needs to be consistent with what you know about the sample\'s composition and history. A single matching line is a hypothesis, not a result. This is exactly the kind of over-claim that Part (e) of the structured questions asks you to catch.' },

  { t: 'h2', x: 'Check yourself' },
  { t: 'check',
    q: 'At fixed wavelength and order, a diffraction peak shifts to a larger 2θ. What has happened to the d-spacing?',
    options: ['It increased', 'It decreased', 'It is unchanged — only the intensity moved', 'Not enough information'],
    answer: 1,
    why: 'From d = nλ/(2 sin θ): larger 2θ means larger θ, hence larger sin θ, hence smaller d. Physically the planes have moved closer — perhaps from compressive strain, cooling, or a change in composition. Note that the *cause* is not determined by the shift alone.' },
  { t: 'check',
    q: 'Why is a powder sample so much more convenient than a stationary single crystal?',
    options: ['Powders scatter more strongly per unit mass', 'Randomly oriented crystallites guarantee that some grain satisfies each reflection condition simultaneously', 'Powders have larger d-spacings', 'A powder has no structure factor'],
    answer: 1,
    why: 'With millions of orientations present at once, the Ewald sphere always intersects some correctly aligned grain for every accessible reflection. You get the whole pattern in one scan without moving the crystal. The price is that you lose the orientational information a single crystal would have given you.' },

  { t: 'h2', x: 'Exit challenge' },
  { t: 'callout', kind: 'key', title: 'Diagnosing a pattern',
    x: 'A cubic sample measured with Cu Kα (λ = 0.15406 nm) gives its first three peaks at 2θ = 28.44°, 47.30° and 56.12°. **(a)** Calculate d for each. **(b)** Assuming the first is (111), determine a and predict where (220) and (311) should fall. **(c)** Compare with the measured values and identify the material. **(d)** The peaks are noticeably broader than the instrument standard. Give two physically distinct explanations, and state what further measurement would distinguish them.' },

  { t: 'read', items: [
    { book: 'Kittel, Ch. 2', where: 'Diffraction of Waves by Crystals · **The Bragg Law** · Scattered Wave Amplitude · Reciprocal Lattice Vectors · Diffraction Conditions · Laue Equations · Atomic Form Factor. Kittel Ch. 2 is the single best match of any prescribed book to any topic in this course — it covers Topics 3 and 4 together.' },
    { book: 'Hofmann, 1.3.1', where: '1.3.1.1 Bragg Theory · 1.3.1.3 General Diffraction Theory · 1.3.1.4 The Reciprocal Lattice · 1.3.1.5 The Meaning of the Reciprocal Lattice · 1.3.1.7 The Ewald Construction · 1.3.1.8 Relation Between Bragg and Laue Theory. The clearest numbered treatment of the Bragg–Laue equivalence.' },
    { book: 'Ashcroft & Mermin, Ch. 5 and 6', where: 'Ch. 5 The Reciprocal Lattice; Ch. 6 Determination of Crystal Structures by X-Ray Diffraction — both the Bragg and von Laue formulations, the Ewald construction and the experimental methods.' },
    { book: 'Snoke, 1.5 and 3.2', where: '1.5 X-ray Scattering; 3.2 Neutron Scattering — the latter is worth a look now, because Topic 6 uses it to measure phonon dispersion.' }
  ]}
  ]
};
