window.PHY3201.pages.p4ph = {
  title: 'Physics for Planetary Health',
  navShort: 'P4PH project',
  accent: 'brand',
  eyebrow: ['Week 1 · Introduction', 'Step 4 of 4', 'PBL · 20 %'],
  lede: 'Use solid state physics to explain a real material or technology to a public audience — and to say honestly what your explanation does not establish. Runs Weeks 2 to 14. Carries CLO3 and 20 % of the course mark.',
  blocks: [

  { t: 'h2', x: 'Your role' },
  { t: 'callout', kind: 'key', title: 'Materials physicist and science communicator',
    x: 'Your task is **not** to promote a technology. It is to explain how solid state physics connects a specific material to a real planetary-health challenge, and to communicate that responsibly — including the parts that do not flatter the technology. A polished video that overstates its evidence scores worse than a rough one that is honest.' },
  { t: 'grid', cols: 4, cards: [
    { k: '🌍 Planet', h: 'What challenge exists?', x: 'Name it specifically and attach a number to it.' },
    { k: '👥 People', h: 'Why does it matter?', x: 'Who is affected, and how?' },
    { k: '⚛️ Physics', h: 'What PHY3201 physics explains it?', x: 'At least two concepts, and the link between them.' },
    { k: '⚖️ Trade-off', h: 'What limitation remains?', x: 'A project with no trade-off has not been thought through.' }
  ]},

  { t: 'h2', x: 'The minimum physics requirement' },
  { t: 'callout', kind: 'warn', title: 'Two concepts, explicitly connected',
    x: 'You must use **at least two strongly relevant PHY3201 concepts** and make the connection between them explicit. Naming Topic numbers is not enough — name the actual physics. "We used Topic 5 and Topic 7" earns nothing; "the stiff sp³ bonding of Topic 5 gives the high phonon group velocity that Topic 7 needs for a large κ" earns the marks.' },

  { t: 'h2', x: 'The five steps before you film anything' },
  { t: 'p', x: 'This is the sequence that decides whether the project works. Every group that produces a weak video skipped step 4.' },
  { t: 'widget', id: 'p4ph-planner', title: 'Physics Map — the five pre-video steps' },
  { t: 'callout', kind: 'stop', title: 'Scientific checkpoint',
    x: 'Complete steps 1–5 and obtain lecturer or tutor scientific approval **before full video production**. Approval is not the same as perfection — it means the scientific backbone is sound enough that you will not build a public video around a major misconception.' },

  { t: 'h2', x: 'The reasoning chain a strong project builds' },
  { t: 'eq', x: 'Planetary-health challenge  →  why it matters  →  material or technology\n     →  PHY3201 physics  →  material property  →  device performance\n            →  planetary-health benefit  →  trade-off',
    note: 'Every arrow must be a physics statement or a piece of sourced evidence. An arrow that is only an association — "solar panels are made of silicon, and silicon is a semiconductor, so solar is green" — is where projects lose most of their marks.' },
  { t: 'h3', x: 'A worked example of the chain, done properly' },
  { t: 'table',
    head: ['Link', 'Weak version', 'Strong version'],
    rows: [
      ['Problem', '"Climate change"', '"Lighting still accounts for a large share of building electricity demand; the US Department of Energy reports installed A19 LED lamps at around 92 lm/W in 2022 while laboratory packages exceed 200 lm/W."'],
      ['Material', '"LEDs"', '"InGaN quantum wells on GaN, with the indium fraction setting the emission wavelength."'],
      ['Physics 1', '"Band theory"', '"The direct band gap of GaN (3.39–3.44 eV at 300 K) means the conduction minimum and valence maximum share the same k, so radiative recombination conserves crystal momentum without a phonon."'],
      ['Physics 2', '"Crystal structure"', '"Alloying with indium narrows the gap continuously, tuning emission across the visible range — the same nearly-free-electron gap argument from Topic 9, applied to a composition variable."'],
      ['Link between them', '(missing)', '"Composition changes the lattice parameter, which changes the periodic potential, which changes the gap — Topic 1 and Topic 9 are the same argument at two ends."'],
      ['Evidence', '"LEDs are very efficient"', '"Cree LED, 31 March 2026: J Series 3030S packages up to 220 lm/W at 65 mA."'],
      ['Trade-off', '(missing)', '"The green gap is still unsolved: a 2025 result reports 65 % peak EQE at 520 nm as *progress*, and green droop has been decomposed as ~49 % Auger–Meitner, 35 % polarisation, 16 % thermal. And package efficacy is not installed efficacy — 220 lm/W in the lab, 92 lm/W in the fitting."']
    ],
    caption: 'The right-hand column is not longer because it is padded. It is longer because each link is doing work.' },

  { t: 'h2', x: 'Choosing a challenge' },
  { t: 'grid', cols: 4, cards: [
    { k: '☀️', h: 'Solar cells', x: 'light → carriers → electrical energy. Band gap, absorption, the Shockley–Queisser limit. **Topic 9.**' },
    { k: '💡', h: 'LEDs and lighting', x: 'bands → recombination → light. Direct vs indirect gap, alloy tuning. **Topics 5, 9.**' },
    { k: '🌡️', h: 'Electronics heat', x: 'phonons → κ → device reliability. Mean free path, umklapp, nanoscale confinement. **Topics 6, 7.**' },
    { k: '🔋', h: 'Batteries and storage', x: 'structure → ion transport → capacity. LiCoO₂ is layered R3̄m; LiFePO₄ is olivine Pnma with 1-D Li channels. **Topics 1, 2, 5.**' },
    { k: '🏢', h: 'Smart windows', x: 'electronic and optical response. WO₃ electrochromics; VO₂ metal–insulator transition at ≈68 °C. **Topics 8, 9.**' },
    { k: '♻️', h: 'E-waste and recovery', x: 'material properties → recyclability → resource efficiency. 62 Mt generated in 2022, 22.3 % formally recycled. **Topics 2, 5.**' },
    { k: '💧', h: 'Water-quality sensing', x: 'material response → detection. Surface states, planar density, defect chemistry. **Topics 2, 9.**' },
    { k: '🌡️', h: 'Thermoelectrics', x: 'ZT = S²σT/κ. Phonon-glass electron-crystal, and the anharmonicity alternative. **Topic 7.**' }
  ]},

  { t: 'h2', x: 'Verified figures you may use' },
  { t: 'callout', kind: 'key', title: 'These were checked against primary sources on 1 September 2026',
    x: 'Every number below was retrieved from the source named. Cite the source and the date, not this page. If you find a different number elsewhere, do not average them — work out which measurement was actually made, and of what.' },
  { t: 'table',
    head: ['Figure', 'Value', 'Source and date'],
    rows: [
      ['Record mono-Si solar cell', '28.1 %', 'Fraunhofer ISE *Photovoltaics Report*, 14 July 2026'],
      ['Record perovskite/Si tandem', '35.2 %', 'Fraunhofer ISE, 14 July 2026'],
      ['Commercial c-Si module', '18.9–24.8 %, weighted average 22.7 %', 'Fraunhofer ISE, Q4 2024 data'],
      ['Shockley–Queisser limit', '30 % at E_g = 1.1 eV, blackbody 6000 K / 300 K', 'Shockley & Queisser, *J. Appl. Phys.* **32**, 510 (1961)'],
      ['Commercial white LED package', 'up to 220 lm/W at 65 mA', 'Cree LED J Series 3030S, 31 March 2026'],
      ['Installed A19 LED lamp', '≈92 lm/W (90th percentile)', 'US DOE, *2022 SSL R&D Opportunities*'],
      ['GaN band gap at 300 K', '3.39–3.44 eV', 'Ioffe NSM Archive (Bougrov 2001, Monemar 1974)'],
      ['Green InGaN mini-LED', 'peak EQE 65.0 %, WPE 60.1 % at 520 nm', '*Applied Physics Express*, 1 August 2025'],
      ['SnSe single crystal ZT', '2.6 ± 0.3 at 923 K', 'Zhao *et al.*, *Nature* **508**, 373 (2014)'],
      ['Isotopically pure ¹²C diamond', '~50 % higher thermal diffusivity than natural diamond, at 300 K', 'Anthony *et al.*, *Phys. Rev. B* **42**, 1104 (1990)'],
      ['CVD diamond heat spreader', '1000–2200 W m⁻¹ K⁻¹', 'Element Six product data'],
      ['VO₂ metal–insulator transition', '≈68 °C (68.1 °C undoped, 43.0 °C W-doped)', '*Light: Sci. Appl.*, 18 Sep 2024; *J. Korean Ceram. Soc.*, 4 Mar 2025'],
      ['SageGlass electrochromic deployment', '1700+ installations, 27 countries', 'SageGlass (Saint-Gobain) company site'],
      ['Solid-state EV batteries', '**Not in series production**; all-solid-state at prototype stage. Semi-solid-state is commercial but needs elevated temperature.', 'IEA *Global EV Outlook 2026*, 20 May 2026'],
      ['LFP share of EV batteries', '>55 % of those deployed globally in 2025', 'IEA *Global EV Outlook 2026*'],
      ['Global e-waste', '62 Mt generated in 2022; 22.3 % documented as collected and recycled', 'Global E-waste Monitor 2024 (ITU/UNITAR), 20 March 2024'],
      ['Malaysian front-end wafer fabs', 'X-FAB Sarawak (8-inch, 350/180/130 nm); SilTerra Kulim (40 000 wafers/month)', 'X-FAB and SilTerra company sites']
    ]},
  { t: 'callout', kind: 'stop', title: 'Do not claim these — they could not be verified',
    x: '**"303 lm/W" as the white-LED lab record** (traces to a 2014 press release that no longer exists). **"InN has a 1.9 eV gap"** — obsolete, and still printed by the Ioffe archive; the modern ~0.7 eV value also could not be sourced. **Any CdTe record cell efficiency** — sources conflict. **"33.7 % at 1.34 eV" for Shockley–Queisser** — that is a later AM1.5G recalculation, not the 1961 result; never present the two as the same calculation. **"41 000 W/m/K for isotopically pure diamond"** — that is a 104 K value, not room temperature. **"Commercial Bi₂Te₃ modules have ZT ≈ 1"** — universally repeated, never verified. **"Malaysia has 13 % of the global semiconductor market"** — false; any Malaysian share figure refers to back-end assembly, test and packaging, and even that number needs the National Semiconductor Strategy as its citation. **"VO₂ smart windows are commercially available"** — no verified deployment found.' },

  { t: 'h2', x: 'The seven stages' },
  { t: 'table',
    head: ['~Stage', 'What happens', 'When', 'Output'],
    rows: [
      ['1', 'Choose the challenge and the technology', 'Week 2–3', 'Team, challenge, named material'],
      ['2', 'Build the Physics Map — the five steps above', 'Week 4–6', 'One-page scientific backbone'],
      ['3', '**Scientific approval gate**', 'Week 7–8', 'Lecturer/tutor sign-off — required before filming'],
      ['4', 'Storyboard the 2–3 minute vertical video', 'Week 9–10', 'Six-beat storyboard plus the Physics Moment'],
      ['5', 'Publish and engage', 'Week 11–12', 'Public post, audience response, your physics-based reply'],
      ['6', 'Individual micro-viva', 'Week 13', 'Each member answers 1–2 unscripted questions'],
      ['7', 'Reflection and evidence trail', 'Week 14', 'One page: what changed in your understanding']
    ]},

  { t: 'h2', x: 'Stage 3 · the approval checklist' },
  { t: 'ul', items: [
    'Two strongly relevant PHY3201 concepts are used.',
    'The **connection between the two concepts** is stated explicitly, not implied.',
    'Equations and diagrams use correct symbols, units and stated assumptions.',
    'Material-performance claims are supported by evidence that can be traced.',
    'At least one meaningful limitation or trade-off is included.',
    'Three to five credible sources are listed, each with a date.',
    'Scientific figures are original, properly attributed, or independently verified.',
    'The public message does not exaggerate beyond what the evidence supports.'
  ]},

  { t: 'h2', x: 'Stage 4 · the video' },
  { t: 'table',
    head: ['~Time', 'Beat', 'What it does'],
    rows: [
      ['0–15 s', 'Hook', 'One arresting fact or image. No jargon yet.'],
      ['15–40 s', 'Why should we care?', 'The planetary-health stake, with a number.'],
      ['40–120 s', '**The physics**', 'The largest block. This is where the marks are.'],
      ['120–150 s', 'Material / technology', 'How the physics becomes a device.'],
      ['150–170 s', 'Benefit **and trade-off**', 'Both. Not one.'],
      ['170–180 s', 'Public question', 'Something an ordinary viewer can actually answer.']
    ]},
  { t: 'callout', kind: 'warn', title: 'The required original Physics Moment',
    x: 'Every video must contain one original element that makes the physics *visible*: a student-made animation, a physical model, a simple experiment, a paper demonstration, a hand-drawn graph, or an object analogy with the physics explained. The test is simple — **if you could delete it without changing the explanation, it is decoration, not a Physics Moment.**' },

  { t: 'h2', x: 'Stage 6 · micro-viva practice questions' },
  { t: 'grid', cols: 3, cards: [
    { k: 'Explain', h: 'What does your key equation mean physically?', x: 'Not what the symbols stand for — what the relationship says about the material.' },
    { k: 'Connect', h: 'How are your two PHY3201 concepts related?', x: 'The link, in one sentence, without notes.' },
    { k: 'Defend', h: 'Which claim in your video has the strongest evidence?', x: 'And which has the weakest? Be able to rank them.' },
    { k: 'Limit', h: 'What can your project not conclude?', x: 'The question most groups have never asked themselves.' },
    { k: 'Transfer', h: 'What changes if a material parameter changes?', x: 'Double the Debye temperature, halve the gap — then what?' },
    { k: 'Public', h: 'How would you correct a common misconception?', x: 'Pick one your own audience actually voiced.' }
  ]},

  { t: 'h2', x: 'AI use' },
  { t: 'callout', kind: 'note', title: 'Declare it',
    x: 'AI tools may be used for drafting, translation and editing. They must be declared, and you remain fully responsible for every physics claim. **Verify every number an AI gives you against a primary source before it goes in the video** — the "do not claim" list above exists precisely because plausible-sounding figures circulate widely and several of them are wrong. An unverified number in a public video is a worse outcome than no number at all.' },

  { t: 'h2', x: 'What will be valued' },
  { t: 'grid', cols: 2, cards: [
    { h: 'A project that will score well', x: 'Names a specific material, not a category. Uses two concepts and states the link. Carries one sourced number with a date. Admits one honest trade-off. Every team member can explain the physics unprompted. The Physics Moment cannot be removed without breaking the explanation.' },
    { h: 'A project that will not', x: 'Describes a technology rather than explaining it. Lists topic numbers instead of physics. Quotes an impressive number with no source or date. Presents the technology as having no downside. Has one member who did the physics and three who did the editing.' }
  ]}
  ]
};
