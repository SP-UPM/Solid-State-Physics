window.PHY3201.pages.references = {
  title: 'References and Glossary',
  navShort: 'References and glossary',
  accent: 'brand',
  eyebrow: ['Reference', 'Verified 1 September 2026'],
  lede: 'The five prescribed books, what each is actually good for, three citations in the course outline that need correcting, and the terms auto-linked throughout this studio.',
  blocks: [

  { t: 'h2', x: 'Prescribed references' },
  { t: 'callout', kind: 'warn', title: 'Three of the five citations in the course outline do not match a book that exists',
    x: 'Bibliographic records were checked against library catalogues and publisher pages on 1 September 2026. The corrections below are worth making before the reference list goes to students, because two of the citations as printed cannot be used to find the book.' },
  { t: 'table',
    head: ['As printed in the RK', 'What actually exists', 'Status'],
    rows: [
      ['Kittel, C. (2020). *Introduction to solid state physics* (Global ed.). John Wiley & Sons.', 'Wiley, [2018] © 2018, ISBN **978-1-119-45416-8**, xix + 692 pp., 22 chapters. Catalogues record it as "Global edition, [9th edition]" but the bracket means a cataloguer inferred it; Wiley prints no number, and a chapter-by-chapter comparison shows it is the **8th-edition text** with chapters 14–16 reordered.', '**Do not call it the 9th edition.** Otherwise correct.'],
      ['Ashcroft, N. W., & Mermin, N. D. (2019). *Solid state physics* (2nd ed.). Cengage Learning Asia.', 'There is **no second edition**. The Cengage Asia book is Ashcroft, Mermin & **Wei, D.** (2016), *Solid state physics* (**Revised ed.**), ISBN **978-981-4369-89-3**, xxxiii + 1294 pp., **35 chapters**.', '**Needs correcting.** Also note the Revised Edition renumbers the chapters, so classic chapter numbers will be off.'],
      ['Hofmann, P. (2022). *Solid state physics: An introduction*. Wiley-VCH.', 'Confirmed, and it is the **3rd edition**, July 2022, ISBN 978-3-527-41410-9, 288 pp.', 'Correct — add "3rd ed."'],
      ['Snoke, D. W. (2020). *Solid state physics: Essential concepts*. Cambridge University Press.', 'Confirmed: 2nd edition, 2020, ISBN 9781107191983, 765 pp., 11 chapters.', 'Correct.'],
      ['Lawrence, A. (2019). *Solid state physics*. Larsen and Keller Education.', 'Augusta Lawrence is the **editor**, not the author. ISBN 9781641721479, 286 pp. **No table of contents is available anywhere**; a search of the K10plus union catalogue (~200 million records) returns **zero holdings**; the publisher domain does not resolve in DNS; the price is US$187 for 286 pages.', '**Recommend removing or demoting to "supplementary".** No topic can honestly be mapped to it.']
    ]},

  { t: 'h2', x: 'What each book is actually good for' },
  { t: 'table',
    head: ['Book', 'Best for', 'Weak on', 'Level'],
    rows: [
      ['**Kittel** (Global ed.)', 'Topics 3 and 4 — Chapter 2 is the single best match of any book to any topic here. Also near one-to-one for Topics 8 (Ch. 6) and 9 (Ch. 7).', 'Crystal symmetry and point groups (no section at all); atomic packing fraction and planar/volume density (problems only); the classical ideal-gas heat capacity (no named subheading).', 'Undergraduate — the standard anchor'],
      ['**Hofmann** (3rd ed.)', 'Topic 5 (Ch. 2 entire — the cleanest single-chapter match in the course) and Topic 7 (4.2 with the Einstein and Debye models properly separated). **The only prescribed book with genuine hierarchical section numbering**, so the easiest to cite precisely.', 'No Kronig–Penney model anywhere; thinner than Kittel on cubic Brillouin-zone construction.', 'Undergraduate, shorter and more modern'],
      ['**Ashcroft, Mermin & Wei** (Rev. ed.)', 'Topic 1 crystal symmetry (Ch. 7 is the only proper treatment among the five) and Topic 8 (Ch. 1–3, with section-level detail on Drude and Sommerfeld).', 'Length. Kronig–Penney appears essentially as a problem. Chapter numbering differs from the classic edition.', 'Advanced undergraduate to graduate'],
      ['**Snoke** (2nd ed.)', '**Topic 9** — the strongest of the five. Kronig–Penney has its own numbered section (1.2), plus Bloch\'s theorem (1.3) and "How to Read a Band Diagram" (1.9.1). Also good on neutron scattering (3.2).', '**No coverage of Topics 1, 2 or 5** — no inert-gas crystals, no van der Waals–London calculation, no Madelung constant. It opens with bands rather than structure.', 'Graduate'],
      ['**Lawrence** (2019)', 'Unknown — contents could not be verified.', 'Everything, in the sense that nothing could be confirmed.', 'Unknown']
    ]},

  { t: 'h2', x: 'Reading map by topic' },
  { t: 'table',
    head: ['~#', 'Topic', 'Kittel', 'Hofmann', 'A&M (classic numbering)', 'Snoke'],
    rows: [
      ['1', 'Crystal Structure', 'Ch. 1', '1.1, 1.2', 'Ch. 4, **7**', '1.4 (thin)'],
      ['2', 'Crystal Analysis', 'Ch. 1', '1.3.1.2, 1.2.2', 'Ch. 4, 5, 7', '—'],
      ['3', 'Wave Diffraction', '**Ch. 2**', '1.3.1.1–1.3.1.8', 'Ch. 5, 6', '1.5, 3.2'],
      ['4', 'Amplitude Wave Scattering', '**Ch. 2**', '1.3.1.3, 1.3.1.6, 4.1.2.2', 'Ch. 5, 6', '1.4, 1.5 (thin)'],
      ['5', 'Crystal Bonding', 'Ch. 3, first half only', '**Ch. 2 entire**', 'Ch. 19, 20', '1.11 only — inadequate'],
      ['6', 'Phonons I', 'Ch. 4 + App. C', '4.1.1–4.1.5', 'Ch. 21–24', '3.1, 3.2, 4.1, 4.2, 5.1, 5.4'],
      ['7', 'Phonons II', 'Ch. 5', '**4.2.1–4.2.3, 4.4, 4.5**', 'Ch. 22, 23, 25', '4.9.1–4.9.4, 5.7'],
      ['8', 'Free Electrons and Fermi Gas', '**Ch. 6** + App. D, F', 'Ch. 5 entire + 6.2', '**Ch. 1, 2, 3**', '2.4, 4.9.4, 5.8, 5.10, 2.9'],
      ['9', 'Band Theory', '**Ch. 7**', '6.1, 6.3–6.6', 'Ch. 8, 9, 10', '**1.2, 1.3, 1.6, 1.9.3**']
    ],
    caption: 'Bold = the best source for that topic. **Kittel has no numbered sections** — chapters are numbered, everything below is an unnumbered named subheading, so "Kittel §2.3" does not exist. Cite the chapter and the subheading name.' },
  { t: 'callout', kind: 'stop', title: 'A gap that affects a six-hour topic',
    x: 'Atomic packing fraction, surface (planar) density and volume density — the whole second half of Topic 2 — have **no named coverage in any of the four verifiable books**. They are materials-science conventions rather than physics-text ones; in Kittel they exist only as Chapter 1 problems. The usual fix is **Callister & Rethwisch, *Materials Science and Engineering*, Ch. 3**, or Omar, *Elementary Solid State Physics*. Worth adding to the reference list as a supplementary text.' },

  { t: 'h2', x: 'Data sources used in this studio' },
  { t: 'p', x: 'Time-sensitive figures — anything about a technology, a record efficiency or a market — were verified against a primary source before being used. Textbook constants (lattice parameters, Debye temperatures, cohesive energies, Fermi energies) come from the standard tables in Kittel and are of the kind that do not change.' },
  { t: 'ul', items: [
    'Fraunhofer ISE, *Photovoltaics Report*, 14 July 2026 — solar cell and module efficiencies',
    'Shockley & Queisser, *J. Appl. Phys.* **32**, 510 (1961) — the detailed-balance limit, 30 % at 1.1 eV for a blackbody spectrum',
    'Cree LED, J Series 3030S press release, 31 March 2026 — LED package efficacy',
    'US Department of Energy, *2022 SSL R&D Opportunities* — installed lamp efficacy',
    'Ioffe Institute NSM Archive — GaN band gap, silicon thermal conductivity',
    '*Applied Physics Express*, 1 August 2025 — green InGaN mini-LED EQE',
    'Zhao *et al.*, *Nature* **508**, 373 (2014) — SnSe ZT = 2.6 and the bond-anharmonicity argument',
    'Snyder & Toberer, *Nature Materials* **7**, 105 (2008) — the phonon-glass electron-crystal principle',
    'Anthony *et al.*, *Phys. Rev. B* **42**, 1104 (1990) — isotopically enriched diamond thermal diffusivity',
    'Element Six (De Beers Group) — CVD diamond heat spreader conductivity',
    '*Light: Science & Applications*, 18 September 2024 — VO₂ thermochromic window review',
    'IEA, *Global EV Outlook 2026*, 20 May 2026 — solid-state battery status, LFP share',
    'Global E-waste Monitor 2024 (ITU / UNITAR), 20 March 2024 — 62 Mt, 22.3 % recycled',
    'X-FAB and SilTerra company sites — Malaysian front-end wafer fabrication'
  ]},
  { t: 'callout', kind: 'stop', title: 'Claims deliberately avoided — please preserve this list when editing',
    x: '**"303 lm/W" as the white-LED lab record** (2014 press release, no longer retrievable). **"InN has a 1.9 eV gap"** — obsolete; the Ioffe archive still prints it, and the modern ~0.7 eV value could not be sourced either. **Any CdTe record cell efficiency** — sources conflict between 21.0 % and 23.1 %. **"33.7 % at 1.34 eV" for Shockley–Queisser** — a later AM1.5G recalculation, not the 1961 blackbody result; never present the two as the same calculation. **"29.4 % is the silicon limit"** — unverified. **"41 000 W/m/K for isotopically pure diamond"** — a 104 K value, not 300 K. **"~2200 W/m/K for natural type IIa diamond"** and **"copper 401 W/m/K"** — handbook values, unverified. **"Commercial Bi₂Te₃ modules have ZT ≈ 1"** — universally repeated, never verified. **"Malaysia has 13 % of the global semiconductor market"** — false; any Malaysian share figure refers to back-end assembly, test and packaging, and that number itself needs the National Semiconductor Strategy as its citation. **"Infineon operates a wafer fab at Kulim"** — very likely true, but Infineon\'s own site would not confirm it; X-FAB Sarawak and SilTerra Kulim are the two documented examples. **"VO₂ smart windows are commercially available"** — no verified deployment. **Any statement attributed to the NREL efficiency chart** — the chart is robots-blocked and was never retrieved.' },

  { t: 'h2', x: 'Glossary' },
  { t: 'p', x: 'These sixty terms are auto-linked on their first occurrence in every page of this studio — hover or focus a dotted term to see its definition. The full list is below for revision.' },
  { t: 'widget', id: 'glossary-list', title: 'All 60 terms' },

  { t: 'h2', x: 'Constants used in this studio' },
  { t: 'table',
    head: ['Constant', 'Symbol', '~Value'],
    rows: [
      ['Elementary charge', 'e', '1.602176634 × 10⁻¹⁹ C  (exact)'],
      ['Electron rest mass', 'mₑ', '9.1093837015 × 10⁻³¹ kg'],
      ['Reduced Planck constant', 'ħ', '1.054571817 × 10⁻³⁴ J s'],
      ['Boltzmann constant', 'k_B', '1.380649 × 10⁻²³ J K⁻¹  (exact)'],
      ['Avogadro constant', 'N_A', '6.02214076 × 10²³ mol⁻¹  (exact)'],
      ['Gas constant', 'R = N_A k_B', '8.314 J mol⁻¹ K⁻¹'],
      ['Dulong–Petit value', '3R', '24.94 J mol⁻¹ K⁻¹'],
      ['Lorenz number', 'L = π²k_B²/3e²', '2.44 × 10⁻⁸ W Ω K⁻²'],
      ['Coulomb constant in convenient units', 'e²/4πε₀', '14.3996 eV Å'],
      ['Thermal energy at 300 K', 'k_BT', '0.02585 eV'],
      ['Cu Kα wavelength', 'λ', '0.15406 nm']
    ]},

  { t: 'h2', x: 'Who built this studio' },
  { t: 'callout', kind: 'note', title: 'Developer',
    x: '**Associate Professor Ts. Dr Suriati Paiman** · Physics Department, Faculty of Science, Universiti Putra Malaysia · PHY3201 Solid State Physics, Semester 1, 2026/2027. [Full credit on the course home page.](#home)' },
  { t: 'p', x: 'The nine-topic structure, the 42-hour weekly plan and the CLO/PO weightings on these pages are taken from the approved **Rangka Kursus** and the **Assessment Plan and CAP/COPO mapping for Semester 1, 2026/2027**. The physics content, the 41 figures and the practice bank were written for this course; every figure is drawn from its own equation and every number in a Calculation Corner or a worked answer has been recomputed independently. Corrections are welcome and should go to the lecturer.' }
  ]
};
