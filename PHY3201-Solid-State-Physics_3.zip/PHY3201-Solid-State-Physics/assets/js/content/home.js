window.PHY3201.pages.home = {
  title: 'PHY3201 · Solid State Physics',
  navShort: 'Course home',
  accent: 'brand',
  eyebrow: ['Week 1 · Introduction', 'Semester 1, 2026/2027', 'Universiti Putra Malaysia'],
  lede: 'See the structure. Understand the physics. Explain the material. Nine topics, 42 lecture hours, one continuous argument running from atomic arrangement to the band gap that makes semiconductor technology possible.',
  blocks: [

  { t: 'grid', cols: 4, cards: [
    { k: 'Semester', big: '1', x: '2026/2027' },
    { k: 'Teaching weeks', big: '14', x: '42 lecture contact hours' },
    { k: 'Topics', big: '9', x: 'Crystal structure → band theory' },
    { k: 'Student learning time', big: '120 h', x: '3(3+0) credits' }
  ]},

  { t: 'h2', x: 'How Week 1 runs' },
  { t: 'p', x: 'The first week is not Topic 1. It is the course introduction, and it has four parts, delivered in this order. Work through them before you start the physics — the map and the assessment structure are what make the rest of the semester legible.' },
  { t: 'grid', cols: 4, cards: [
    { k: 'Step 1', h: 'Course home', x: 'What the subject is, why the topics are in this order, and what you are being asked to become good at. You are here.' },
    { k: 'Step 2', h: '14-week teaching map', x: 'The whole semester on one page, built from the approved course outline.', href: '#map' },
    { k: 'Step 3', h: 'Assessment hub', x: 'Where the marks come from, what each CLO asks, and where marks are actually lost.', href: '#assessment' },
    { k: 'Step 4', h: 'Physics for Planetary Health', x: 'The 20 % project. It starts in Week 2, so read it now, not in Week 10.', href: '#p4ph' }
  ]},

  { t: 'h2', x: 'What solid state physics asks' },
  { t: 'p', x: 'A single silicon atom has no band gap. A single copper atom has no electrical conductivity. Neither has a melting point, a hardness or a thermal conductivity. Every property this course is about **emerges only when you put 10²³ atoms together in a periodic arrangement** — and the central question is how microscopic rules become macroscopic behaviour.' },
  { t: 'callout', kind: 'key', title: 'The course question',
    x: 'Given how the atoms are arranged and how they are bonded, what can you say about how the material will behave — and, just as importantly, what can you *not* say? The second half of that question is what separates a physicist from someone who has memorised equations.' },
  { t: 'grid', cols: 4, cards: [
    { k: '🔵 Structure', h: 'How are atoms arranged?', x: 'Crystal lattices, symmetry, planes, and how we measure them. **Topics 1–4.**' },
    { k: '🟡 Bonding', h: 'What holds them together?', x: 'Van der Waals, ionic, covalent, metallic — and the spring constant that follows. **Topic 5.**' },
    { k: '🟢 Excitations', h: 'How does the solid respond?', x: 'Phonons carry heat; electrons carry charge. **Topics 6–8.**' },
    { k: '🟣 Properties', h: 'What behaviour emerges?', x: 'Thermal, electrical, optical — and the band gap that decides them. **Topic 9.**' }
  ]},

  { t: 'h2', x: 'The nine topics, and what each hands to the next' },
  { t: 'diagram', id: 'course-chain', label: 'Figure H.1',
    caption: 'PHY3201 is one argument in nine steps, not nine separate subjects. Each topic produces a specific quantity that the next one needs.' },
  { t: 'topicgrid' },

  { t: 'h2', x: 'Follow one material all the way through' },
  { t: 'p', x: 'The fastest way to see that the nine topics are a single argument is to watch one material travel along it. Take silicon.' },
  { t: 'table',
    head: ['~Topic', 'What we learn about silicon', 'What it hands on'],
    rows: [
      ['1', 'Diamond cubic: an FCC lattice with a two-atom basis, a = 0.5431 nm', 'The structure type'],
      ['2', 'Eight atoms per conventional cell; APF only 0.340 because the bonding is directional', 'The openness that makes doping possible'],
      ['3', 'We know all of this because the (111) reflection appears at 2θ = 28.44° with Cu Kα', 'Experimental confirmation'],
      ['4', 'And because (222) is systematically absent — the diamond-structure signature', 'The basis, not just the lattice'],
      ['5', 'sp³ covalent bonds, cohesive energy 4.63 eV per atom, stiff and directional', 'A large spring constant K'],
      ['6', 'That stiffness with a light atom gives phonons up to about 13 THz', 'The vibrational spectrum'],
      ['7', 'Hence Θ_D = 645 K, κ ≈ 130–150 W m⁻¹ K⁻¹, phonon mean free path ≈ 40 nm', 'Why nanoscale transistors overheat'],
      ['8', 'The valence electrons are *not* free. The model fails, informatively', 'A problem that needs the lattice back'],
      ['9', 'The periodic potential opens a **1.12 eV indirect gap**', 'The number the semiconductor industry is built on']
    ],
    caption: 'Nine topics, one material, one continuous chain of reasoning. By Week 14 you should be able to do this for copper and diamond too, without notes.' },

  { t: 'h2', x: 'How to use this studio' },
  { t: 'grid', cols: 3, cards: [
    { h: 'Each topic page', x: 'Opens with what you should be able to do, works through the physics with derivations and figures drawn to show *mechanism*, includes Calculation Corners with checked numbers, and ends with an exit challenge and a reading map to the five prescribed books.' },
    { h: 'The explorers', x: 'Every topic carries at least one interactive explorer. Use them properly: predict which way the curve will move **before** you drag the slider. If you cannot, that is the thing to go back and read.' },
    { h: 'The practice hub', x: 'Filterable by topic, level and question type, with staged hints before the worked answer. Foundation → Connect → Materials Challenge, on the same topic, in that order.', href: '#practice' }
  ]},
  { t: 'callout', kind: 'note', title: 'A note on the figures',
    x: 'Every diagram in this studio is hand-drawn to show a mechanism rather than to label parts. Where a figure shows a curve, the curve is computed from the actual equation, not sketched. Where a Calculation Corner gives a number, that number has been computed and checked against a published value, and the comparison is shown — including when the model is a few percent off, and why.' },

  { t: 'h2', x: 'Think like a materials physicist' },
  { t: 'grid', cols: 5, cards: [
    { k: '01', h: 'See it', x: 'Visualise the arrangement before reaching for an equation.' },
    { k: '02', h: 'Understand it', x: 'Identify which physical mechanism is operating.' },
    { k: '03', h: 'Calculate it', x: 'Apply the model — and name the model.' },
    { k: '04', h: 'Connect it', x: 'Relate the result to the material, not just to the number.' },
    { k: '05', h: 'Bound it', x: 'State what your reasoning does **not** establish.' }
  ]},
  { t: 'callout', kind: 'key', title: 'Start here',
    x: 'Read the [14-week teaching map](#map) next, then the [Assessment Hub](#assessment), then the [P4PH project brief](#p4ph). After that, [Topic 1 · Crystal Structure](#topic01).' },

  { t: 'hr' },
  { t: 'person', kicker: 'Developed by',
    name: 'Associate Professor Ts. Dr Suriati Paiman',
    role: 'Course developer and lecturer, PHY3201 Solid State Physics',
    affil: 'Physics Department, Faculty of Science, Universiti Putra Malaysia',
    src: 'assets/img/developer-suriati-paiman.jpg',
    alt: 'Associate Professor Ts. Dr Suriati Paiman',
    x: 'This studio was written for Semester 1, 2026/2027 and follows the approved Rangka Kursus and the CAP/COPO assessment mapping. Questions about coverage, assessment dates or the P4PH project go to the lecturer, not to this page.' }
  ]
};
