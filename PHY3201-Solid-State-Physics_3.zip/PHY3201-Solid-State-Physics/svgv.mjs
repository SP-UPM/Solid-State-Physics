import { chromium } from 'playwright';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const HERE = dirname(fileURLToPath(import.meta.url));
const PAGE = 'file://' + join(HERE, 'index.html');
const SHOTS = join(HERE, 'shots');

const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await b.newPage({viewport:{width:1360,height:1000}});
await p.goto(PAGE + '#home',{waitUntil:'load'});
await p.waitForTimeout(300);
const res = await p.evaluate(() => {
  const D=window.PHY3201.diagrams, out={h:[],v:[]};
  const host=document.createElement('div');
  host.style.cssText='position:absolute;left:-9999px;top:0;width:1200px';
  document.body.appendChild(host);
  for(const id of Object.keys(D)){
    host.innerHTML=D[id]();
    const svg=host.querySelector('svg'), vb=svg.viewBox.baseVal;
    svg.querySelectorAll('text').forEach(t=>{
      const bb=t.getBBox();
      if(bb.x<-1||bb.x+bb.width>vb.width+1) out.h.push(`${id}: +${Math.round(bb.x+bb.width-vb.width)}px  "${t.textContent.slice(0,40)}"`);
      if(bb.y<-1||bb.y+bb.height>vb.height+1) out.v.push(`${id}: bottom ${Math.round(bb.y+bb.height)} > h ${vb.height}  "${t.textContent.slice(0,40)}"`);
    });
  }
  host.remove(); return out;
});
console.log('HORIZONTAL overflow:', res.h.length); res.h.forEach(x=>console.log('  '+x));
console.log('VERTICAL overflow:', res.v.length);  res.v.forEach(x=>console.log('  '+x));
await b.close();
