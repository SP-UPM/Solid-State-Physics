#!/usr/bin/env python3
"""Build PHY3201-offline.html — a single self-contained file with no external
requests. Run from the repository root:   python3 build-single-file.py

IMPORTANT: JS_FILES below must match the <script> order in index.html.
Any new script added to index.html must be added here too, or it will be
missing from the offline build.
"""
import base64
import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))

CSS_FILE = "assets/css/styles.css"

JS_FILES = [
    "assets/js/glossary.js",
    "assets/js/diagrams.js",
    "assets/js/content/home.js",
    "assets/js/content/map.js",
    "assets/js/content/assessment.js",
    "assets/js/content/topic01.js",
    "assets/js/content/topic02.js",
    "assets/js/content/topic03.js",
    "assets/js/content/topic04.js",
    "assets/js/content/topic05.js",
    "assets/js/content/topic06.js",
    "assets/js/content/topic07.js",
    "assets/js/content/topic08.js",
    "assets/js/content/topic09.js",
    "assets/js/content/practice.js",
    "assets/js/content/p4ph.js",
    "assets/js/content/references.js",
    "assets/js/widgets.js",
    "assets/js/app.js",
]

OUT = "PHY3201-offline.html"


def read(path):
    with open(os.path.join(ROOT, path), encoding="utf-8") as fh:
        return fh.read()


def data_uri(path):
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
            "webp": "image/webp", "svg": "image/svg+xml", "gif": "image/gif"}.get(ext, "application/octet-stream")
    with open(os.path.join(ROOT, path), "rb") as fh:
        return "data:%s;base64,%s" % (mime, base64.b64encode(fh.read()).decode("ascii"))


def main():
    missing = [p for p in [CSS_FILE] + JS_FILES if not os.path.exists(os.path.join(ROOT, p))]
    if missing:
        sys.exit("Missing source files:\n  " + "\n  ".join(missing))

    html = read("index.html")

    # 0 · strip the Google Fonts links — the offline file must make no request.
    #     styles.css already declares a full system fallback stack.
    html = re.sub(r'\s*<link rel="preconnect"[^>]*>', "", html)
    html = re.sub(r'\s*<link rel="stylesheet" href="https://fonts\.googleapis[^"]*">', "", html)

    # 1 · inline the stylesheet
    html = re.sub(
        r'<link rel="stylesheet" href="[^"]*">',
        lambda m: "<style>\n" + read(CSS_FILE) + "\n</style>",
        html, count=1)

    # 2 · inline every script, in order, replacing the whole run of <script> tags
    bundle = []
    for path in JS_FILES:
        bundle.append("/* ==== %s ==== */" % path)
        bundle.append(read(path))
    scripts = "<script>\n" + "\n".join(bundle) + "\n</script>"
    html = re.sub(r'(<script src="[^"]*"></script>\s*)+', lambda m: scripts, html, count=1)

    # 3 · inline any local <img src="assets/..."> as a data: URI
    def repl_img(m):
        src = m.group(1)
        full = os.path.join(ROOT, src)
        if src.startswith(("http", "data:")) or not os.path.exists(full):
            return m.group(0)
        return m.group(0).replace(src, data_uri(src))
    html = re.sub(r'<img[^>]*\bsrc="([^"]+)"[^>]*>', repl_img, html)

    # 3b · inline any assets/img/... path that appears inside the bundled JS as well.
    #      Content blocks reference the developer portrait from a page object, not from an
    #      <img> tag in index.html, so the tag-level pass above cannot see it — and a bare
    #      relative path 404s in both the offline file and the artifact.
    def repl_path(m):
        src = m.group(1)
        return data_uri(src) if os.path.exists(os.path.join(ROOT, src)) else m.group(0)
    html = re.sub(r"(assets/img/[A-Za-z0-9._/-]+\.(?:png|jpe?g|webp|svg|gif))", repl_path, html)

    # 4 · if the UPM logo has not been supplied, drop the <img> so the offline
    #     file makes no network request at all, and show the fallback crest
    if not os.path.exists(os.path.join(ROOT, "assets/img/upm-logo.png")):
        html = re.sub(r'<a class="brandbar__logolink".*?</a>', "", html, flags=re.S)
        html = html.replace('id="brandMark" hidden', 'id="brandMark"')

    # 5 · sanity checks
    # Two distinct risks: an unresolved src/href attribute, and a bare assets/img path
    # left inside the bundled JS. The /* ==== assets/js/x.js ==== */ banners are comments
    # and must not trip this, so the bare-path check is limited to the image directory.
    leftovers = (re.findall(r'(?:src|href)="(assets/[^"]+)"', html) +
                 re.findall(r'assets/img/[A-Za-z0-9._/-]+\.(?:png|jpe?g|webp|svg|gif)', html))
    if leftovers:
        sys.exit("ERROR: unresolved local references would 404 offline: %s"
                 % sorted(set(leftovers)))

    with open(os.path.join(ROOT, OUT), "w", encoding="utf-8") as fh:
        fh.write(html)

    size = os.path.getsize(os.path.join(ROOT, OUT))
    print("Wrote %s  (%.1f KB, %d scripts inlined)" % (OUT, size / 1024, len(JS_FILES)))
    if "<script src=" in html:
        sys.exit("ERROR: an external script tag survived the bundle step.")


if __name__ == "__main__":
    main()
