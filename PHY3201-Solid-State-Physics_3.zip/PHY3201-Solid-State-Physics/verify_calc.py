# -*- coding: utf-8 -*-
"""Independent recomputation of every number in the 18 new calculation questions."""
from math import pi, sqrt, sin, cos, asin, degrees, radians, exp, log

u   = 1.66053906660e-27
e   = 1.602176634e-19
me  = 9.1093837015e-31
hbar= 1.054571817e-34
kB  = 1.380649e-23
NA  = 6.02214076e23
R   = NA*kB
out = []
def p(tag, *vals): out.append((tag,) + vals); print(tag, *vals)

print("== T1-C3  polonium, simple cubic")
a = 0.3359e-9
Rad = a/2
apf = (4/3)*pi*Rad**3 / a**3
p("R (nm)", round(Rad*1e9,5)); p("APF", round(apf,4), "pi/6 =", round(pi/6,4))
p("n (m^-3)", "%.4g" % (1/a**3)); p("a^3", "%.5g" % a**3)

print("== T1-M3  CsCl / NaCl radius ratio")
rCs, rCl, rNa = 0.170, 0.181, 0.102
p("Cs+/Cl-", round(rCs/rCl,4)); p("Na+/Cl-", round(rNa/rCl,4))
aCsCl = 2*(rCs+rCl)/sqrt(3)
p("a CsCl (nm)", round(aCsCl,4), "vs 0.4110 err%", round((aCsCl-0.4110)/0.4110*100,2))
aNaCl = 2*(rNa+rCl)
p("a NaCl (nm)", round(aNaCl,4), "vs 0.5640 err%", round((aNaCl-0.5640)/0.5640*100,2))

print("== T2-C3  BCC Fe interplanar spacings + [111] linear density")
aFe = 0.2866
for hkl,N in (("110",2),("200",4),("211",6)):
    p("d"+hkl+" (nm)", round(aFe/sqrt(N),5))
p("body diag (nm)", round(sqrt(3)*aFe,5))
p("LD[111] (nm^-1)", round(2/(sqrt(3)*aFe),4))

print("== T2-M3  BCC Fe planar density (110) vs (100)")
p("a^2 (nm^2)", round(aFe**2,6))
pd110 = sqrt(2)/aFe**2; pd100 = 1/aFe**2
p("PD110 nm^-2", round(pd110,3), "= %.4g m^-2" % (pd110*1e18))
p("PD100 nm^-2", round(pd100,3), "= %.4g m^-2" % (pd100*1e18))
p("ratio", round(pd110/pd100,4), "sqrt2 =", round(sqrt(2),4))
RFe = sqrt(3)*aFe/4
p("R Fe (nm)", round(RFe,5))
p("planar packing (110)", round(2*pi*RFe**2/(sqrt(2)*aFe**2),4))

print("== T3-C3  powder pattern of FCC Al")
lam = 0.15406; aAl = 0.40496
for hkl,N in (("111",3),("200",4),("220",8)):
    d = aAl/sqrt(N); st = lam/(2*d); th = degrees(asin(st))
    p(hkl, "d=%.5f  sin=%.5f  2theta=%.3f" % (d, st, 2*th))
s = [sin(radians(38.476/2))**2, sin(radians(44.714/2))**2, sin(radians(65.099/2))**2]
p("sin^2 ratios", [round(x/s[0],3) for x in s])
# back out a from the first peak
d1 = lam/(2*sin(radians(38.476/2))); p("a from (111)", round(d1*sqrt(3),5))

print("== T3-M3  Scherrer")
K=0.9; beta_deg=0.86; th=radians(38.47/2)
beta=radians(beta_deg)
D = K*lam/(beta*cos(th))
p("beta rad", round(beta,6)); p("cos th", round(cos(th),5)); p("D (nm)", round(D,3))

print("== T4-C3  CsCl structure factor")
fCs, fCll = 54.0, 17.0
p("F even", fCs+fCll, "F odd", fCs-fCll)
p("I ratio", round(((fCs+fCll)/(fCs-fCll))**2,4))

print("== T4-M3  Ewald cut-off for FCC Al with Cu Ka")
G111 = 2*pi*sqrt(3)/aAl
p("|G111| nm^-1", round(G111,4))
p("2|k| = 4pi/lam nm^-1", round(4*pi/lam,3))
Nmax = (2*aAl/lam)**2
p("sqrt(N) limit", round(2*aAl/lam,4), "N limit", round(Nmax,2))
def fcc_allowed(nmax):
    res=set()
    for h in range(0,7):
        for k in range(0,7):
            for l in range(0,7):
                if h==k==l==0: continue
                par = [h%2,k%2,l%2]
                if par==[1,1,1] or par==[0,0,0]:
                    n=h*h+k*k+l*l
                    if n<=nmax: res.add(n)
    return sorted(res)
p("FCC allowed N <= limit", fcc_allowed(int(Nmax)))

print("== T5-C3  NaCl Born model")
alpha=1.7476; r0=2.820  # angstrom
k_eV_A = 14.399645
for n in (8,9,10):
    U = -alpha*(k_eV_A/r0)*(1-1/n)
    p("n=%d  U (eV/ion pair)"%n, round(U,4), " per atom", round(U/2,4))
p("coulomb term alone", round(-alpha*k_eV_A/r0,4))

print("== T5-M3  Lennard-Jones argon")
eps=0.0104; sig=3.40    # eV, angstrom
r0lj = 2**(1/6)*sig
p("r0 (A)", round(r0lj,4)); p("U(r0) eV", -eps)
Kcurv_eVA2 = 4*eps/sig**2*(156/2**(14/6) - 42/2**(8/6))
p("57.146 eps/sig^2 check", round(4*(156/2**(14/6) - 42/2**(8/6)),4))
p("K (eV/A^2)", round(Kcurv_eVA2,6))
K_Nm = Kcurv_eVA2 * e/1e-20
p("K (N/m)", round(K_Nm,4))
mAr = 39.948*u
om = sqrt(K_Nm/mAr)
p("omega (rad/s)", "%.4g"%om, " nu THz", round(om/2/pi/1e12,4))
Theta = hbar*om/kB
p("Theta_E (K)", round(Theta,2), " x sqrt(12) =", round(Theta*sqrt(12),1), " (Debye Ar = 92 K)")

print("== T6-C3  monatomic chain, copper")
C=15.0; M=63.55*u; aNN=0.3615/sqrt(2)
p("a_NN (nm)", round(aNN,5))
w0=sqrt(C/M); wmax=2*w0
p("sqrt(C/M)", "%.5g"%w0); p("omega_max rad/s", "%.5g"%wmax, "nu_max THz", round(wmax/2/pi/1e12,4))
vs = aNN*1e-9*w0
p("v_s (m/s)", round(vs,1))
p("v_g at k=pi/2a (m/s)", round(vs*cos(pi/4),1))

print("== T6-M3  diatomic chain NaCl masses")
m1=22.98977*u; m2=35.453*u
mu = 1/(1/m1+1/m2)
p("mu (kg)", "%.5g"%mu)
wopt0=sqrt(2*C/mu)
p("omega_opt(0)", "%.5g"%wopt0, "THz", round(wopt0/2/pi/1e12,4))
wA=sqrt(2*C/m2); wO=sqrt(2*C/m1)
p("zone-edge acoustic THz", round(wA/2/pi/1e12,4), " optical THz", round(wO/2/pi/1e12,4))
p("gap THz", round((wO-wA)/2/pi/1e12,4), " ratio", round(wO/wA,4), "sqrt(M/m)", round(sqrt(m2/m1),4))

print("== T7-C3  Debye T^3 for copper at 10 K")
Th=343.0
pref = (12*pi**4/5)*R
p("12pi^4/5", round(12*pi**4/5,4)); p("prefactor J/mol/K", round(pref,2))
Cv10 = pref*(10/Th)**3
p("C_V(10K)", round(Cv10,5), " % of 3R", round(Cv10/(3*R)*100,4))
A = pref/Th**3
gam = 0.695e-3
p("A J/mol/K^4", "%.5g"%A); p("crossover T (K)", round(sqrt(gam/A),3))

print("== T7-M3  silicon nanowire thermal conductivity")
kap=130.0; cv=1.66e6; v=6400.0
lb = 3*kap/(cv*v)
p("l_bulk (nm)", round(lb*1e9,3))
d=20e-9
lw = 1/(1/lb+1/d)
p("l_wire (nm)", round(lw*1e9,3))
kw = cv*v*lw/3
p("kappa_wire", round(kw,2), " reduction x", round(kap/kw,3))

print("== T8-C3  Drude for copper")
sig=5.96e7; n=8.47e28; vF=1.57e6
tau = sig*me/(n*e**2)
p("tau (s)", "%.5g"%tau, "fs", round(tau*1e15,3))
p("l = vF tau (nm)", round(vF*tau*1e9,3))
p("in units of a_NN(0.2556nm)", round(vF*tau*1e9/0.2556,1))
mob = e*tau/me
p("mobility m^2/Vs", "%.5g"%mob, "cm^2/Vs", round(mob*1e4,2))

print("== T8-M3  Wiedemann-Franz for copper")
L=2.44e-8
kel = L*sig*300
p("kappa_el", round(kel,2), " vs 401 measured, err%", round((kel-401)/401*100,2))

print("== T9-C3  intrinsic carriers in silicon")
Nc=2.8e25; Nv=1.04e25; Eg=1.12; kT=0.02585
pre=sqrt(Nc*Nv)
p("sqrt(NcNv) m^-3", "%.5g"%pre)
ex=exp(-Eg/(2*kT))
p("Eg/2kT", round(Eg/(2*kT),5), " exp", "%.5g"%ex)
ni=pre*ex
p("n_i m^-3", "%.4g"%ni, " cm^-3", "%.4g"%(ni/1e6))

print("== T9-M3  effective mass from curvature")
kv=0.50e9; Ev=0.142*e
mst = hbar**2*kv**2/(2*Ev)
p("hbar^2 k^2", "%.5g"%(hbar**2*kv**2)); p("m* kg", "%.5g"%mst, " m*/me", round(mst/me,4))
p("mobility ratio 0.26/0.067", round(0.26/0.067,3), " measured 8500/1400", round(8500/1400,3))
