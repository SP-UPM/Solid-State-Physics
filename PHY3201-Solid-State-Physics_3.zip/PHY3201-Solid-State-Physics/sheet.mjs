import { chromium } from 'playwright';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const HERE = dirname(fileURLToPath(import.meta.url));
const PAGE = 'file://' + join(HERE, 'index.html');
const SHOTS = join(HERE, 'shots');

import fs from 'fs';
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await b.newPage({viewport:{width:600,height:600},deviceScaleFactor:2});
await p.goto(PAGE + '#home',{waitUntil:'load'});
await p.waitForTimeout(600);
const ids=await p.evaluate(()=>Object.keys(window.PHY3201.diagrams));
fs.mkdirSync(join(SHOTS,'dg'),{recursive:true});
for(const id of ids){
  await p.evaluate(i=>{
    document.body.innerHTML='<div id="s" style="background:#fff;padding:10px;width:520px">'+window.PHY3201.diagrams[i]()+'</div>';
    document.body.style.margin='0';document.body.style.background='#fff';
  },id);
  await p.waitForTimeout(60);
  await p.locator('#s').screenshot({path:join(SHOTS,'dg',id+'.png')});
}
console.log('rendered',ids.length);
fs.writeFileSync(join(SHOTS,'dg','_ids.json'),JSON.stringify(ids));
await b.close();
