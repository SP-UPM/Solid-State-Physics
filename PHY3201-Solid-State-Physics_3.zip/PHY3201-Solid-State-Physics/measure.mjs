import { chromium } from 'playwright';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
const HERE = dirname(fileURLToPath(import.meta.url));
const PAGE = 'file://' + join(HERE, 'index.html');
const SHOTS = join(HERE, 'shots');

const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await b.newPage({viewport:{width:1360,height:1000}});
await p.goto(PAGE + '#home',{waitUntil:'load'});
await p.waitForTimeout(300);
const res = await p.evaluate(() => {
  const D=window.PHY3201.diagrams, out={};
  const host=document.createElement('div');
  host.style.cssText='position:absolute;left:-9999px;top:0;width:1200px';
  document.body.appendChild(host);
  for(const id of Object.keys(D)){
    host.innerHTML=D[id]();
    const svg=host.querySelector('svg'), vb=svg.viewBox.baseVal;
    let bot=0;
    svg.querySelectorAll('text,rect,circle,line,path,polygon,ellipse').forEach(e=>{
      try{const bb=e.getBBox(); bot=Math.max(bot, bb.y+bb.height);}catch(err){}
    });
    out[id]={h:vb.height, need:Math.ceil(bot)+8};
  }
  host.remove(); return out;
});
console.log(JSON.stringify(res));
await b.close();
