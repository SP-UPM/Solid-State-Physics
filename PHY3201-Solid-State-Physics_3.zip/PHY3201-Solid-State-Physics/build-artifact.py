#!/usr/bin/env python3
"""Build phy3201-artifact.html — the body-only form the Artifact tool expects.

The Artifact publisher wraps the file in its own <!doctype>/<head>/<body>, so this
build strips those, keeps <title> and the font links, and inlines every script.
Run after build-single-file.py:   python3 build-artifact.py
"""
import os, re, sys
import importlib.util

ROOT = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("bsf", os.path.join(ROOT, "build-single-file.py"))
bsf = importlib.util.module_from_spec(spec); spec.loader.exec_module(bsf)

def read(p):
    with open(os.path.join(ROOT, p), encoding="utf-8") as fh: return fh.read()

html = read("index.html")
html = re.sub(r'<link rel="stylesheet" href="assets/css/styles.css">',
              lambda m: "<style>\n" + read(bsf.CSS_FILE) + "\n</style>", html, count=1)
bundle = []
for path in bsf.JS_FILES:
    bundle.append("/* ==== %s ==== */" % path)
    bundle.append(read(path))
html = re.sub(r'(<script src="[^"]*"></script>\s*)+',
              lambda m: "<script>\n" + "\n".join(bundle) + "\n</script>", html, count=1)

# Inline every local image as a data: URI. An artifact is served from its own origin with
# no accompanying asset folder, so a relative src silently 404s — this is exactly the bug
# that left the PHY4230 artifact showing a broken logo. Do not remove this step.
def _repl_img(m):
    src = m.group(1)
    if src.startswith(("http", "data:")) or not os.path.exists(os.path.join(ROOT, src)):
        return m.group(0)
    return m.group(0).replace(src, bsf.data_uri(src))
html = re.sub(r'<img[^>]*\bsrc="([^"]+)"[^>]*>', _repl_img, html, flags=re.S)

# Content blocks reference the developer portrait from a page object inside the bundled JS,
# where the <img>-tag pass above cannot see it. Inline any bare assets/img path too.
def _repl_path(m):
    src = m.group(1)
    return bsf.data_uri(src) if os.path.exists(os.path.join(ROOT, src)) else m.group(0)
html = re.sub(r"(assets/img/[A-Za-z0-9._/-]+\.(?:png|jpe?g|webp|svg|gif))", _repl_path, html)

# if the logo file is absent entirely, drop the tag and show the typographic fallback
if not os.path.exists(os.path.join(ROOT, "assets/img/upm-logo.png")):
    html = re.sub(r'<a class="brandbar__logolink".*?</a>', "", html, flags=re.S)
    html = html.replace('id="brandMark" hidden', 'id="brandMark"')

# pull out <title>, the font links, the <style> and everything inside <body>
title = re.search(r'<title>(.*?)</title>', html, re.S).group(1)
fonts = "\n".join(re.findall(r'<link rel="(?:preconnect|stylesheet)"[^>]*fonts\.g[^>]*>', html))
style = re.search(r'<style>.*?</style>', html, re.S).group(0)
body  = re.search(r'<body>(.*)</body>', html, re.S).group(1)

out = "<title>%s</title>\n%s\n%s\n%s" % (title, fonts, style, body.strip())
dest = os.path.join(ROOT, "phy3201-artifact.html")
with open(dest, "w", encoding="utf-8") as fh:
    fh.write(out)

# precise checks — "<header" legitimately contains "<head"
for pat in (r'<!doctype', r'</?html\b', r'</?head\s*>', r'</?body\s*>', r'<script\s+src='):
    if re.search(pat, out, re.I):
        sys.exit("ERROR: %s survived into the artifact build" % pat)
stragglers = (re.findall(r'(?:src|href)="(assets/[^"]+)"', out) +
              re.findall(r'assets/img/[A-Za-z0-9._/-]+\.(?:png|jpe?g|webp|svg|gif)', out))
if stragglers:
    sys.exit("ERROR: un-inlined local references would 404 in the artifact: %s" % sorted(set(stragglers)))
print("Wrote phy3201-artifact.html  (%.1f KB)" % (os.path.getsize(dest)/1024))
